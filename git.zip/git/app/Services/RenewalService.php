<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use PDO;

/**
 * Renewal Center engine.
 *
 * InfinityFree has no cron jobs, so expiry checks run dynamically on
 * page load (dashboard + renewal center). Everything here is a single
 * cheap indexed query per source — no state, no background jobs.
 *
 * Sources scanned: domain expiry, domain SSL expiry, hosting expiry,
 * project maintenance expiry, project warranty expiry.
 */
final class RenewalService
{
    /** Bucket edges, in days (spec: expired / 7 / 15 / 30 / 60 / 90). */
    public const BUCKETS = [0, 7, 15, 30, 60, 90];

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    /**
     * All items expiring within $horizon days (plus anything already expired),
     * as a unified list sorted soonest-first. Each item:
     * [type, id, label, client_id, client_name, whatsapp, client_email, expiry, days]
     */
    public function expiringItems(int $horizon = 90): array
    {
        $sql = "
            SELECT 'domain' AS type, d.id, d.domain_name AS label,
                   d.client_id, c.name AS client_name, c.whatsapp, c.email AS client_email, d.expiry_date AS expiry
            FROM domains d LEFT JOIN clients c ON c.id = d.client_id
            WHERE d.status = 'active' AND d.expiry_date IS NOT NULL
              AND d.expiry_date <= DATE_ADD(CURDATE(), INTERVAL :h1 DAY)

            UNION ALL
            SELECT 'ssl', d.id, CONCAT('SSL — ', d.domain_name),
                   d.client_id, c.name, c.whatsapp, c.email, d.ssl_expiry
            FROM domains d LEFT JOIN clients c ON c.id = d.client_id
            WHERE d.status = 'active' AND d.ssl_expiry IS NOT NULL
              AND d.ssl_expiry <= DATE_ADD(CURDATE(), INTERVAL :h2 DAY)

            UNION ALL
            SELECT 'hosting', h.id, CONCAT(h.provider, IFNULL(CONCAT(' — ', h.plan), '')),
                   h.client_id, c.name, c.whatsapp, c.email, h.expiry_date
            FROM hosting_accounts h LEFT JOIN clients c ON c.id = h.client_id
            WHERE h.status = 'active' AND h.expiry_date IS NOT NULL
              AND h.expiry_date <= DATE_ADD(CURDATE(), INTERVAL :h3 DAY)

            UNION ALL
            SELECT 'maintenance', p.id, CONCAT('Maintenance — ', p.name),
                   p.client_id, c.name, c.whatsapp, c.email, p.maintenance_until
            FROM projects p JOIN clients c ON c.id = p.client_id
            WHERE p.status <> 'cancelled' AND p.maintenance_until IS NOT NULL
              AND p.maintenance_until <= DATE_ADD(CURDATE(), INTERVAL :h4 DAY)

            UNION ALL
            SELECT 'warranty', p.id, CONCAT('Warranty — ', p.name),
                   p.client_id, c.name, c.whatsapp, c.email, p.warranty_until
            FROM projects p JOIN clients c ON c.id = p.client_id
            WHERE p.status <> 'cancelled' AND p.warranty_until IS NOT NULL
              AND p.warranty_until <= DATE_ADD(CURDATE(), INTERVAL :h5 DAY)

            ORDER BY expiry ASC";

        $stmt = $this->db->prepare($sql);
        foreach (['h1', 'h2', 'h3', 'h4', 'h5'] as $p) {
            $stmt->bindValue($p, $horizon, PDO::PARAM_INT);
        }
        $stmt->execute();

        $items = $stmt->fetchAll();
        foreach ($items as &$item) {
            $item['days'] = days_left($item['expiry']);
        }
        return $items;
    }

    /**
     * Group items into display buckets:
     * 'expired', 'within_7', 'within_15', 'within_30', 'within_60', 'within_90'.
     */
    public function buckets(int $horizon = 90): array
    {
        $groups = [
            'expired'   => [], 'within_7'  => [], 'within_15' => [],
            'within_30' => [], 'within_60' => [], 'within_90' => [],
        ];

        foreach ($this->expiringItems($horizon) as $item) {
            $d = $item['days'];
            $key = match (true) {
                $d < 0   => 'expired',
                $d <= 7  => 'within_7',
                $d <= 15 => 'within_15',
                $d <= 30 => 'within_30',
                $d <= 60 => 'within_60',
                default  => 'within_90',
            };
            $groups[$key][] = $item;
        }
        return $groups;
    }

    /** Count needing attention soon — the dashboard stat (expired or ≤30 days). */
    public function dueCount(): int
    {
        $count = 0;
        foreach ($this->expiringItems(30) as $item) {
            $count++;
        }
        return $count;
    }
}
