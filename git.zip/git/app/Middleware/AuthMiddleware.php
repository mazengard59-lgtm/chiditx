<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Session;

/** Requires an authenticated user; otherwise redirects to login. */
final class AuthMiddleware
{
    public function handle(Request $request): void
    {
        if (!Auth::check()) {
            Session::set('_intended', $request->path);
            flash('error', 'Please sign in to continue.');
            redirect('login');
        }
    }
}
