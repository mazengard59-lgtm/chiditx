<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;

/** Requires the admin role (use after 'auth'). */
final class AdminMiddleware
{
    public function handle(Request $request): void
    {
        if (!Auth::isAdmin()) {
            http_response_code(403);
            exit(\App\Core\View::render('errors.403', [], null));
        }
    }
}
