<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Csrf;
use App\Core\Request;

/**
 * Verifies the CSRF token on state-changing requests.
 * Applied automatically by the kernel to POST/PUT/PATCH/DELETE.
 */
final class CsrfMiddleware
{
    public function handle(Request $request): void
    {
        $token = $request->input('_token') ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);

        if (!Csrf::verify($token)) {
            http_response_code(419);
            exit('Page expired. Go back, refresh, and try again.');
        }
    }
}
