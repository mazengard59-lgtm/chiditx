<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;

/** Portal routes: requires a client-role user linked to a client record. */
final class ClientMiddleware
{
    public function handle(Request $request): void
    {
        $user = Auth::user();

        if (($user['role'] ?? null) !== 'client') {
            http_response_code(403);
            exit(\App\Core\View::render('errors.403', [], null));
        }

        if ((new \App\Models\Client())->findBy('user_id', (int) $user['id']) === null) {
            Auth::logout();
            flash('error', 'Your portal account is not linked to a client profile. Contact support.');
            redirect('login');
        }
    }
}
