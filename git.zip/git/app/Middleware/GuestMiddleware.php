<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;

/** Routes for guests only (login page) — authenticated users go to the dashboard. */
final class GuestMiddleware
{
    public function handle(Request $request): void
    {
        if (Auth::check()) {
            redirect(Auth::user()['role'] === 'client' ? 'portal' : 'dashboard');
        }
    }
}
