<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\HostingAccount;

final class HostingController extends Controller
{
    private HostingAccount $hosting;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->hosting = new HostingAccount();
    }

    public function index(): string
    {
        return $this->view('hosting.index', [
            'title'    => 'Hosting',
            'accounts' => $this->hosting->allWithClients(),
        ]);
    }

    public function create(): string
    {
        return $this->form(null);
    }

    public function edit(string $id): string
    {
        $account = $this->hosting->find((int) $id) ?? $this->notFound();
        return $this->form($account);
    }

    private function form(?array $account): string
    {
        return $this->view('hosting.form', [
            'title'         => $account ? 'Edit — ' . $account['provider'] : 'New Hosting Account',
            'account'       => $account,
            'clientOptions' => (new Client())->options(),
            'errors'        => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('hosting/create');
        $this->hosting->create($data);
        ActivityLog::record((int) auth()['id'], 'hosting.create', "Added hosting {$data['provider']}", $this->request);
        flash('success', "Hosting account ({$data['provider']}) added.");
        redirect('hosting');
    }

    public function update(string $id): string
    {
        $this->hosting->find((int) $id) ?? $this->notFound();
        $data = $this->validated("hosting/{$id}/edit");
        $this->hosting->update((int) $id, $data);
        ActivityLog::record((int) auth()['id'], 'hosting.update', "Updated hosting {$data['provider']}", $this->request);
        flash('success', 'Hosting account updated.');
        redirect('hosting');
    }

    public function destroy(string $id): string
    {
        $account = $this->hosting->find((int) $id) ?? $this->notFound();
        $this->hosting->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'hosting.delete', "Deleted hosting {$account['provider']}", $this->request);
        flash('success', "Hosting account ({$account['provider']}) deleted.");
        redirect('hosting');
    }

    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'provider'          => 'required|min:2|max:120',
            'plan'              => 'max:120',
            'disk_space'        => 'max:60',
            'bandwidth'         => 'max:60',
            'server_ip'         => 'max:45',
            'control_panel_url' => 'max:300',
            'php_version'       => 'max:20',
            'username'          => 'max:120',
            'notes'             => 'max:5000',
        ]);

        $status = $this->request->input('status', 'active');
        if (!in_array($status, HostingAccount::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }

        $clientId = (int) ($this->request->input('client_id', '0') ?? 0);
        if ($clientId > 0 && (new Client())->find($clientId) === null) {
            $errors['client_id'] = 'Invalid client.';
        }

        $expiry = $this->request->input('expiry_date', '');
        if ($expiry !== '' && $expiry !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry)) {
            $errors['expiry_date'] = 'Use the date picker (YYYY-MM-DD).';
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        return array_merge($values, [
            'client_id'   => $clientId > 0 ? $clientId : null,
            'status'      => $status,
            'has_ssl'     => $this->request->input('has_ssl') === '1' ? 1 : 0,
            'expiry_date' => $expiry ?: null,
        ]);
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
