<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Project;

final class ClientController extends Controller
{
    private Client $clients;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->clients = new Client();
    }

    public function index(): string
    {
        return $this->view('clients.index', [
            'title'   => 'Clients',
            'clients' => $this->clients->allWithProjectCounts(),
        ]);
    }

    public function create(): string
    {
        return $this->view('clients.form', [
            'title'  => 'New Client',
            'client' => null,
            'errors' => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('clients/create');

        $id = $this->clients->create($data);
        ActivityLog::record((int) auth()['id'], 'client.create', "Added client \"{$data['name']}\"", $this->request);

        flash('success', "Client \"{$data['name']}\" added.");
        redirect("clients/{$id}");
    }

    public function show(string $id): string
    {
        $client = $this->clients->find((int) $id) ?? $this->notFound();

        return $this->view('clients.show', [
            'title'    => $client['name'],
            'client'   => $client,
            'projects' => (new Project())->forClient((int) $id),
        ]);
    }

    public function edit(string $id): string
    {
        $client = $this->clients->find((int) $id) ?? $this->notFound();

        return $this->view('clients.form', [
            'title'  => 'Edit — ' . $client['name'],
            'client' => $client,
            'errors' => Session::pull('_errors', []),
        ]);
    }

    public function update(string $id): string
    {
        $client = $this->clients->find((int) $id) ?? $this->notFound();
        $data = $this->validated("clients/{$id}/edit");

        $this->clients->update((int) $id, $data);
        ActivityLog::record((int) auth()['id'], 'client.update', "Updated client \"{$data['name']}\"", $this->request);

        flash('success', 'Client updated.');
        redirect("clients/{$id}");
    }

    public function destroy(string $id): string
    {
        $client = $this->clients->find((int) $id) ?? $this->notFound();

        $this->clients->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'client.delete', "Deleted client \"{$client['name']}\"", $this->request);

        flash('success', "Client \"{$client['name']}\" deleted (including their projects).");
        redirect('clients');
    }

    /** Create a portal login for this client (random password, shown once). */
    public function createPortalAccount(string $id): string
    {
        $client = $this->clients->find((int) $id) ?? $this->notFound();

        if ($client['user_id'] !== null) {
            flash('error', 'This client already has a portal account.');
            redirect("clients/{$id}");
        }
        if (empty($client['email'])) {
            flash('error', 'Add an email address to this client first — it becomes their login.');
            redirect("clients/{$id}");
        }
        if ((new \App\Models\User())->findByEmail($client['email']) !== null) {
            flash('error', 'A user with this email already exists.');
            redirect("clients/{$id}");
        }

        $password = bin2hex(random_bytes(5)); // 10-char one-time password
        $userId = (new \App\Models\User())->create([
            'name'          => $client['name'],
            'email'         => mb_strtolower($client['email']),
            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
            'role'          => 'client',
            'status'        => 'active',
            'avatar_url'    => $client['photo_url'],
            'phone'         => $client['phone'],
        ]);
        $this->clients->update((int) $id, ['user_id' => $userId]);

        ActivityLog::record((int) auth()['id'], 'client.portal', "Created portal account for {$client['name']}", $this->request);
        flash('success', "Portal account created. Login: {$client['email']} — Password: {$password} (share it now; it won't be shown again).");
        redirect("clients/{$id}");
    }

    /** Shared validation for store/update. Redirects back on failure. */
    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'name'     => 'required|min:2|max:120',
            'company'  => 'max:150',
            'industry' => 'max:100',
            'email'    => 'email|max:190',
            'phone'    => 'max:30',
            'whatsapp' => 'max:30',
            'country'  => 'max:80',
            'timezone' => 'max:60',
            'address'  => 'max:300',
            'photo_url'=> 'max:500',
            'tags'     => 'max:300',
            'notes'    => 'max:5000',
        ]);

        $status = $this->request->input('status', 'regular');
        if (!in_array($status, Client::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        $values['status'] = $status;
        $values['email'] = mb_strtolower($values['email']);
        return $values;
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
