<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\View;
use App\Models\ActivityLog;
use App\Models\BlogComment;
use App\Models\Post;

/** Admin blog CMS + public blog pages. */
final class BlogController extends Controller
{
    private Post $posts;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->posts = new Post();
    }

    /* ===================== Admin ===================== */

    public function index(): string
    {
        return $this->view('blog.index', [
            'title' => 'Blog',
            'posts' => $this->posts->allWithAuthors(),
        ]);
    }

    public function create(): string
    {
        return $this->form(null);
    }

    public function edit(string $id): string
    {
        $post = $this->posts->find((int) $id) ?? $this->notFound();
        return $this->form($post);
    }

    private function form(?array $post): string
    {
        return $this->view('blog.form', [
            'title'  => $post ? 'Edit — ' . $post['title'] : 'New Post',
            'post'   => $post,
            'errors' => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('posts/create');
        $data['user_id'] = (int) auth()['id'];
        $data['slug'] = $this->posts->makeSlug($data['title']);

        $id = $this->posts->create($data);
        ActivityLog::record((int) auth()['id'], 'post.create', "Created post \"{$data['title']}\"", $this->request);
        flash('success', $data['status'] === 'published' ? 'Post published.' : 'Draft saved.');
        redirect("posts/{$id}/edit");
    }

    public function update(string $id): string
    {
        $post = $this->posts->find((int) $id) ?? $this->notFound();
        $data = $this->validated("posts/{$id}/edit");
        $data['slug'] = $this->posts->makeSlug($data['title'], (int) $id);

        // Keep original publish date once published
        if ($post['published_at'] && $data['status'] === 'published') {
            $data['published_at'] = $post['published_at'];
        }

        $this->posts->update((int) $id, $data);
        ActivityLog::record((int) auth()['id'], 'post.update', "Updated post \"{$data['title']}\"", $this->request);
        flash('success', 'Post saved.');
        redirect("posts/{$id}/edit");
    }

    public function destroy(string $id): string
    {
        $post = $this->posts->find((int) $id) ?? $this->notFound();
        $this->posts->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'post.delete', "Deleted post \"{$post['title']}\"", $this->request);
        flash('success', 'Post deleted.');
        redirect('posts');
    }

    public function comments(): string
    {
        return $this->view('blog.comments', [
            'title'    => 'Blog Comments',
            'comments' => (new BlogComment())->allWithPosts(),
        ]);
    }

    public function approveComment(string $id): string
    {
        (new BlogComment())->update((int) $id, ['is_approved' => 1]);
        flash('success', 'Comment approved.');
        redirect('posts/comments');
    }

    public function deleteComment(string $id): string
    {
        (new BlogComment())->delete((int) $id);
        flash('success', 'Comment deleted.');
        redirect('posts/comments');
    }

    /* ===================== Public ===================== */

    public function publicIndex(): string
    {
        return View::render('blog.public-index', [
            'posts' => $this->posts->published(30),
        ], null);
    }

    public function publicShow(string $slug): string
    {
        $post = $this->posts->findPublishedBySlug($slug);
        if ($post === null) {
            http_response_code(404);
            return View::render('errors.404', [], null);
        }

        return View::render('blog.public-show', [
            'post'     => $post,
            'comments' => (new BlogComment())->approvedFor((int) $post['id']),
            'sent'     => Session::pull('_comment_sent'),
        ], null);
    }

    /** Public comment submission (moderated; honeypot spam trap). */
    public function submitComment(string $slug): string
    {
        $post = $this->posts->findPublishedBySlug($slug);
        if ($post === null) {
            http_response_code(404);
            return View::render('errors.404', [], null);
        }

        // Honeypot: bots fill the hidden "website" field
        if (trim((string) $this->request->input('website', '')) !== '') {
            redirect("blog/{$slug}");
        }

        $name = trim((string) $this->request->input('name', ''));
        $body = trim((string) $this->request->input('body', ''));
        $email = trim((string) $this->request->input('email', ''));

        if (mb_strlen($name) >= 2 && mb_strlen($body) >= 3) {
            (new BlogComment())->create([
                'post_id'     => (int) $post['id'],
                'name'        => mb_substr($name, 0, 120),
                'email'       => filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null,
                'body'        => mb_substr($body, 0, 2000),
                'is_approved' => 0,
            ]);
            Session::set('_comment_sent', '1');
        }
        redirect("blog/{$slug}");
    }

    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'title'              => 'required|min:3|max:200',
            'excerpt'            => 'max:500',
            'category'           => 'max:80',
            'tags'               => 'max:300',
            'featured_image_url' => 'max:500',
            'meta_title'         => 'max:200',
            'meta_description'   => 'max:300',
        ]);

        $body = trim((string) $this->request->input('body', ''));
        if ($body === '' || $body === '<p><br></p>') {
            $errors['body'] = 'Post content is required.';
        }

        $status = $this->request->input('status', 'draft');
        if (!in_array($status, Post::STATUSES, true)) {
            $status = 'draft';
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        return array_merge($values, [
            'body'         => $body,
            'status'       => $status,
            'published_at' => $status === 'published' ? date('Y-m-d H:i:s') : null,
        ]);
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(View::render('errors.404', [], null));
    }
}
