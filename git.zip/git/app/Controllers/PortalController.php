<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Session;
use App\Core\View;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\Project;
use App\Models\Ticket;
use App\Models\TicketReply;
use App\Models\User;

/**
 * Client portal. Every method scopes queries to the logged-in client —
 * clients can never reach another client's data.
 */
final class PortalController extends Controller
{
    private array $client;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        // ClientMiddleware guarantees this exists.
        $this->client = (new Client())->findBy('user_id', (int) auth()['id']) ?? [];
    }

    private function portalView(string $view, array $data = []): string
    {
        $data['client'] = $this->client;
        return View::render($view, $data, 'portal');
    }

    public function dashboard(): string
    {
        $db = Database::connection();
        $cid = (int) $this->client['id'];

        $projects = (new Project())->forClient($cid);
        $active = array_filter($projects, fn($p) => in_array($p['status'], Project::ACTIVE_STATUSES, true));

        $inv = $db->prepare(
            "SELECT COALESCE(SUM(total - amount_paid), 0) FROM invoices
             WHERE client_id = ? AND status IN ('pending','partial','overdue')"
        );
        $inv->execute([$cid]);
        $due = (float) $inv->fetchColumn();

        $tickets = $db->prepare(
            "SELECT COUNT(*) FROM tickets WHERE client_id = ? AND status IN ('open','pending')"
        );
        $tickets->execute([$cid]);

        // Client's own upcoming renewals (domains + hosting within 60 days)
        $renewals = $db->prepare(
            "SELECT domain_name AS label, expiry_date AS expiry, 'domain' AS type
             FROM domains WHERE client_id = :c1 AND status = 'active' AND expiry_date IS NOT NULL
               AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 60 DAY)
             UNION ALL
             SELECT CONCAT(provider, ' hosting'), expiry_date, 'hosting'
             FROM hosting_accounts WHERE client_id = :c2 AND status = 'active' AND expiry_date IS NOT NULL
               AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 60 DAY)
             ORDER BY expiry ASC"
        );
        $renewals->execute(['c1' => $cid, 'c2' => $cid]);

        return $this->portalView('portal.dashboard', [
            'title'          => 'Overview',
            'projects'       => $projects,
            'activeProjects' => count($active),
            'amountDue'      => $due,
            'openTickets'    => (int) $tickets->fetchColumn(),
            'renewals'       => $renewals->fetchAll(),
        ]);
    }

    public function projects(): string
    {
        return $this->portalView('portal.projects', [
            'title'    => 'My Projects',
            'projects' => (new Project())->forClient((int) $this->client['id']),
        ]);
    }

    public function invoices(): string
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM invoices WHERE client_id = ? AND status <> "draft" ORDER BY created_at DESC'
        );
        $stmt->execute([(int) $this->client['id']]);

        return $this->portalView('portal.invoices', [
            'title'    => 'My Invoices',
            'invoices' => $stmt->fetchAll(),
        ]);
    }

    /** Printable invoice — reuses the admin print view, ownership-checked. */
    public function invoicePrint(string $id): string
    {
        $invoice = (new Invoice())->findFull((int) $id);
        if ($invoice === null || (int) $invoice['client_id'] !== (int) $this->client['id']) {
            http_response_code(404);
            return View::render('errors.404', [], null);
        }
        return View::render('invoices.print', ['invoice' => $invoice], null);
    }

    public function tickets(): string
    {
        $stmt = Database::connection()->prepare(
            'SELECT t.*, (SELECT COUNT(*) FROM ticket_replies r WHERE r.ticket_id = t.id AND r.is_internal = 0) AS reply_count
             FROM tickets t WHERE t.client_id = ? ORDER BY t.updated_at DESC'
        );
        $stmt->execute([(int) $this->client['id']]);

        return $this->portalView('portal.tickets', [
            'title'   => 'Support',
            'tickets' => $stmt->fetchAll(),
            'errors'  => Session::pull('_errors', []),
        ]);
    }

    public function ticketStore(): string
    {
        [$values, $errors] = $this->validate([
            'subject' => 'required|min:3|max:200',
            'message' => 'required|min:3|max:10000',
        ]);
        if ($errors !== []) {
            $this->backWithErrors('portal/tickets', $errors);
        }

        $id = (new Ticket())->create([
            'client_id' => (int) $this->client['id'],
            'subject'   => $values['subject'],
            'category'  => 'general',
            'priority'  => 'medium',
            'status'    => 'open',
        ]);
        (new TicketReply())->create([
            'ticket_id'   => $id,
            'user_id'     => null, // null author = the client
            'message'     => $values['message'],
            'is_internal' => 0,
        ]);

        flash('success', "Ticket #{$id} opened — we'll get back to you shortly.");
        redirect("portal/tickets/{$id}");
    }

    public function ticketShow(string $id): string
    {
        $ticket = $this->ownTicket((int) $id);

        // Internal notes are never shown to clients.
        $replies = array_values(array_filter(
            (new TicketReply())->forTicket((int) $id),
            static fn($r) => !$r['is_internal']
        ));

        return $this->portalView('portal.ticket', [
            'title'   => "Ticket #{$ticket['id']}",
            'ticket'  => $ticket,
            'replies' => $replies,
        ]);
    }

    public function ticketReply(string $id): string
    {
        $ticket = $this->ownTicket((int) $id);

        $message = trim((string) $this->request->input('message', ''));
        if ($message === '') {
            flash('error', 'Reply cannot be empty.');
            redirect("portal/tickets/{$id}");
        }

        (new TicketReply())->create([
            'ticket_id'   => (int) $id,
            'user_id'     => null,
            'message'     => mb_substr($message, 0, 10000),
            'is_internal' => 0,
        ]);
        if (in_array($ticket['status'], ['resolved', 'closed'], true)) {
            (new Ticket())->update((int) $id, ['status' => 'open']);
        }

        flash('success', 'Reply sent.');
        redirect("portal/tickets/{$id}");
    }

    public function profile(): string
    {
        return $this->portalView('portal.profile', [
            'title'  => 'My Profile',
            'errors' => Session::pull('_errors', []),
        ]);
    }

    public function profileSave(): string
    {
        [$values, $errors] = $this->validate([
            'name'     => 'required|min:2|max:120',
            'phone'    => 'max:30',
            'whatsapp' => 'max:30',
            'address'  => 'max:300',
        ]);
        if ($errors !== []) {
            $this->backWithErrors('portal/profile', $errors);
        }

        (new Client())->update((int) $this->client['id'], $values);
        (new User())->update((int) auth()['id'], ['name' => $values['name'], 'phone' => $values['phone']]);

        flash('success', 'Profile updated.');
        redirect('portal/profile');
    }

    public function passwordSave(): string
    {
        $current = (string) $this->request->input('current_password', '');
        $new     = (string) $this->request->input('new_password', '');

        if (!password_verify($current, auth()['password_hash'])) {
            $this->backWithErrors('portal/profile', ['current_password' => 'Current password is incorrect.']);
        }
        if (mb_strlen($new) < 8) {
            $this->backWithErrors('portal/profile', ['new_password' => 'New password must be at least 8 characters.']);
        }

        (new User())->update((int) auth()['id'], [
            'password_hash' => password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]),
        ]);
        flash('success', 'Password changed.');
        redirect('portal/profile');
    }

    /** Fetch a ticket, 404 unless it belongs to this client. */
    private function ownTicket(int $id): array
    {
        $ticket = (new Ticket())->find($id);
        if ($ticket === null || (int) $ticket['client_id'] !== (int) $this->client['id']) {
            http_response_code(404);
            exit(View::render('errors.404', [], null));
        }
        return $ticket;
    }
}
