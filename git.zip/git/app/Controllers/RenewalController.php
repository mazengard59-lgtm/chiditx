<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\ActivityLog;
use App\Models\Renewal;
use App\Services\RenewalService;

final class RenewalController extends Controller
{
    /** item_type => [table, expiry column, label column/expr]. */
    private const SOURCES = [
        'domain'      => ['domains',          'expiry_date',       'domain_name'],
        'ssl'         => ['domains',          'ssl_expiry',        'domain_name'],
        'hosting'     => ['hosting_accounts', 'expiry_date',       'provider'],
        'maintenance' => ['projects',         'maintenance_until', 'name'],
        'warranty'    => ['projects',         'warranty_until',    'name'],
    ];

    public function index(): string
    {
        $service = new RenewalService();

        return $this->view('renewals.index', [
            'title'   => 'Renewal Center',
            'buckets' => $service->buckets(90),
            'history' => (new Renewal())->recent(15),
        ]);
    }

    /**
     * Mark renewed / extend expiry for any renewable item type.
     * Extends from the later of (current expiry, today) by N months.
     */
    public function renew(): string
    {
        $type   = $this->request->input('item_type', '');
        $id     = (int) ($this->request->input('item_id', '0') ?? 0);
        $months = (int) ($this->request->input('months', '12') ?? 12);

        if (!isset(self::SOURCES[$type]) || $id <= 0) {
            flash('error', 'Invalid renewal request.');
            redirect('renewals');
        }
        $months = max(1, min(60, $months));
        [$table, $column, $labelColumn] = self::SOURCES[$type];

        $db = Database::connection();
        $stmt = $db->prepare("SELECT `{$labelColumn}` AS label, `{$column}` AS expiry FROM `{$table}` WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();

        if (!$row) {
            flash('error', 'Item not found.');
            redirect('renewals');
        }

        $baseDate  = max($row['expiry'] ?? date('Y-m-d'), date('Y-m-d'));
        $newExpiry = date('Y-m-d', strtotime("{$baseDate} +{$months} months"));

        $update = $db->prepare("UPDATE `{$table}` SET `{$column}` = ?, `status` = IF(`status` = 'expired', 'active', `status`) WHERE id = ?");
        // projects/hosting have different status enums; only domains use 'expired'
        if ($table !== 'domains') {
            $update = $db->prepare("UPDATE `{$table}` SET `{$column}` = ? WHERE id = ?");
        }
        $update->execute([$newExpiry, $id]);

        (new Renewal())->create([
            'user_id'    => (int) auth()['id'],
            'item_type'  => $type,
            'item_id'    => $id,
            'item_label' => (string) $row['label'],
            'old_expiry' => $row['expiry'],
            'new_expiry' => $newExpiry,
            'amount'     => max(0, (float) str_replace(',', '', $this->request->input('amount', '0') ?? '0')),
            'notes'      => mb_substr((string) $this->request->input('notes', ''), 0, 500),
        ]);

        ActivityLog::record(
            (int) auth()['id'],
            'renewal.renew',
            ucfirst($type) . " \"{$row['label']}\" renewed until {$newExpiry}",
            $this->request
        );

        flash('success', ucfirst($type) . " renewed — new expiry {$newExpiry}.");
        redirect('renewals');
    }
}
