<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Automation;
use App\Models\AutomationLog;
use App\Models\Client;

final class AutomationController extends Controller
{
    private Automation $automations;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->automations = new Automation();
    }

    public function index(): string
    {
        return $this->view('automations.index', [
            'title'       => 'AI Automation',
            'automations' => $this->automations->allWithClients(),
        ]);
    }

    public function create(): string
    {
        return $this->form(null);
    }

    public function edit(string $id): string
    {
        $automation = $this->automations->find((int) $id) ?? $this->notFound();
        return $this->form($automation);
    }

    private function form(?array $automation): string
    {
        return $this->view('automations.form', [
            'title'         => $automation ? 'Edit — ' . $automation['name'] : 'New Automation',
            'automation'    => $automation,
            'clientOptions' => (new Client())->options(),
            'errors'        => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('automations/create');
        $id = $this->automations->create($data);

        (new AutomationLog())->create([
            'automation_id' => $id,
            'level'         => 'info',
            'message'       => 'Automation created (' . $data['version'] . ').',
        ]);
        ActivityLog::record((int) auth()['id'], 'automation.create', "Created automation \"{$data['name']}\"", $this->request);
        flash('success', "Automation \"{$data['name']}\" created.");
        redirect("automations/{$id}");
    }

    public function show(string $id): string
    {
        $automation = $this->automations->findWithClient((int) $id) ?? $this->notFound();

        return $this->view('automations.show', [
            'title'      => $automation['name'],
            'automation' => $automation,
            'logs'       => (new AutomationLog())->forAutomation((int) $id),
        ]);
    }

    public function update(string $id): string
    {
        $existing = $this->automations->find((int) $id) ?? $this->notFound();
        $data = $this->validated("automations/{$id}/edit");

        $this->automations->update((int) $id, $data);

        if ($existing['version'] !== $data['version']) {
            (new AutomationLog())->create([
                'automation_id' => (int) $id,
                'level'         => 'info',
                'message'       => "Version bumped {$existing['version']} → {$data['version']}.",
            ]);
        }
        ActivityLog::record((int) auth()['id'], 'automation.update', "Updated automation \"{$data['name']}\"", $this->request);
        flash('success', 'Automation saved.');
        redirect("automations/{$id}");
    }

    public function destroy(string $id): string
    {
        $automation = $this->automations->find((int) $id) ?? $this->notFound();
        $this->automations->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'automation.delete', "Deleted automation \"{$automation['name']}\"", $this->request);
        flash('success', "Automation \"{$automation['name']}\" deleted.");
        redirect('automations');
    }

    /** Manual log entry (integrations can POST here later via webhook). */
    public function addLog(string $id): string
    {
        $this->automations->find((int) $id) ?? $this->notFound();

        $level = $this->request->input('level', 'info');
        if (!in_array($level, AutomationLog::LEVELS, true)) {
            $level = 'info';
        }
        $message = trim((string) $this->request->input('message', ''));
        if ($message === '') {
            flash('error', 'Log message cannot be empty.');
            redirect("automations/{$id}");
        }

        (new AutomationLog())->create([
            'automation_id' => (int) $id,
            'level'         => $level,
            'message'       => mb_substr($message, 0, 1000),
        ]);
        flash('success', 'Log entry added.');
        redirect("automations/{$id}");
    }

    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'name'        => 'required|min:2|max:180',
            'description' => 'max:5000',
            'webhook_url' => 'max:400',
            'version'     => 'max:20',
        ]);

        $platform = $this->request->input('platform', 'whatsapp');
        if (!in_array($platform, Automation::PLATFORMS, true)) {
            $errors['platform'] = 'Invalid platform.';
        }
        $status = $this->request->input('status', 'development');
        if (!in_array($status, Automation::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }
        $clientId = (int) ($this->request->input('client_id', '0') ?? 0);
        if ($clientId > 0 && (new Client())->find($clientId) === null) {
            $errors['client_id'] = 'Invalid client.';
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        return array_merge($values, [
            'client_id' => $clientId > 0 ? $clientId : null,
            'platform'  => $platform,
            'status'    => $status,
            'version'   => $values['version'] ?: 'v1.0',
            'prompt'    => (string) $this->request->input('prompt', ''),
            'workflow'  => (string) $this->request->input('workflow', ''),
        ]);
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
