<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Lead;
use App\Models\Project;
use App\Services\RenewalService;

final class DashboardController extends Controller
{
    public function index(): string
    {
        $clients  = new Client();
        $projects = new Project();

        // Renewal check runs on every dashboard load (no cron on shared hosting).
        $dueRenewals  = (new RenewalService())->dueCount();
        $dueFollowUps = (new Lead())->dueFollowUps();

        $stats = [
            'clients'  => ['label' => 'Clients',         'value' => $clients->count(),             'icon' => 'people',       'trend' => $clients->countByStatus('vip') . ' VIP',     'href' => 'clients'],
            'projects' => ['label' => 'Active Projects', 'value' => $projects->countActive(),      'icon' => 'kanban',       'trend' => $projects->count() . ' total',               'href' => 'projects'],
            'revenue'  => ['label' => 'Revenue',         'value' => $projects->collectedRevenue(), 'icon' => 'cash-stack',   'trend' => 'collected', 'prefix' => '₦'],
            'renewals' => ['label' => 'Due Renewals',    'value' => $dueRenewals,                  'icon' => 'arrow-repeat', 'trend' => $dueFollowUps . ' follow-ups due',           'href' => 'renewals'],
        ];

        return $this->view('dashboard.index', [
            'title'      => 'Dashboard',
            'stats'      => $stats,
            'deadlines'  => $projects->upcomingDeadlines(5),
            'activities' => (new ActivityLog())->recent(8),
        ]);
    }
}
