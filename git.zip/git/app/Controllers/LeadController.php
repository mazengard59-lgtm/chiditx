<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Lead;

final class LeadController extends Controller
{
    private Lead $leads;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->leads = new Lead();
    }

    public function index(): string
    {
        return $this->view('leads.index', [
            'title' => 'CRM — Leads',
            'leads' => $this->leads->pipeline(),
        ]);
    }

    public function create(): string
    {
        return $this->form(null);
    }

    public function edit(string $id): string
    {
        $lead = $this->leads->find((int) $id) ?? $this->notFound();
        return $this->form($lead);
    }

    private function form(?array $lead): string
    {
        return $this->view('leads.form', [
            'title'  => $lead ? 'Edit Lead — ' . $lead['name'] : 'New Lead',
            'lead'   => $lead,
            'errors' => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('crm/create');
        $this->leads->create($data);
        ActivityLog::record((int) auth()['id'], 'lead.create', "Added lead \"{$data['name']}\"", $this->request);
        flash('success', "Lead \"{$data['name']}\" added.");
        redirect('crm');
    }

    public function update(string $id): string
    {
        $this->leads->find((int) $id) ?? $this->notFound();
        $data = $this->validated("crm/{$id}/edit");
        $this->leads->update((int) $id, $data);
        ActivityLog::record((int) auth()['id'], 'lead.update', "Updated lead \"{$data['name']}\"", $this->request);
        flash('success', 'Lead updated.');
        redirect('crm');
    }

    public function destroy(string $id): string
    {
        $lead = $this->leads->find((int) $id) ?? $this->notFound();
        $this->leads->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'lead.delete', "Deleted lead \"{$lead['name']}\"", $this->request);
        flash('success', "Lead \"{$lead['name']}\" deleted.");
        redirect('crm');
    }

    /** Convert a lead into a client and mark it won. */
    public function convert(string $id): string
    {
        $lead = $this->leads->find((int) $id) ?? $this->notFound();

        if ($lead['converted_client_id'] !== null) {
            flash('error', 'This lead was already converted.');
            redirect('crm');
        }

        $clientId = (new Client())->create([
            'name'     => $lead['name'],
            'company'  => $lead['company'],
            'email'    => $lead['email'],
            'phone'    => $lead['phone'],
            'whatsapp' => $lead['whatsapp'],
            'notes'    => "Converted from CRM lead (source: {$lead['source']}).\n" . ($lead['notes'] ?? ''),
            'status'   => 'regular',
        ]);

        $this->leads->update((int) $id, [
            'status'              => 'won',
            'converted_client_id' => $clientId,
        ]);

        ActivityLog::record((int) auth()['id'], 'lead.convert', "Converted lead \"{$lead['name']}\" to client", $this->request);
        flash('success', "Lead converted — \"{$lead['name']}\" is now a client.");
        redirect("clients/{$clientId}");
    }

    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'name'     => 'required|min:2|max:120',
            'company'  => 'max:150',
            'email'    => 'email|max:190',
            'phone'    => 'max:30',
            'whatsapp' => 'max:30',
            'services' => 'max:300',
            'notes'    => 'max:5000',
        ]);

        $source = $this->request->input('source', 'website');
        if (!in_array($source, Lead::SOURCES, true)) {
            $errors['source'] = 'Invalid source.';
        }
        $status = $this->request->input('status', 'new');
        if (!in_array($status, Lead::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }

        $dates = [];
        foreach (['last_contact_at', 'follow_up_at'] as $field) {
            $raw = $this->request->input($field, '');
            if ($raw === '' || $raw === null) {
                $dates[$field] = null;
            } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) {
                $dates[$field] = $raw;
            } else {
                $errors[$field] = 'Use the date picker (YYYY-MM-DD).';
            }
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        return array_merge($values, $dates, [
            'source' => $source,
            'status' => $status,
            'score'  => max(0, min(100, (int) ($this->request->input('score', '50') ?? 50))),
        ]);
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
