<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Project;

final class AnalyticsController extends Controller
{
    public function index(): string
    {
        $db = Database::connection();

        // Last 12 month labels (YYYY-MM)
        $months = [];
        for ($i = 11; $i >= 0; $i--) {
            $months[] = date('Y-m', strtotime("first day of -{$i} months"));
        }

        // Revenue: invoice payments + logged renewal amounts, per month
        $paymentTotals = (new Payment())->monthlyTotals(12);
        $renewalStmt = $db->query(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, SUM(amount) AS total
             FROM renewals WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
             GROUP BY ym"
        );
        $renewalTotals = [];
        foreach ($renewalStmt->fetchAll() as $row) {
            $renewalTotals[$row['ym']] = (float) $row['total'];
        }

        $revenueSeries = array_map(
            static fn($m) => round(($paymentTotals[$m] ?? 0) + ($renewalTotals[$m] ?? 0), 2),
            $months
        );

        // New clients per month
        $clientStmt = $db->query(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, COUNT(*) AS n
             FROM clients WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
             GROUP BY ym"
        );
        $clientCounts = [];
        foreach ($clientStmt->fetchAll() as $row) {
            $clientCounts[$row['ym']] = (int) $row['n'];
        }
        $clientSeries = array_map(static fn($m) => $clientCounts[$m] ?? 0, $months);

        // Projects by status
        $projectRows = $db->query(
            'SELECT status, COUNT(*) AS n FROM projects GROUP BY status'
        )->fetchAll();

        // Leads by source
        $leadRows = $db->query(
            'SELECT source, COUNT(*) AS n FROM leads GROUP BY source'
        )->fetchAll();

        $invoices = new Invoice();

        return $this->view('analytics.index', [
            'title'  => 'Analytics',
            'chart'  => [
                'months'   => array_map(static fn($m) => date('M y', strtotime($m . '-01')), $months),
                'revenue'  => $revenueSeries,
                'clients'  => $clientSeries,
                'projects' => ['labels' => array_map(static fn($r) => label($r['status']), $projectRows),
                               'data'   => array_map(static fn($r) => (int) $r['n'], $projectRows)],
                'leads'    => ['labels' => array_map(static fn($r) => label($r['source']), $leadRows),
                               'data'   => array_map(static fn($r) => (int) $r['n'], $leadRows)],
            ],
            'totals' => [
                'revenue12m'  => array_sum($revenueSeries),
                'outstanding' => $invoices->outstandingTotal(),
                'collected'   => (new Project())->collectedRevenue(),
                'newClients'  => array_sum($clientSeries),
            ],
        ]);
    }
}
