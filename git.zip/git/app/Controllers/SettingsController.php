<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Setting;
use App\Models\User;

/**
 * Settings: agency/branding, integration API keys, user management,
 * activity log, and database backup — one tabbed page.
 */
final class SettingsController extends Controller
{
    /** Whitelisted setting keys per group — nothing else is persisted. */
    private const GROUPS = [
        'general' => [
            'agency_name', 'agency_tagline', 'agency_logo_url',
            'agency_email', 'agency_whatsapp', 'default_theme',
        ],
        'integrations' => [
            'emailjs_service_id', 'emailjs_template_id', 'emailjs_public_key',
            'cloudinary_cloud_name', 'cloudinary_upload_preset',
            'paystack_public_key', 'flutterwave_public_key', 'ga_measurement_id',
        ],
        'ai' => [
            'openai_api_key', 'claude_api_key', 'gemini_api_key',
        ],
    ];

    public function index(): string
    {
        $settings = [];
        foreach ((new Setting())->all('id ASC', 500) as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        return $this->view('settings.index', [
            'title'      => 'Settings',
            'settings'   => $settings,
            'users'      => (new User())->all('id ASC'),
            'activities' => (new ActivityLog())->recent(30),
            'tab'        => $this->request->input('tab', 'general'),
            'errors'     => Session::pull('_errors', []),
        ]);
    }

    public function save(): string
    {
        $group = $this->request->input('group', '');
        $keys  = self::GROUPS[$group] ?? null;

        if ($keys === null) {
            flash('error', 'Unknown settings group.');
            redirect('settings');
        }

        $model = new Setting();
        foreach ($keys as $key) {
            $value = $this->request->input($key);
            if ($value !== null) {
                $model->setValue($key, mb_substr(trim($value), 0, 2000));
            }
        }

        ActivityLog::record((int) auth()['id'], 'settings.save', "Updated {$group} settings", $this->request);
        flash('success', ucfirst($group) . ' settings saved.');
        redirect('settings?tab=' . $group);
    }

    /* ---------------- Users ---------------- */

    public function createUser(): string
    {
        [$values, $errors] = $this->validate([
            'name'  => 'required|min:2|max:120',
            'email' => 'required|email|max:190',
        ]);
        $role = $this->request->input('role', 'staff');
        if (!in_array($role, ['admin', 'staff'], true)) {
            $role = 'staff';
        }
        if ((new User())->findByEmail($values['email']) !== null) {
            $errors['email'] = 'A user with this email already exists.';
        }
        if ($errors !== []) {
            $this->backWithErrors('settings?tab=users', $errors);
        }

        $password = bin2hex(random_bytes(5));
        (new User())->create([
            'name'          => $values['name'],
            'email'         => mb_strtolower($values['email']),
            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
            'role'          => $role,
            'status'        => 'active',
        ]);

        ActivityLog::record((int) auth()['id'], 'user.create', "Created {$role} account for {$values['name']}", $this->request);
        flash('success', "User created. Login: {$values['email']} — Password: {$password} (share now; shown once).");
        redirect('settings?tab=users');
    }

    public function toggleUser(string $id): string
    {
        $user = (new User())->find((int) $id);
        if ($user === null) {
            flash('error', 'User not found.');
            redirect('settings?tab=users');
        }
        if ((int) $id === (int) auth()['id']) {
            flash('error', 'You cannot deactivate your own account.');
            redirect('settings?tab=users');
        }

        $newStatus = $user['status'] === 'active' ? 'inactive' : 'active';
        (new User())->update((int) $id, ['status' => $newStatus]);

        ActivityLog::record((int) auth()['id'], 'user.status', "{$user['name']} marked {$newStatus}", $this->request);
        flash('success', "{$user['name']} is now {$newStatus}.");
        redirect('settings?tab=users');
    }

    public function resetUserPassword(string $id): string
    {
        $user = (new User())->find((int) $id);
        if ($user === null) {
            flash('error', 'User not found.');
            redirect('settings?tab=users');
        }

        $password = bin2hex(random_bytes(5));
        (new User())->update((int) $id, [
            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
        ]);

        ActivityLog::record((int) auth()['id'], 'user.password_reset', "Reset password for {$user['name']}", $this->request);
        flash('success', "New password for {$user['email']}: {$password} (shown once).");
        redirect('settings?tab=users');
    }

    /* ---------------- Backup ---------------- */

    /** Stream a full SQL dump (pure PHP — InfinityFree has no mysqldump). */
    public function backup(): string
    {
        $db = Database::connection();
        $tables = $db->query('SHOW TABLES')->fetchAll(\PDO::FETCH_COLUMN);

        $dump = "-- SAMS backup " . date('Y-m-d H:i:s') . "\nSET FOREIGN_KEY_CHECKS=0;\n\n";
        foreach ($tables as $table) {
            $create = $db->query("SHOW CREATE TABLE `{$table}`")->fetch();
            $dump .= "DROP TABLE IF EXISTS `{$table}`;\n" . $create['Create Table'] . ";\n\n";

            $rows = $db->query("SELECT * FROM `{$table}`")->fetchAll();
            foreach ($rows as $row) {
                $values = array_map(
                    static fn($v) => $v === null ? 'NULL' : $db->quote((string) $v),
                    array_values($row)
                );
                $columns = '`' . implode('`, `', array_keys($row)) . '`';
                $dump .= "INSERT INTO `{$table}` ({$columns}) VALUES (" . implode(', ', $values) . ");\n";
            }
            $dump .= "\n";
        }
        $dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

        ActivityLog::record((int) auth()['id'], 'backup.download', 'Downloaded database backup', $this->request);

        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="sams-backup-' . date('Ymd-His') . '.sql"');
        header('Content-Length: ' . strlen($dump));
        return $dump;
    }
}
