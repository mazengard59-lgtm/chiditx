<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Domain;
use App\Models\HostingAccount;

final class DomainController extends Controller
{
    private Domain $domains;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->domains = new Domain();
    }

    public function index(): string
    {
        return $this->view('domains.index', [
            'title'   => 'Domains',
            'domains' => $this->domains->allWithRelations(),
        ]);
    }

    public function create(): string
    {
        return $this->form(null);
    }

    public function edit(string $id): string
    {
        $domain = $this->domains->find((int) $id) ?? $this->notFound();
        return $this->form($domain);
    }

    private function form(?array $domain): string
    {
        return $this->view('domains.form', [
            'title'          => $domain ? 'Edit — ' . $domain['domain_name'] : 'New Domain',
            'domain'         => $domain,
            'clientOptions'  => (new Client())->options(),
            'hostingOptions' => (new HostingAccount())->options(),
            'errors'         => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('domains/create');
        $id = $this->domains->create($data);
        ActivityLog::record((int) auth()['id'], 'domain.create', "Added domain {$data['domain_name']}", $this->request);
        flash('success', "Domain {$data['domain_name']} added.");
        redirect('domains');
    }

    public function update(string $id): string
    {
        $this->domains->find((int) $id) ?? $this->notFound();
        $data = $this->validated("domains/{$id}/edit");
        $this->domains->update((int) $id, $data);
        ActivityLog::record((int) auth()['id'], 'domain.update', "Updated domain {$data['domain_name']}", $this->request);
        flash('success', 'Domain updated.');
        redirect('domains');
    }

    public function destroy(string $id): string
    {
        $domain = $this->domains->find((int) $id) ?? $this->notFound();
        $this->domains->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'domain.delete', "Deleted domain {$domain['domain_name']}", $this->request);
        flash('success', "Domain {$domain['domain_name']} deleted.");
        redirect('domains');
    }

    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'domain_name' => 'required|min:3|max:190',
            'registrar'   => 'max:120',
            'nameservers' => 'max:300',
            'notes'       => 'max:5000',
        ]);

        $status = $this->request->input('status', 'active');
        if (!in_array($status, Domain::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }

        $refs = [];
        foreach (['client_id' => Client::class, 'hosting_id' => HostingAccount::class] as $field => $model) {
            $raw = (int) ($this->request->input($field, '0') ?? 0);
            if ($raw > 0 && (new $model())->find($raw) === null) {
                $errors[$field] = 'Invalid selection.';
            }
            $refs[$field] = $raw > 0 ? $raw : null;
        }

        $dates = [];
        foreach (['purchase_date', 'expiry_date', 'ssl_expiry'] as $field) {
            $raw = $this->request->input($field, '');
            if ($raw === '' || $raw === null) {
                $dates[$field] = null;
            } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) {
                $dates[$field] = $raw;
            } else {
                $errors[$field] = 'Use the date picker (YYYY-MM-DD).';
            }
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        return array_merge($values, $refs, $dates, [
            'domain_name' => mb_strtolower($values['domain_name']),
            'status'      => $status,
            'auto_renew'  => $this->request->input('auto_renew') === '1' ? 1 : 0,
        ]);
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
