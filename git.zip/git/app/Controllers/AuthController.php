<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Session;
use App\Core\View;
use App\Models\ActivityLog;

final class AuthController extends Controller
{
    /** Simple per-session brute-force throttle. */
    private const MAX_ATTEMPTS = 5;
    private const LOCKOUT_SECONDS = 300;

    public function showLogin(): string
    {
        return View::render('auth.login', [
            'errors' => Session::pull('_errors', []),
        ], null);
    }

    public function login(): string
    {
        if ($this->isLockedOut()) {
            $this->backWithErrors('login', [
                'email' => 'Too many failed attempts. Try again in a few minutes.',
            ]);
        }

        [$values, $errors] = $this->validate([
            'email'    => 'required|email|max:190',
            'password' => 'required|min:8|max:190',
        ]);

        if ($errors !== []) {
            $this->backWithErrors('login', $errors);
        }

        $user = Auth::attempt($values['email'], $values['password'], $this->request);

        if ($user === null) {
            $this->recordFailedAttempt();
            $this->backWithErrors('login', [
                'email' => 'These credentials do not match our records.',
            ]);
        }

        Session::remove('_login_attempts');
        Session::remove('_old');
        flash('success', 'Welcome back, ' . $user['name'] . '!');

        $home = $user['role'] === 'client' ? 'portal' : 'dashboard';
        $intended = Session::pull('_intended', $home);
        redirect(is_string($intended) ? $intended : $home);
    }

    public function logout(): string
    {
        $user = Auth::user();
        if ($user !== null) {
            ActivityLog::record((int) $user['id'], 'auth.logout', 'Signed out', $this->request);
        }
        Auth::logout();
        flash('success', 'You have been signed out.');
        redirect('login');
    }

    private function isLockedOut(): bool
    {
        $attempts = Session::get('_login_attempts', ['count' => 0, 'first_at' => time()]);

        if ((time() - $attempts['first_at']) > self::LOCKOUT_SECONDS) {
            Session::remove('_login_attempts');
            return false;
        }
        return $attempts['count'] >= self::MAX_ATTEMPTS;
    }

    private function recordFailedAttempt(): void
    {
        $attempts = Session::get('_login_attempts', ['count' => 0, 'first_at' => time()]);
        $attempts['count']++;
        Session::set('_login_attempts', $attempts);
    }
}
