<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\View;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Project;

final class InvoiceController extends Controller
{
    private Invoice $invoices;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->invoices = new Invoice();
    }

    public function index(): string
    {
        $this->invoices->refreshOverdue(); // no-cron lazy check

        return $this->view('invoices.index', [
            'title'       => 'Invoices',
            'invoices'    => $this->invoices->allWithClients(),
            'outstanding' => $this->invoices->outstandingTotal(),
        ]);
    }

    public function create(): string
    {
        return $this->form(null);
    }

    public function edit(string $id): string
    {
        $invoice = $this->invoices->findFull((int) $id) ?? $this->notFound();
        return $this->form($invoice);
    }

    private function form(?array $invoice): string
    {
        return $this->view('invoices.form', [
            'title'          => $invoice ? 'Edit — ' . $invoice['invoice_number'] : 'New Invoice',
            'invoice'        => $invoice,
            'clientOptions'  => (new Client())->options(),
            'projectOptions' => (new Project())->allWithClients(),
            'errors'         => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        [$data, $items] = $this->validated('invoices/create');

        $data['invoice_number'] = $this->invoices->nextNumber();
        $id = $this->invoices->create($data);
        $this->invoices->syncItems($id, $items);

        ActivityLog::record((int) auth()['id'], 'invoice.create', "Created invoice {$data['invoice_number']}", $this->request);
        flash('success', "Invoice {$data['invoice_number']} created.");
        redirect("invoices/{$id}");
    }

    public function update(string $id): string
    {
        $invoice = $this->invoices->find((int) $id) ?? $this->notFound();
        [$data, $items] = $this->validated("invoices/{$id}/edit");

        $this->invoices->update((int) $id, $data);
        $this->invoices->syncItems((int) $id, $items);

        ActivityLog::record((int) auth()['id'], 'invoice.update', "Updated invoice {$invoice['invoice_number']}", $this->request);
        flash('success', 'Invoice updated.');
        redirect("invoices/{$id}");
    }

    public function show(string $id): string
    {
        $this->invoices->refreshOverdue();
        $invoice = $this->invoices->findFull((int) $id) ?? $this->notFound();

        return $this->view('invoices.show', [
            'title'   => $invoice['invoice_number'],
            'invoice' => $invoice,
        ]);
    }

    /** Print-optimized standalone page; browser print = PDF download. */
    public function print(string $id): string
    {
        $invoice = $this->invoices->findFull((int) $id) ?? $this->notFound();
        return View::render('invoices.print', ['invoice' => $invoice], null);
    }

    public function destroy(string $id): string
    {
        $invoice = $this->invoices->find((int) $id) ?? $this->notFound();
        $this->invoices->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'invoice.delete', "Deleted invoice {$invoice['invoice_number']}", $this->request);
        flash('success', "Invoice {$invoice['invoice_number']} deleted.");
        redirect('invoices');
    }

    /** Record a payment against an invoice. */
    public function addPayment(string $id): string
    {
        $invoice = $this->invoices->find((int) $id) ?? $this->notFound();

        $amount = (float) str_replace(',', '', $this->request->input('amount', '0') ?? '0');
        $method = $this->request->input('method', 'bank_transfer');
        $paidAt = $this->request->input('paid_at', date('Y-m-d'));

        if ($amount <= 0) {
            flash('error', 'Payment amount must be greater than zero.');
            redirect("invoices/{$id}");
        }
        if (!in_array($method, Payment::METHODS, true)) {
            $method = 'other';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $paidAt)) {
            $paidAt = date('Y-m-d');
        }

        (new Payment())->create([
            'invoice_id' => (int) $id,
            'amount'     => $amount,
            'method'     => $method,
            'reference'  => mb_substr((string) $this->request->input('reference', ''), 0, 120),
            'paid_at'    => $paidAt,
            'notes'      => mb_substr((string) $this->request->input('notes', ''), 0, 500),
        ]);
        $this->invoices->recalculate((int) $id);

        ActivityLog::record((int) auth()['id'], 'invoice.payment', money($amount) . " recorded on {$invoice['invoice_number']}", $this->request);
        flash('success', 'Payment recorded.');
        redirect("invoices/{$id}");
    }

    /** @return array{0: array, 1: array} [invoice data, line items] */
    private function validated(string $backPath): array
    {
        $errors = [];

        $clientId = (int) ($this->request->input('client_id', '0') ?? 0);
        if ($clientId <= 0 || (new Client())->find($clientId) === null) {
            $errors['client_id'] = 'Choose a valid client.';
        }

        $projectId = (int) ($this->request->input('project_id', '0') ?? 0);
        if ($projectId > 0 && (new Project())->find($projectId) === null) {
            $projectId = 0;
        }

        $status = $this->request->input('status', 'pending');
        if (!in_array($status, Invoice::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }

        $dates = [];
        foreach (['issue_date', 'due_date'] as $field) {
            $raw = $this->request->input($field, '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $raw)) {
                $errors[$field] = 'Required (YYYY-MM-DD).';
            } else {
                $dates[$field] = $raw;
            }
        }

        // Line items arrive as parallel arrays: item_desc[], item_qty[], item_price[]
        $items = [];
        $descs  = (array) ($_POST['item_desc'] ?? []);
        $qtys   = (array) ($_POST['item_qty'] ?? []);
        $prices = (array) ($_POST['item_price'] ?? []);
        foreach ($descs as $i => $desc) {
            $desc = trim((string) $desc);
            if ($desc === '') {
                continue;
            }
            $items[] = [
                'description' => mb_substr($desc, 0, 300),
                'quantity'    => max(0.01, (float) str_replace(',', '', (string) ($qtys[$i] ?? 1))),
                'unit_price'  => max(0.0, (float) str_replace(',', '', (string) ($prices[$i] ?? 0))),
            ];
        }
        if ($items === []) {
            $errors['items'] = 'Add at least one line item.';
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        $data = array_merge($dates, [
            'client_id'  => $clientId,
            'project_id' => $projectId > 0 ? $projectId : null,
            'status'     => $status,
            'discount'   => max(0.0, (float) str_replace(',', '', $this->request->input('discount', '0') ?? '0')),
            'tax_rate'   => max(0.0, min(100.0, (float) ($this->request->input('tax_rate', '0') ?? 0))),
            'notes'      => mb_substr((string) $this->request->input('notes', ''), 0, 1000),
        ]);

        return [$data, $items];
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(View::render('errors.404', [], null));
    }
}
