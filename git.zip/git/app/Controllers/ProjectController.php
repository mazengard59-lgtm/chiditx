<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Project;

final class ProjectController extends Controller
{
    private Project $projects;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->projects = new Project();
    }

    public function index(): string
    {
        return $this->view('projects.index', [
            'title'    => 'Projects',
            'projects' => $this->projects->allWithClients(),
        ]);
    }

    public function create(): string
    {
        return $this->view('projects.form', [
            'title'         => 'New Project',
            'project'       => null,
            'images'        => [],
            'clientOptions' => (new Client())->options(),
            'errors'        => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        $data = $this->validated('projects/create');

        $id = $this->projects->create($data);
        $this->saveScreenshots($id);
        ActivityLog::record((int) auth()['id'], 'project.create', "Created project \"{$data['name']}\"", $this->request);

        flash('success', "Project \"{$data['name']}\" created.");
        redirect("projects/{$id}");
    }

    public function show(string $id): string
    {
        $project = $this->projects->findWithClient((int) $id) ?? $this->notFound();

        return $this->view('projects.show', [
            'title'   => $project['name'],
            'project' => $project,
        ]);
    }

    public function edit(string $id): string
    {
        $project = $this->projects->find((int) $id) ?? $this->notFound();

        return $this->view('projects.form', [
            'title'         => 'Edit — ' . $project['name'],
            'project'       => $project,
            'images'        => (new \App\Models\ProjectImage())->forProject((int) $id),
            'clientOptions' => (new Client())->options(),
            'errors'        => Session::pull('_errors', []),
        ]);
    }

    public function update(string $id): string
    {
        $project = $this->projects->find((int) $id) ?? $this->notFound();
        $data = $this->validated("projects/{$id}/edit");

        $this->projects->update((int) $id, $data);
        $this->saveScreenshots((int) $id);
        ActivityLog::record((int) auth()['id'], 'project.update', "Updated project \"{$data['name']}\"", $this->request);

        flash('success', 'Project updated.');
        redirect("projects/{$id}");
    }

    public function destroy(string $id): string
    {
        $project = $this->projects->find((int) $id) ?? $this->notFound();

        $this->projects->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'project.delete', "Deleted project \"{$project['name']}\"", $this->request);

        flash('success', "Project \"{$project['name']}\" deleted.");
        redirect('projects');
    }

    /** Shared validation for store/update. Redirects back on failure. */
    private function validated(string $backPath): array
    {
        [$values, $errors] = $this->validate([
            'name'         => 'required|min:2|max:180',
            'description'  => 'max:5000',
            'category'     => 'max:100',
            'developer'    => 'max:120',
            'github_url'   => 'max:300',
            'live_url'     => 'max:300',
            'staging_url'  => 'max:300',
            'technologies' => 'max:300',
            'notes'        => 'max:5000',
        ]);

        // Client must exist
        $clientId = (int) ($this->request->input('client_id', '0') ?? 0);
        if ($clientId <= 0 || (new Client())->find($clientId) === null) {
            $errors['client_id'] = 'Choose a valid client.';
        }

        // Enums
        $status = $this->request->input('status', 'planning');
        if (!in_array($status, Project::STATUSES, true)) {
            $errors['status'] = 'Invalid status.';
        }
        $priority = $this->request->input('priority', 'medium');
        if (!in_array($priority, Project::PRIORITIES, true)) {
            $errors['priority'] = 'Invalid priority.';
        }

        // Money & progress
        $price   = $this->numeric('price', $errors);
        $deposit = $this->numeric('deposit', $errors);
        if ($deposit > $price) {
            $errors['deposit'] = 'Deposit cannot exceed the project price.';
        }
        $progress = max(0, min(100, (int) ($this->request->input('progress', '0') ?? 0)));

        // Dates (optional, must be YYYY-MM-DD when present)
        $dates = [];
        foreach (['start_date', 'deadline', 'launch_date', 'maintenance_until', 'warranty_until'] as $field) {
            $raw = $this->request->input($field, '');
            if ($raw === '' || $raw === null) {
                $dates[$field] = null;
            } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) {
                $dates[$field] = $raw;
            } else {
                $errors[$field] = 'Use the date picker (YYYY-MM-DD).';
            }
        }

        if ($errors !== []) {
            $this->backWithErrors($backPath, $errors);
        }

        return array_merge($values, $dates, [
            'client_id' => $clientId,
            'status'    => $status,
            'priority'  => $priority,
            'price'       => $price,
            'deposit'     => $deposit,
            'progress'    => $progress,
            'is_featured' => $this->request->input('is_featured') === '1' ? 1 : 0,
        ]);
    }

    /**
     * Store all files from the multi-upload input `screenshot_files[]`
     * as showcase images (jpg/png/webp/gif, max 3 MB each).
     * Skipped files are reported via flash so a bad file never blocks the save.
     */
    private function saveScreenshots(int $projectId): void
    {
        $batch = $_FILES['screenshot_files'] ?? null;
        if (!$batch || !is_array($batch['name'])) {
            return;
        }

        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
        $dir = BASE_PATH . '/assets/uploads';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $existing = count((new \App\Models\ProjectImage())->forProject($projectId));
        $saved = 0;
        $skipped = [];

        foreach ($batch['name'] as $i => $clientName) {
            if (($batch['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            if ($batch['error'][$i] !== UPLOAD_ERR_OK || $batch['size'][$i] > 3 * 1024 * 1024) {
                $skipped[] = $clientName . ' (too large or failed)';
                continue;
            }
            // Trust the file contents, not the client-supplied name/type.
            $mime = getimagesize($batch['tmp_name'][$i])['mime'] ?? '';
            if (!isset($extensions[$mime])) {
                $skipped[] = $clientName . ' (not an image)';
                continue;
            }

            $name = 'shot-' . bin2hex(random_bytes(8)) . '.' . $extensions[$mime];
            if (!move_uploaded_file($batch['tmp_name'][$i], $dir . '/' . $name)) {
                $skipped[] = $clientName . ' (could not save)';
                continue;
            }

            (new \App\Models\ProjectImage())->create([
                'project_id' => $projectId,
                'image_url'  => 'assets/uploads/' . $name,
                'sort_order' => $existing + $saved,
            ]);
            $saved++;
        }

        if ($skipped !== []) {
            flash('error', 'Skipped: ' . implode(', ', array_slice($skipped, 0, 5)));
        }
    }

    /** Remove a showcase image (and its file when stored in uploads). */
    public function destroyImage(string $id, string $imageId): string
    {
        $this->projects->find((int) $id) ?? $this->notFound();

        $images = new \App\Models\ProjectImage();
        $image = $images->find((int) $imageId);
        if ($image === null || (int) $image['project_id'] !== (int) $id) {
            $this->notFound();
        }

        $images->delete((int) $imageId);
        // Only unlink files we manage; never touch anything outside uploads.
        if (str_starts_with($image['image_url'], 'assets/uploads/')) {
            @unlink(BASE_PATH . '/' . $image['image_url']);
        }

        flash('success', 'Image removed.');
        redirect("projects/{$id}/edit");
    }

    private function numeric(string $field, array &$errors): float
    {
        $raw = str_replace(',', '', $this->request->input($field, '0') ?? '0');
        if ($raw !== '' && !is_numeric($raw)) {
            $errors[$field] = ucfirst($field) . ' must be a number.';
            return 0.0;
        }
        return max(0.0, (float) $raw);
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
