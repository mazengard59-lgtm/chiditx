<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\View;

/** Public agency website. */
final class HomeController extends Controller
{
    public function index(): string
    {
        // The portfolio page is a complete standalone document — no layout wrapper.
        return View::render('home.index', [
            'featuredProjects' => (new \App\Models\Project())->featured(),
        ], null);
    }
}
