<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\ActivityLog;
use App\Models\Client;
use App\Models\Ticket;
use App\Models\TicketReply;

final class TicketController extends Controller
{
    private Ticket $tickets;

    public function __construct(\App\Core\Request $request)
    {
        parent::__construct($request);
        $this->tickets = new Ticket();
    }

    public function index(): string
    {
        return $this->view('tickets.index', [
            'title'   => 'Support Tickets',
            'tickets' => $this->tickets->allWithClients(),
        ]);
    }

    public function create(): string
    {
        return $this->view('tickets.form', [
            'title'         => 'New Ticket',
            'clientOptions' => (new Client())->options(),
            'errors'        => Session::pull('_errors', []),
        ]);
    }

    public function store(): string
    {
        [$values, $errors] = $this->validate(['subject' => 'required|min:3|max:200']);

        $clientId = (int) ($this->request->input('client_id', '0') ?? 0);
        if ($clientId <= 0 || (new Client())->find($clientId) === null) {
            $errors['client_id'] = 'Choose a valid client.';
        }
        $priority = $this->request->input('priority', 'medium');
        if (!in_array($priority, Ticket::PRIORITIES, true)) {
            $priority = 'medium';
        }
        $category = mb_substr((string) $this->request->input('category', 'general'), 0, 60) ?: 'general';

        if ($errors !== []) {
            $this->backWithErrors('support/create', $errors);
        }

        $id = $this->tickets->create([
            'client_id' => $clientId,
            'subject'   => $values['subject'],
            'category'  => $category,
            'priority'  => $priority,
            'status'    => 'open',
        ]);

        $message = trim((string) $this->request->input('message', ''));
        if ($message !== '') {
            (new TicketReply())->create([
                'ticket_id'   => $id,
                'user_id'     => (int) auth()['id'],
                'message'     => mb_substr($message, 0, 10000),
                'is_internal' => 0,
            ]);
        }

        ActivityLog::record((int) auth()['id'], 'ticket.create', "Opened ticket #{$id}: {$values['subject']}", $this->request);
        flash('success', "Ticket #{$id} opened.");
        redirect("support/{$id}");
    }

    public function show(string $id): string
    {
        $ticket = $this->tickets->findWithClient((int) $id) ?? $this->notFound();

        return $this->view('tickets.show', [
            'title'   => "Ticket #{$ticket['id']}",
            'ticket'  => $ticket,
            'replies' => (new TicketReply())->forTicket((int) $id),
        ]);
    }

    public function reply(string $id): string
    {
        $ticket = $this->tickets->find((int) $id) ?? $this->notFound();

        $message = trim((string) $this->request->input('message', ''));
        if ($message === '') {
            flash('error', 'Reply cannot be empty.');
            redirect("support/{$id}");
        }

        (new TicketReply())->create([
            'ticket_id'   => (int) $id,
            'user_id'     => (int) auth()['id'],
            'message'     => mb_substr($message, 0, 10000),
            'is_internal' => $this->request->input('is_internal') === '1' ? 1 : 0,
        ]);

        // Replying reopens a resolved conversation unless explicitly closed.
        if ($ticket['status'] === 'resolved') {
            $this->tickets->update((int) $id, ['status' => 'pending']);
        }

        flash('success', 'Reply added.');
        redirect("support/{$id}");
    }

    public function setStatus(string $id): string
    {
        $ticket = $this->tickets->find((int) $id) ?? $this->notFound();

        $status = $this->request->input('status', '');
        if (!in_array($status, Ticket::STATUSES, true)) {
            flash('error', 'Invalid status.');
            redirect("support/{$id}");
        }

        $this->tickets->update((int) $id, ['status' => $status]);
        ActivityLog::record((int) auth()['id'], 'ticket.status', "Ticket #{$id} marked {$status}", $this->request);
        flash('success', "Ticket marked " . label($status) . '.');
        redirect("support/{$id}");
    }

    public function destroy(string $id): string
    {
        $ticket = $this->tickets->find((int) $id) ?? $this->notFound();
        $this->tickets->delete((int) $id);
        ActivityLog::record((int) auth()['id'], 'ticket.delete', "Deleted ticket #{$id}: {$ticket['subject']}", $this->request);
        flash('success', 'Ticket deleted.');
        redirect('support');
    }

    private function notFound(): never
    {
        http_response_code(404);
        exit(\App\Core\View::render('errors.404', [], null));
    }
}
