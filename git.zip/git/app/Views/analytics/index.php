<?php
/**
 * Analytics — Chart.js, single-hue marks (validated), theme-aware.
 * @var array $chart  months/revenue/clients/projects/leads series
 * @var array $totals revenue12m, outstanding, collected, newClients
 */
?>
<div class="row g-3 mb-4">
  <?php
  $tiles = [
      ['cash-stack',   'Revenue (12 months)', money($totals['revenue12m']),  'payments + renewals'],
      ['hourglass',    'Outstanding',         money($totals['outstanding']), 'unpaid invoices'],
      ['wallet2',      'Collected (projects)', money($totals['collected']),  'deposits + completed'],
      ['person-plus',  'New clients (12 mo)', (string) $totals['newClients'], 'from CRM + direct'],
  ];
  foreach ($tiles as [$icon, $label, $value, $sub]): ?>
    <div class="col-6 col-xl-3">
      <div class="card-sams stat-card">
        <div class="stat-card__icon"><i class="bi bi-<?= $icon ?>"></i></div>
        <div>
          <div class="stat-card__value" style="font-size:22px;"><?= e($value) ?></div>
          <div class="stat-card__label"><?= e($label) ?></div>
          <span class="stat-card__trend"><?= e($sub) ?></span>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-sams p-4">
      <h5 class="mb-3"><i class="bi bi-graph-up me-2" style="color:var(--accent)"></i>Monthly revenue</h5>
      <canvas id="chartRevenue" height="220"></canvas>
    </div>
  </div>
  <div class="col-12 col-lg-5">
    <div class="card-sams p-4">
      <h5 class="mb-3"><i class="bi bi-person-plus me-2" style="color:var(--accent)"></i>New clients per month</h5>
      <canvas id="chartClients" height="220"></canvas>
    </div>
  </div>
  <div class="col-12 col-lg-6">
    <div class="card-sams p-4">
      <h5 class="mb-3"><i class="bi bi-kanban me-2" style="color:var(--accent)"></i>Projects by status</h5>
      <canvas id="chartProjects" height="200"></canvas>
    </div>
  </div>
  <div class="col-12 col-lg-6">
    <div class="card-sams p-4">
      <h5 class="mb-3"><i class="bi bi-funnel me-2" style="color:var(--accent)"></i>Leads by source</h5>
      <canvas id="chartLeads" height="200"></canvas>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
const samsChartData = <?= json_encode($chart, JSON_UNESCAPED_UNICODE) ?>;
const samsCharts = [];

function chartTokens() {
  const s = getComputedStyle(document.documentElement);
  return {
    accent: s.getPropertyValue('--accent').trim(),
    grid:   s.getPropertyValue('--border').trim(),
    ink:    s.getPropertyValue('--text-mid').trim(),
    surface:s.getPropertyValue('--surface').trim(),
  };
}

function baseOptions(t, horizontal = false, isMoney = false) {
  const money = (v) => '₦' + Number(v).toLocaleString();
  return {
    indexAxis: horizontal ? 'y' : 'x',
    responsive: true,
    plugins: {
      legend: { display: false },                       // single series — title names it
      tooltip: {
        backgroundColor: t.surface,
        titleColor: t.ink, bodyColor: t.ink,
        borderColor: t.grid, borderWidth: 1,
        callbacks: isMoney ? { label: (c) => ' ' + money(horizontal ? c.parsed.x : c.parsed.y) } : {},
      },
    },
    scales: {
      x: { grid: { color: horizontal ? t.grid : 'transparent' }, ticks: { color: t.ink, font: { size: 11 }, callback: isMoney && horizontal ? (v) => money(v) : undefined } },
      y: { grid: { color: horizontal ? 'transparent' : t.grid }, ticks: { color: t.ink, font: { size: 11 }, callback: isMoney && !horizontal ? (v) => money(v) : undefined }, beginAtZero: true },
    },
  };
}

function bar(t, id, labels, data, { horizontal = false, isMoney = false } = {}) {
  const c = new Chart(document.getElementById(id), {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: t.accent,
        borderRadius: 4,                 // rounded data-end
        borderSkipped: horizontal ? 'left' : 'bottom', // flat at the baseline
        maxBarThickness: 26,
        categoryPercentage: 0.7,
      }],
    },
    options: baseOptions(t, horizontal, isMoney),
  });
  samsCharts.push({ chart: c, horizontal, isMoney });
  return c;
}

function renderCharts() {
  const t = chartTokens();
  bar(t, 'chartRevenue', samsChartData.months, samsChartData.revenue, { isMoney: true });
  bar(t, 'chartClients', samsChartData.months, samsChartData.clients);
  bar(t, 'chartProjects', samsChartData.projects.labels, samsChartData.projects.data, { horizontal: true });
  bar(t, 'chartLeads', samsChartData.leads.labels, samsChartData.leads.data, { horizontal: true });
}

/* Re-theme charts when the mode toggles (charts don't re-read CSS vars). */
document.getElementById('themeToggle')?.addEventListener('click', () => {
  setTimeout(() => {
    const t = chartTokens();
    samsCharts.forEach(({ chart, horizontal, isMoney }) => {
      chart.data.datasets[0].backgroundColor = t.accent;
      Object.assign(chart.options, baseOptions(t, horizontal, isMoney));
      chart.update();
    });
  }, 50);
});

renderCharts();
</script>
