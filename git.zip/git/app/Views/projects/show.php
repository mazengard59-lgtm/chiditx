<?php
/**
 * Project detail.
 * @var array $project Row from Project::findWithClient()
 */
use App\Models\Project;

$balance = (float) $project['price'] - (float) $project['deposit'];
$priorityBadge = ['low' => 'muted', 'medium' => 'info', 'high' => 'warning', 'urgent' => 'danger'];
?>
<div class="page-head">
  <a href="<?= url('projects') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> All projects</a>
  <div class="d-flex gap-2">
    <a href="<?= url('projects/' . $project['id'] . '/edit') ?>" class="btn-sams"><i class="bi bi-pencil me-1"></i> Edit</a>
  </div>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-8">
    <div class="card-sams p-4 mb-3">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
        <div>
          <h3 class="mb-1"><?= e($project['name']) ?></h3>
          <a href="<?= url('clients/' . $project['client_id']) ?>" style="color:var(--text-mid); font-size:14px;">
            <i class="bi bi-person me-1"></i><?= e($project['client_name']) ?><?= $project['client_company'] ? ' — ' . e($project['client_company']) : '' ?>
          </a>
        </div>
        <div class="d-flex gap-2">
          <span class="badge-soft badge-soft--<?= Project::STATUS_COLORS[$project['status']] ?? 'muted' ?>"><?= label($project['status']) ?></span>
          <span class="badge-soft badge-soft--<?= $priorityBadge[$project['priority']] ?? 'muted' ?>"><?= e($project['priority']) ?> priority</span>
          <?php if ($project['category']): ?><span class="badge-soft badge-soft--muted"><?= e($project['category']) ?></span><?php endif; ?>
        </div>
      </div>

      <div class="d-flex align-items-center gap-3 mb-4">
        <div class="progress flex-grow-1" style="height:10px; background:var(--surface-2);">
          <div class="progress-bar" style="width:<?= (int) $project['progress'] ?>%; background:var(--accent);"></div>
        </div>
        <strong style="font-family:var(--font-mono);"><?= (int) $project['progress'] ?>%</strong>
      </div>

      <?php if ($project['description']): ?>
        <p style="color:var(--text-mid); white-space:pre-line;"><?= e($project['description']) ?></p>
      <?php endif; ?>

      <?php if ($project['technologies']): ?>
        <div class="mt-3">
          <?php foreach (array_filter(array_map('trim', explode(',', $project['technologies']))) as $tech): ?>
            <span class="badge-soft badge-soft--muted me-1"><?= e($tech) ?></span>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php
      $links = array_filter([
          'GitHub'  => $project['github_url'],
          'Live'    => $project['live_url'],
          'Staging' => $project['staging_url'],
      ]);
      if ($links !== []): ?>
        <div class="d-flex gap-2 mt-4 flex-wrap">
          <?php foreach ($links as $label => $href): ?>
            <a href="<?= e($href) ?>" target="_blank" rel="noopener" class="btn-ghost-sams">
              <i class="bi bi-<?= $label === 'GitHub' ? 'github' : 'box-arrow-up-right' ?> me-1"></i><?= $label ?>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <?php if ($project['notes']): ?>
        <hr style="border-color:var(--border);">
        <div class="page-head__sub mb-1">INTERNAL NOTES</div>
        <p style="color:var(--text-mid); font-size:13.5px; white-space:pre-line; margin:0;"><?= e($project['notes']) ?></p>
      <?php endif; ?>
    </div>

    <div class="card-sams">
      <div class="panel-header"><h5><i class="bi bi-calendar3 me-2" style="color:var(--accent)"></i>Timeline</h5></div>
      <div class="p-4 row g-3">
        <?php
        $dates = [
            ['Start',       $project['start_date'],        'play'],
            ['Deadline',    $project['deadline'],          'flag'],
            ['Launch',      $project['launch_date'],       'rocket-takeoff'],
            ['Maintenance', $project['maintenance_until'], 'wrench'],
            ['Warranty',    $project['warranty_until'],    'shield-check'],
        ];
        foreach ($dates as [$label, $date, $icon]): ?>
          <div class="col-6 col-md-4">
            <div class="page-head__sub"><i class="bi bi-<?= $icon ?> me-1"></i><?= $label ?></div>
            <div style="font-weight:600;"><?= $date ? e(date('M j, Y', strtotime($date))) : '—' ?></div>
          </div>
        <?php endforeach; ?>
        <div class="col-6 col-md-4">
          <div class="page-head__sub"><i class="bi bi-person-gear me-1"></i>Developer</div>
          <div style="font-weight:600;"><?= e($project['developer'] ?: '—') ?></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="card-sams p-4">
      <h5 class="mb-4"><i class="bi bi-cash-stack me-2" style="color:var(--accent)"></i>Commercials</h5>

      <dl class="info-list">
        <dt>Project price</dt>
        <dd style="font-size:24px; font-family:var(--font-display); font-weight:800;"><?= money($project['price']) ?></dd>

        <dt>Deposit received</dt>
        <dd style="color:var(--success); font-weight:700;"><?= money($project['deposit']) ?></dd>

        <dt>Balance due</dt>
        <dd style="color:<?= $balance > 0 ? 'var(--warning)' : 'var(--success)' ?>; font-weight:700;">
          <?= money($balance) ?>
          <?= $balance <= 0 ? '<i class="bi bi-check-circle ms-1"></i>' : '' ?>
        </dd>
      </dl>

      <?php $paidPct = (float) $project['price'] > 0 ? (int) round((float) $project['deposit'] / (float) $project['price'] * 100) : 0; ?>
      <div class="mt-3">
        <div class="d-flex justify-content-between mb-1" style="font-size:12px; color:var(--text-low);">
          <span>Payment progress</span><span style="font-family:var(--font-mono);"><?= $paidPct ?>%</span>
        </div>
        <div class="progress" style="height:8px; background:var(--surface-2);">
          <div class="progress-bar" style="width:<?= $paidPct ?>%; background:var(--success);"></div>
        </div>
      </div>
    </div>
  </div>
</div>
