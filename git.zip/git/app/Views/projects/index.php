<?php
/**
 * Projects list.
 * @var array $projects Rows from Project::allWithClients()
 */
use App\Models\Project;

$priorityBadge = ['low' => 'muted', 'medium' => 'info', 'high' => 'warning', 'urgent' => 'danger'];
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($projects) ?> project<?= count($projects) === 1 ? '' : 's' ?> total</div>
  <a href="<?= url('projects/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Project</a>
</div>

<div class="card-sams">
  <?php if ($projects === []): ?>
    <div class="empty-state">
      <i class="bi bi-kanban"></i>
      <p>No projects yet. Create your first project.</p>
      <a href="<?= url('projects/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Create Project</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Project</th>
            <th>Category</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Progress</th>
            <th>Price</th>
            <th>Deadline</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($projects as $p): ?>
            <tr>
              <td>
                <a href="<?= url('projects/' . $p['id']) ?>"><?= e($p['name']) ?></a>
                <div style="font-size:12px; color:var(--text-low);"><?= e($p['client_name']) ?></div>
              </td>
              <td><?= e($p['category'] ?? '—') ?></td>
              <td><span class="badge-soft badge-soft--<?= Project::STATUS_COLORS[$p['status']] ?? 'muted' ?>"><?= label($p['status']) ?></span></td>
              <td><span class="badge-soft badge-soft--<?= $priorityBadge[$p['priority']] ?? 'muted' ?>"><?= e($p['priority']) ?></span></td>
              <td style="min-width:110px;" data-order="<?= (int) $p['progress'] ?>">
                <div class="d-flex align-items-center gap-2">
                  <div class="progress flex-grow-1" style="height:6px; background:var(--surface-2);">
                    <div class="progress-bar" style="width:<?= (int) $p['progress'] ?>%; background:var(--accent);"></div>
                  </div>
                  <span style="font-family:var(--font-mono); font-size:11px;"><?= (int) $p['progress'] ?>%</span>
                </div>
              </td>
              <td data-order="<?= (float) $p['price'] ?>"><?= money($p['price']) ?></td>
              <td data-order="<?= e($p['deadline'] ?? '') ?>"><?= $p['deadline'] ? e(date('M j, Y', strtotime($p['deadline']))) : '—' ?></td>
              <td class="text-end" style="white-space:nowrap;">
                <a href="<?= url('projects/' . $p['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('projects/' . $p['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete project <?= e($p['name']) ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
