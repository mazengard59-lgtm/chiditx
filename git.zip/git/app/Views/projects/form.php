<?php
/**
 * Project create/edit form (shared).
 * @var array|null $project       Existing row when editing
 * @var array      $clientOptions id => label pairs
 * @var array      $errors        Validation errors keyed by field
 */
use App\Models\Project;

$editing = $project !== null;
$action  = $editing ? url('projects/' . $project['id']) : url('projects');
$value   = fn(string $f) => old($f, (string) ($project[$f] ?? ''));
$err     = fn(string $f) => isset($errors[$f])
    ? '<div class="invalid-feedback-sams">' . e($errors[$f]) . '</div>' : '';
?>
<form method="post" action="<?= $action ?>" novalidate enctype="multipart/form-data">
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4 mb-3">
        <h5 class="mb-4"><i class="bi bi-kanban me-2" style="color:var(--accent)"></i>Project details</h5>

        <div class="row g-3">
          <div class="col-md-8">
            <label for="name" class="form-label-sams">Project name *</label>
            <input type="text" id="name" name="name" value="<?= $value('name') ?>"
                   class="form-control-sams <?= isset($errors['name']) ? 'is-invalid' : '' ?>">
            <?= $err('name') ?>
          </div>
          <div class="col-md-4">
            <label for="category" class="form-label-sams">Category</label>
            <input type="text" id="category" name="category" value="<?= $value('category') ?>"
                   list="categoryList" class="form-control-sams">
            <datalist id="categoryList">
              <option value="Website"><option value="Web App"><option value="E-commerce">
              <option value="AI Automation"><option value="Fintech"><option value="Maintenance">
            </datalist>
          </div>

          <div class="col-12">
            <label for="client_id" class="form-label-sams">Client *</label>
            <select id="client_id" name="client_id"
                    class="form-control-sams <?= isset($errors['client_id']) ? 'is-invalid' : '' ?>">
              <option value="">— Choose client —</option>
              <?php $currentClient = (int) old('client_id', (string) ($project['client_id'] ?? 0)); ?>
              <?php foreach ($clientOptions as $cid => $label): ?>
                <option value="<?= $cid ?>" <?= $currentClient === $cid ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
            <?= $err('client_id') ?>
          </div>

          <div class="col-12">
            <label for="description" class="form-label-sams">Description</label>
            <textarea id="description" name="description" rows="3" class="form-control-sams"><?= $value('description') ?></textarea>
          </div>

          <div class="col-md-4">
            <label for="developer" class="form-label-sams">Developer</label>
            <input type="text" id="developer" name="developer" value="<?= old('developer', (string) ($project['developer'] ?? 'Chidi')) ?>" class="form-control-sams">
          </div>
          <div class="col-md-8">
            <label for="technologies" class="form-label-sams">Technologies (comma-separated)</label>
            <input type="text" id="technologies" name="technologies" value="<?= $value('technologies') ?>" class="form-control-sams" placeholder="PHP, MySQL, Bootstrap">
          </div>

          <?php foreach ([['github_url', 'GitHub repository'], ['live_url', 'Live URL'], ['staging_url', 'Staging URL']] as [$field, $label]): ?>
            <div class="col-md-4">
              <label for="<?= $field ?>" class="form-label-sams"><?= $label ?></label>
              <input type="url" id="<?= $field ?>" name="<?= $field ?>" value="<?= $value($field) ?>" class="form-control-sams" placeholder="https://">
            </div>
          <?php endforeach; ?>

          <div class="col-12">
            <label for="screenshot_files" class="form-label-sams">Showcase screenshots (portfolio carousel)</label>

            <?php if (($images ?? []) !== []): ?>
              <div class="d-flex flex-wrap gap-2 mb-2">
                <?php foreach ($images as $img): ?>
                  <div style="position:relative;">
                    <img src="<?= e(preg_match('#^https?://#i', $img['image_url']) ? $img['image_url'] : url($img['image_url'])) ?>"
                         alt="Screenshot" style="height:72px; aspect-ratio:16/10; object-fit:cover; border-radius:8px; border:1px solid var(--border);">
                    <button type="submit" form="delimg-<?= (int) $img['id'] ?>" title="Remove image"
                            style="position:absolute; top:-7px; right:-7px; width:22px; height:22px; border-radius:50%; border:none; background:var(--danger); color:#fff; font-size:12px; line-height:1; cursor:pointer;">
                      &times;
                    </button>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>

            <input type="file" id="screenshot_files" name="screenshot_files[]" multiple
                   accept="image/jpeg,image/png,image/webp,image/gif" class="form-control-sams">
            <div class="page-head__sub mt-1">
              Select one or more images (Ctrl-click to pick several). JPG, PNG, WebP or GIF — max 3 MB each.
              They slide as a carousel on the portfolio; visitors click to zoom.
            </div>
          </div>

          <div class="col-12">
            <label class="form-label-sams d-flex align-items-center gap-2 m-0" style="cursor:pointer;">
              <input type="checkbox" name="is_featured" value="1" class="form-check-input m-0"
                     <?= old('is_featured', (string) ($project['is_featured'] ?? '0')) === '1' ? 'checked' : '' ?>>
              Feature on portfolio — show this project (screenshot + live link) in the public Work section
            </label>
          </div>

          <div class="col-12">
            <label for="notes" class="form-label-sams">Internal notes</label>
            <textarea id="notes" name="notes" rows="3" class="form-control-sams"><?= $value('notes') ?></textarea>
          </div>
        </div>
      </div>

      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-calendar3 me-2" style="color:var(--accent)"></i>Timeline</h5>
        <div class="row g-3">
          <?php
          $dateFields = [
              ['start_date', 'Start date'], ['deadline', 'Deadline'], ['launch_date', 'Launch date'],
              ['maintenance_until', 'Maintenance until'], ['warranty_until', 'Warranty until'],
          ];
          foreach ($dateFields as [$field, $label]): ?>
            <div class="col-6 col-md-4">
              <label for="<?= $field ?>" class="form-label-sams"><?= $label ?></label>
              <input type="date" id="<?= $field ?>" name="<?= $field ?>" value="<?= $value($field) ?>"
                     class="form-control-sams <?= isset($errors[$field]) ? 'is-invalid' : '' ?>">
              <?= $err($field) ?>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4 mb-3">
        <h5 class="mb-4"><i class="bi bi-cash-stack me-2" style="color:var(--accent)"></i>Commercials</h5>

        <label for="price" class="form-label-sams">Price (₦)</label>
        <input type="number" step="0.01" min="0" id="price" name="price" value="<?= $value('price') ?>"
               class="form-control-sams mb-1 <?= isset($errors['price']) ? 'is-invalid' : '' ?>">
        <?= $err('price') ?>

        <label for="deposit" class="form-label-sams mt-3">Deposit received (₦)</label>
        <input type="number" step="0.01" min="0" id="deposit" name="deposit" value="<?= $value('deposit') ?>"
               class="form-control-sams mb-1 <?= isset($errors['deposit']) ? 'is-invalid' : '' ?>">
        <?= $err('deposit') ?>
        <div class="page-head__sub mt-2">Balance is calculated automatically.</div>
      </div>

      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-sliders me-2" style="color:var(--accent)"></i>Tracking</h5>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $currentStatus = old('status', $project['status'] ?? 'planning'); ?>
          <?php foreach (Project::STATUSES as $s): ?>
            <option value="<?= $s ?>" <?= $currentStatus === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="priority" class="form-label-sams">Priority</label>
        <select id="priority" name="priority" class="form-control-sams mb-3">
          <?php $currentPriority = old('priority', $project['priority'] ?? 'medium'); ?>
          <?php foreach (Project::PRIORITIES as $p): ?>
            <option value="<?= $p ?>" <?= $currentPriority === $p ? 'selected' : '' ?>><?= label($p) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="progress" class="form-label-sams d-flex justify-content-between">
          Progress <span id="progressVal" style="font-family:var(--font-mono);"><?= old('progress', (string) ($project['progress'] ?? 0)) ?>%</span>
        </label>
        <input type="range" id="progress" name="progress" min="0" max="100" step="5"
               value="<?= old('progress', (string) ($project['progress'] ?? 0)) ?>"
               class="form-range mb-4"
               oninput="document.getElementById('progressVal').textContent = this.value + '%'">

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save changes' : 'Create project' ?>
        </button>
        <a href="<?= $editing ? url('projects/' . $project['id']) : url('projects') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>

<?php /* Image-delete forms live OUTSIDE the main form (no nesting); thumbnails target them via form="" */ ?>
<?php foreach (($images ?? []) as $img): ?>
  <form id="delimg-<?= (int) $img['id'] ?>" method="post"
        action="<?= url('projects/' . $project['id'] . '/images/' . $img['id'] . '/delete') ?>"
        data-confirm="Remove this screenshot from the showcase?">
    <?= csrf_field() ?>
  </form>
<?php endforeach; ?>
