<?php
/**
 * Blog comment moderation.
 * @var array $comments
 */
?>
<div class="page-head">
  <a href="<?= url('posts') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> Posts</a>
  <div class="page-head__sub"><?= count($comments) ?> comment<?= count($comments) === 1 ? '' : 's' ?></div>
</div>

<div class="card-sams">
  <?php if ($comments === []): ?>
    <div class="empty-state"><i class="bi bi-chat-square-text"></i><p>No comments yet.</p></div>
  <?php else: ?>
    <?php foreach ($comments as $c): ?>
      <div class="activity-item">
        <span class="activity-item__dot" style="background:<?= $c['is_approved'] ? 'var(--success)' : 'var(--warning)' ?>;"></span>
        <div class="flex-grow-1">
          <div class="d-flex justify-content-between flex-wrap gap-2">
            <div>
              <strong style="color:var(--text-hi);"><?= e($c['name']) ?></strong>
              <span style="color:var(--text-low); font-size:12px;">on</span>
              <a href="<?= url('blog/' . $c['post_slug']) ?>" target="_blank" style="color:var(--accent); font-size:13px;"><?= e($c['post_title']) ?></a>
              <?php if (!$c['is_approved']): ?><span class="badge-soft badge-soft--warning ms-1">pending</span><?php endif; ?>
            </div>
            <div class="d-flex gap-2">
              <?php if (!$c['is_approved']): ?>
                <form method="post" action="<?= url('posts/comments/' . $c['id'] . '/ok') ?>">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Approve" style="color:var(--success);"><i class="bi bi-check-lg"></i></button>
                </form>
              <?php endif; ?>
              <form method="post" action="<?= url('posts/comments/' . $c['id'] . '/delete') ?>" data-confirm="Delete this comment?">
                <?= csrf_field() ?>
                <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
              </form>
            </div>
          </div>
          <p style="color:var(--text-mid); font-size:13.5px; margin:6px 0 0;"><?= e($c['body']) ?></p>
          <div class="activity-item__meta mt-1"><?= e($c['email'] ?? '') ?> &middot; <?= e(date('M j, Y H:i', strtotime($c['created_at']))) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
