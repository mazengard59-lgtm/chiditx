<?php
/**
 * Admin blog posts list.
 * @var array $posts
 */
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($posts) ?> post<?= count($posts) === 1 ? '' : 's' ?></div>
  <div class="d-flex gap-2">
    <a href="<?= url('posts/comments') ?>" class="btn-ghost-sams"><i class="bi bi-chat-square-text me-1"></i> Comments</a>
    <a href="<?= url('blog') ?>" target="_blank" class="btn-ghost-sams"><i class="bi bi-box-arrow-up-right me-1"></i> View blog</a>
    <a href="<?= url('posts/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Post</a>
  </div>
</div>

<div class="card-sams">
  <?php if ($posts === []): ?>
    <div class="empty-state">
      <i class="bi bi-journal-text"></i>
      <p>No posts yet. Publish articles to bring SEO traffic to your agency site.</p>
      <a href="<?= url('posts/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Write First Post</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Comments</th>
            <th>Published</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($posts as $p): ?>
            <tr>
              <td>
                <a href="<?= url('posts/' . $p['id'] . '/edit') ?>"><?= e($p['title']) ?></a>
                <div style="font-size:12px; color:var(--text-low); font-family:var(--font-mono);">/blog/<?= e($p['slug']) ?></div>
              </td>
              <td><?= e($p['category'] ?? '—') ?></td>
              <td>
                <span class="badge-soft badge-soft--<?= $p['status'] === 'published' ? 'success' : 'muted' ?>"><?= e($p['status']) ?></span>
              </td>
              <td>
                <?php if ((int) $p['pending_comments'] > 0): ?>
                  <span class="badge-soft badge-soft--warning"><?= (int) $p['pending_comments'] ?> pending</span>
                <?php else: ?>—<?php endif; ?>
              </td>
              <td data-order="<?= e($p['published_at'] ?? '') ?>" style="font-size:12.5px; color:var(--text-low);">
                <?= $p['published_at'] ? e(date('M j, Y', strtotime($p['published_at']))) : '—' ?>
              </td>
              <td class="text-end" style="white-space:nowrap;">
                <?php if ($p['status'] === 'published'): ?>
                  <a href="<?= url('blog/' . $p['slug']) ?>" target="_blank" class="icon-btn" title="View"><i class="bi bi-box-arrow-up-right"></i></a>
                <?php endif; ?>
                <a href="<?= url('posts/' . $p['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('posts/' . $p['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete post &quot;<?= e($p['title']) ?>&quot;?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
