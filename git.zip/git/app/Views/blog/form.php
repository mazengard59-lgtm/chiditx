<?php
/**
 * Post editor with Quill rich text + SEO fields.
 * @var array|null $post
 * @var array      $errors
 */
$editing = $post !== null;
$action  = $editing ? url('posts/' . $post['id']) : url('posts');
$value   = fn(string $f) => old($f, (string) ($post[$f] ?? ''));
?>
<link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet">
<style>
  /* Theme Quill to match SAMS */
  .ql-toolbar.ql-snow { border: 1px solid var(--border); border-radius: var(--radius-sm) var(--radius-sm) 0 0; background: var(--surface-2); }
  .ql-container.ql-snow { border: 1px solid var(--border); border-top: none; border-radius: 0 0 var(--radius-sm) var(--radius-sm); background: var(--surface-2); color: var(--text-hi); font-family: var(--font-body); font-size: 15px; }
  .ql-editor { min-height: 320px; }
  .ql-snow .ql-stroke { stroke: var(--text-mid); }
  .ql-snow .ql-fill { fill: var(--text-mid); }
  .ql-snow .ql-picker { color: var(--text-mid); }
  .ql-editor.ql-blank::before { color: var(--text-low); }
</style>

<form method="post" action="<?= $action ?>" novalidate id="postForm">
  <?= csrf_field() ?>
  <input type="hidden" name="body" id="bodyInput">

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4 mb-3">
        <label for="title" class="form-label-sams">Title *</label>
        <input type="text" id="title" name="title" value="<?= $value('title') ?>"
               class="form-control-sams mb-1 <?= isset($errors['title']) ? 'is-invalid' : '' ?>" style="font-size:18px; font-weight:600;">
        <?php if (isset($errors['title'])): ?><div class="invalid-feedback-sams"><?= e($errors['title']) ?></div><?php endif; ?>

        <label class="form-label-sams mt-3">Content *</label>
        <div id="editor"><?= $post['body'] ?? '' ?></div>
        <?php if (isset($errors['body'])): ?><div class="invalid-feedback-sams mt-1"><?= e($errors['body']) ?></div><?php endif; ?>

        <label for="excerpt" class="form-label-sams mt-3">Excerpt (list preview)</label>
        <textarea id="excerpt" name="excerpt" rows="2" class="form-control-sams"><?= $value('excerpt') ?></textarea>
      </div>

      <div class="card-sams p-4">
        <h5 class="mb-3"><i class="bi bi-search me-2" style="color:var(--accent)"></i>SEO</h5>
        <div class="row g-3">
          <div class="col-md-6">
            <label for="meta_title" class="form-label-sams">Meta title</label>
            <input type="text" id="meta_title" name="meta_title" value="<?= $value('meta_title') ?>" class="form-control-sams">
          </div>
          <div class="col-md-6">
            <label for="meta_description" class="form-label-sams">Meta description</label>
            <input type="text" id="meta_description" name="meta_description" value="<?= $value('meta_description') ?>" class="form-control-sams">
          </div>
        </div>
        <?php if ($editing): ?>
          <div class="page-head__sub mt-3">URL: <span style="font-family:var(--font-mono);"><?= url('blog/' . $post['slug']) ?></span> (regenerated from title on save)</div>
        <?php endif; ?>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-gear me-2" style="color:var(--accent)"></i>Publish</h5>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $currentStatus = old('status', $post['status'] ?? 'draft'); ?>
          <option value="draft" <?= $currentStatus === 'draft' ? 'selected' : '' ?>>Draft</option>
          <option value="published" <?= $currentStatus === 'published' ? 'selected' : '' ?>>Published</option>
        </select>

        <label for="category" class="form-label-sams">Category</label>
        <input type="text" id="category" name="category" value="<?= $value('category') ?>"
               list="categoryList" class="form-control-sams mb-3">
        <datalist id="categoryList">
          <option value="Web Development"><option value="AI Automation"><option value="Business">
          <option value="Tutorials"><option value="Case Studies">
        </datalist>

        <label for="tags" class="form-label-sams">Tags (comma-separated)</label>
        <input type="text" id="tags" name="tags" value="<?= $value('tags') ?>" class="form-control-sams mb-3">

        <label for="featured_image_url" class="form-label-sams">Featured image URL</label>
        <input type="url" id="featured_image_url" name="featured_image_url" value="<?= $value('featured_image_url') ?>"
               placeholder="https:// (Cloudinary in Phase 5)" class="form-control-sams mb-4">

        <button type="submit" class="btn-sams w-100 mb-2"><i class="bi bi-check-lg me-1"></i> Save post</button>
        <a href="<?= url('posts') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>

<script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
<script>
const quill = new Quill('#editor', {
  theme: 'snow',
  placeholder: 'Write your article…',
  modules: {
    toolbar: [
      [{ header: [2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      ['blockquote', 'code-block', 'link', 'image'],
      ['clean'],
    ],
  },
});
document.getElementById('postForm').addEventListener('submit', () => {
  document.getElementById('bodyInput').value = quill.root.innerHTML;
});
</script>
