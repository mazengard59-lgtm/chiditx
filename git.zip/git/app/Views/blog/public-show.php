<?php
/**
 * Public blog article with comments.
 * @var array       $post
 * @var array       $comments Approved comments
 * @var string|null $sent     '1' after successful comment submission
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($post['meta_title'] ?: $post['title']) ?> — Chidi</title>
<meta name="description" content="<?= e($post['meta_description'] ?: ($post['excerpt'] ?? '')) ?>">
<meta property="og:title" content="<?= e($post['title']) ?>">
<meta property="og:type" content="article">
<?php if ($post['featured_image_url']): ?><meta property="og:image" content="<?= e($post['featured_image_url']) ?>"><?php endif; ?>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --void:#0A0A0C; --elevated:#151417; --elevated-2:#1D1B1F; --signal-red:#E8342A;
    --text-hi:#F4F1EC; --text-mid:#B9B6BE; --text-low:#726F78;
    --border:rgba(244,241,236,0.1);
  }
  * { box-sizing:border-box; margin:0; padding:0; }
  body { background:var(--void); color:var(--text-hi); font-family:'Inter',sans-serif; line-height:1.7; }
  a { color:inherit; text-decoration:none; }
  .container { max-width:760px; margin:0 auto; padding:0 24px; }
  .nav { display:flex; justify-content:space-between; align-items:center; padding:22px 0; border-bottom:1px solid var(--border); }
  .brand { font-family:'Sora',sans-serif; font-weight:800; font-size:19px; }
  .brand .dot { color:var(--signal-red); }
  .nav a.back { font-family:'JetBrains Mono',monospace; font-size:13px; color:var(--text-mid); }
  .nav a.back:hover { color:var(--signal-red); }
  article { padding:56px 0; }
  .meta { font-family:'JetBrains Mono',monospace; font-size:12px; color:var(--text-low); margin-bottom:14px; }
  .meta .cat { color:var(--signal-red); }
  h1 { font-family:'Sora',sans-serif; font-size:clamp(28px,4.5vw,40px); line-height:1.18; margin-bottom:24px; }
  .hero-img { width:100%; border-radius:14px; margin-bottom:28px; }
  .body { color:var(--text-mid); font-size:16.5px; }
  .body h2, .body h3 { font-family:'Sora',sans-serif; color:var(--text-hi); margin:28px 0 12px; }
  .body p { margin-bottom:16px; }
  .body ul, .body ol { margin:0 0 16px 22px; }
  .body a { color:var(--signal-red); }
  .body img { max-width:100%; border-radius:10px; }
  .body blockquote { border-left:3px solid var(--signal-red); padding-left:16px; color:var(--text-low); margin-bottom:16px; }
  .body pre { background:var(--elevated); border:1px solid var(--border); border-radius:10px; padding:16px; overflow-x:auto; font-family:'JetBrains Mono',monospace; font-size:13px; margin-bottom:16px; }
  .tags { margin-top:28px; }
  .tag { display:inline-block; font-family:'JetBrains Mono',monospace; font-size:11px; background:var(--elevated-2); color:var(--text-mid); border-radius:20px; padding:4px 12px; margin:0 6px 6px 0; }
  .comments { border-top:1px solid var(--border); padding:40px 0 64px; }
  .comments h3 { font-family:'Sora',sans-serif; margin-bottom:20px; }
  .comment { background:var(--elevated); border:1px solid var(--border); border-radius:12px; padding:16px 18px; margin-bottom:12px; }
  .comment .who { font-size:13px; font-weight:600; margin-bottom:4px; }
  .comment .when { color:var(--text-low); font-size:11.5px; font-family:'JetBrains Mono',monospace; }
  .comment p { color:var(--text-mid); font-size:14px; margin-top:6px; }
  form .row2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  @media (max-width:600px){ form .row2 { grid-template-columns:1fr; } }
  input, textarea { width:100%; background:var(--elevated-2); border:1px solid var(--border); border-radius:8px; color:var(--text-hi); padding:12px 14px; font-family:'Inter',sans-serif; font-size:14px; margin-bottom:12px; }
  input:focus, textarea:focus { outline:none; border-color:var(--signal-red); }
  button { background:var(--signal-red); color:#fff; border:none; border-radius:8px; padding:12px 26px; font-weight:600; font-family:'Inter',sans-serif; cursor:pointer; }
  button:hover { background:#FF6A4D; }
  .sent { background:rgba(52,199,123,.1); border:1px solid rgba(52,199,123,.35); color:#34C77B; border-radius:8px; padding:12px 16px; font-size:13.5px; margin-bottom:16px; }
  .hp { position:absolute; left:-9999px; }
</style>
</head>
<body>
<div class="container">
  <nav class="nav">
    <a href="<?= url('/') ?>" class="brand">CHIDI<span class="dot">.</span></a>
    <a href="<?= url('blog') ?>" class="back">&larr; all articles</a>
  </nav>

  <article>
    <div class="meta">
      <?= e(date('M j, Y', strtotime($post['published_at']))) ?>
      <?= $post['category'] ? ' · <span class="cat">' . e($post['category']) . '</span>' : '' ?>
      <?= $post['author_name'] ? ' · ' . e($post['author_name']) : '' ?>
    </div>
    <h1><?= e($post['title']) ?></h1>
    <?php if ($post['featured_image_url']): ?>
      <img class="hero-img" src="<?= e($post['featured_image_url']) ?>" alt="<?= e($post['title']) ?>">
    <?php endif; ?>

    <div class="body"><?= $post['body'] /* admin-authored HTML from the CMS editor */ ?></div>

    <?php if ($post['tags']): ?>
      <div class="tags">
        <?php foreach (array_filter(array_map('trim', explode(',', $post['tags']))) as $tag): ?>
          <span class="tag"><?= e($tag) ?></span>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </article>

  <section class="comments">
    <h3>Comments (<?= count($comments) ?>)</h3>

    <?php foreach ($comments as $c): ?>
      <div class="comment">
        <div class="who"><?= e($c['name']) ?> <span class="when">· <?= e(date('M j, Y', strtotime($c['created_at']))) ?></span></div>
        <p><?= e($c['body']) ?></p>
      </div>
    <?php endforeach; ?>

    <?php if ($sent): ?>
      <div class="sent">Thanks! Your comment is awaiting moderation.</div>
    <?php endif; ?>

    <form method="post" action="<?= url('blog/' . $post['slug'] . '/comment') ?>">
      <?= csrf_field() ?>
      <div class="hp" aria-hidden="true">
        <label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
      </div>
      <div class="row2">
        <input type="text" name="name" placeholder="Your name *" required maxlength="120">
        <input type="email" name="email" placeholder="Email (not published)" maxlength="190">
      </div>
      <textarea name="body" rows="4" placeholder="Your comment *" required maxlength="2000"></textarea>
      <button type="submit">Post comment</button>
    </form>
  </section>
</div>
</body>
</html>
