<?php
/**
 * Public blog index — matches the portfolio's dark brand.
 * @var array $posts Published posts
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog — Chidi | Full-Stack Development &amp; AI Automation</title>
<meta name="description" content="Articles on web development, AI automation, and running software projects — by Chidi.">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --void:#0A0A0C; --elevated:#151417; --signal-red:#E8342A; --ember:#FF6A4D;
    --text-hi:#F4F1EC; --text-mid:#B9B6BE; --text-low:#726F78;
    --border:rgba(244,241,236,0.1);
  }
  * { box-sizing:border-box; margin:0; padding:0; }
  body { background:var(--void); color:var(--text-hi); font-family:'Inter',sans-serif; line-height:1.65; }
  a { color:inherit; text-decoration:none; }
  .container { max-width:860px; margin:0 auto; padding:0 24px; }
  .nav { display:flex; justify-content:space-between; align-items:center; padding:22px 0; border-bottom:1px solid var(--border); }
  .brand { font-family:'Sora',sans-serif; font-weight:800; font-size:19px; }
  .brand .dot { color:var(--signal-red); }
  .nav a.back { font-family:'JetBrains Mono',monospace; font-size:13px; color:var(--text-mid); }
  .nav a.back:hover { color:var(--signal-red); }
  .head { padding:64px 0 40px; }
  .eyebrow { font-family:'JetBrains Mono',monospace; font-size:13px; letter-spacing:.08em; text-transform:uppercase; color:var(--signal-red); margin-bottom:12px; }
  h1 { font-family:'Sora',sans-serif; font-size:clamp(30px,5vw,44px); line-height:1.15; }
  .card { display:block; background:var(--elevated); border:1px solid var(--border); border-radius:14px; padding:28px; margin-bottom:18px; transition:transform .25s, border-color .25s; }
  .card:hover { transform:translateY(-2px); border-color:rgba(232,52,42,.4); }
  .card .meta { font-family:'JetBrains Mono',monospace; font-size:11.5px; color:var(--text-low); margin-bottom:8px; }
  .card .meta .cat { color:var(--signal-red); }
  .card h2 { font-family:'Sora',sans-serif; font-size:22px; margin-bottom:8px; }
  .card p { color:var(--text-mid); font-size:14.5px; }
  .empty { text-align:center; color:var(--text-low); padding:80px 0; }
  footer { border-top:1px solid var(--border); margin-top:64px; padding:28px 0; color:var(--text-low); font-size:13px; text-align:center; }
</style>
</head>
<body>
<div class="container">
  <nav class="nav">
    <a href="<?= url('/') ?>" class="brand">CHIDI<span class="dot">.</span></a>
    <a href="<?= url('/') ?>" class="back">&larr; portfolio</a>
  </nav>

  <header class="head">
    <p class="eyebrow">Blog</p>
    <h1>Notes from the workshop.</h1>
  </header>

  <main>
    <?php if ($posts === []): ?>
      <div class="empty">No articles published yet — check back soon.</div>
    <?php else: ?>
      <?php foreach ($posts as $p): ?>
        <a class="card" href="<?= url('blog/' . $p['slug']) ?>">
          <div class="meta">
            <?= e(date('M j, Y', strtotime($p['published_at']))) ?>
            <?= $p['category'] ? ' · <span class="cat">' . e($p['category']) . '</span>' : '' ?>
          </div>
          <h2><?= e($p['title']) ?></h2>
          <?php if ($p['excerpt']): ?><p><?= e($p['excerpt']) ?></p><?php endif; ?>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </main>

  <footer>&copy; <?= date('Y') ?> Chidi. All rights reserved.</footer>
</div>
</body>
</html>
