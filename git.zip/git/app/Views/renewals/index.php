<?php
/**
 * Renewal Center — expiry buckets + renewal history.
 * Checks run dynamically on load (no cron on shared hosting).
 * @var array $buckets Grouped items from RenewalService::buckets()
 * @var array $history Rows from Renewal::recent()
 */
$bucketMeta = [
    'expired'   => ['Expired',        'danger',  'exclamation-octagon'],
    'within_7'  => ['Within 7 days',  'danger',  'alarm'],
    'within_15' => ['Within 15 days', 'warning', 'hourglass-split'],
    'within_30' => ['Within 30 days', 'warning', 'hourglass'],
    'within_60' => ['Within 60 days', 'info',    'calendar3'],
    'within_90' => ['Within 90 days', 'info',    'calendar4-week'],
];
$typeIcons = [
    'domain' => 'globe2', 'ssl' => 'shield-lock', 'hosting' => 'hdd-network',
    'maintenance' => 'wrench', 'warranty' => 'shield-check',
];
$total = array_sum(array_map('count', $buckets));
?>
<div class="page-head">
  <div class="page-head__sub">
    <?= $total ?> item<?= $total === 1 ? '' : 's' ?> need attention within 90 days
    &middot; checked live on every load
  </div>
</div>

<!-- Bucket summary chips -->
<div class="row g-3 mb-4">
  <?php foreach ($bucketMeta as $key => [$label, $tone, $icon]): ?>
    <div class="col-6 col-md-4 col-xl-2">
      <div class="card-sams stat-card" style="padding:16px;">
        <div class="stat-card__icon" style="width:38px;height:38px;font-size:17px; background:rgba(0,0,0,0.001);
             color:var(--<?= $tone === 'danger' ? 'danger' : ($tone === 'warning' ? 'warning' : 'info') ?>);
             background:<?= $tone === 'danger' ? 'rgba(232,52,42,0.12)' : ($tone === 'warning' ? 'rgba(245,184,77,0.12)' : 'rgba(77,159,245,0.12)') ?>;">
          <i class="bi bi-<?= $icon ?>"></i>
        </div>
        <div>
          <div class="stat-card__value" style="font-size:22px;"><?= count($buckets[$key]) ?></div>
          <div class="stat-card__label" style="font-size:11.5px;"><?= $label ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if ($total === 0): ?>
  <div class="card-sams">
    <div class="empty-state">
      <i class="bi bi-check2-circle" style="color:var(--success); opacity:1;"></i>
      <p>Nothing expiring in the next 90 days. All renewals are under control.</p>
    </div>
  </div>
<?php endif; ?>

<?php foreach ($bucketMeta as $key => [$label, $tone, $icon]): ?>
  <?php if ($buckets[$key] === []) continue; ?>
  <div class="card-sams mb-3">
    <div class="panel-header">
      <h5>
        <i class="bi bi-<?= $icon ?> me-2" style="color:var(--<?= $tone ?>);"></i>
        <?= $label ?>
        <span class="badge-soft badge-soft--<?= $tone ?> ms-2"><?= count($buckets[$key]) ?></span>
      </h5>
    </div>
    <div class="table-wrap">
      <table class="table-sams w-100">
        <tbody>
          <?php foreach ($buckets[$key] as $item):
              [$color, , $daysLabel] = expiry_tone($item['days']);
          ?>
            <tr>
              <td style="width:42px;"><i class="bi bi-<?= $typeIcons[$item['type']] ?? 'dot' ?>" style="font-size:17px; color:<?= $color ?>;"></i></td>
              <td>
                <strong style="color:var(--text-hi);"><?= e($item['label']) ?></strong>
                <div style="font-size:12px; color:var(--text-low);">
                  <?= label($item['type']) ?><?= $item['client_name'] ? ' · ' . e($item['client_name']) : '' ?>
                </div>
              </td>
              <td>
                <?= e(date('M j, Y', strtotime($item['expiry']))) ?>
                <div><span style="font-family:var(--font-mono); font-size:11.5px; color:<?= $color ?>;"><?= $daysLabel ?></span></div>
              </td>
              <td class="text-end" style="white-space:nowrap;">
                <?php if ($item['whatsapp']): ?>
                  <a class="icon-btn" title="WhatsApp client" target="_blank" rel="noopener"
                     href="https://wa.me/<?= e(preg_replace('/\D/', '', $item['whatsapp'])) ?>?text=<?= rawurlencode("Hello! A friendly reminder from " . config('agency') . ": \"{$item['label']}\" expires on {$item['expiry']}. Shall we proceed with the renewal?") ?>">
                    <i class="bi bi-whatsapp"></i>
                  </a>
                <?php endif; ?>
                <?php if (!empty($item['client_email'])): ?>
                  <button type="button" class="icon-btn" title="Email reminder"
                          onclick="samsEmailReminder('<?= e($item['client_email']) ?>', '<?= e(addslashes($item['client_name'] ?? '')) ?>', '<?= e(addslashes($item['label'])) ?>', '<?= e($item['expiry']) ?>')">
                    <i class="bi bi-envelope"></i>
                  </button>
                <?php endif; ?>
                <?php if ($item['client_id']): ?>
                  <a href="<?= url('clients/' . $item['client_id']) ?>" class="icon-btn" title="View client"><i class="bi bi-person"></i></a>
                <?php endif; ?>
                <button type="button" class="btn-sams" style="padding:7px 14px; font-size:12.5px;"
                        onclick="samsRenew('<?= e($item['type']) ?>', <?= (int) $item['id'] ?>, '<?= e(addslashes($item['label'])) ?>')">
                  <i class="bi bi-arrow-repeat me-1"></i>Renew
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endforeach; ?>

<!-- Renewal history -->
<div class="card-sams mt-4">
  <div class="panel-header">
    <h5><i class="bi bi-clock-history me-2" style="color:var(--accent)"></i>Renewal History</h5>
  </div>
  <?php if ($history === []): ?>
    <div class="empty-state">
      <i class="bi bi-clock-history"></i>
      <p>No renewals recorded yet.</p>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams w-100">
        <thead>
          <tr><th>Item</th><th>Type</th><th>Old expiry</th><th>New expiry</th><th>Amount</th><th>By</th><th>When</th></tr>
        </thead>
        <tbody>
          <?php foreach ($history as $r): ?>
            <tr>
              <td><strong style="color:var(--text-hi);"><?= e($r['item_label']) ?></strong></td>
              <td><span class="badge-soft badge-soft--muted"><?= e($r['item_type']) ?></span></td>
              <td><?= $r['old_expiry'] ? e(date('M j, Y', strtotime($r['old_expiry']))) : '—' ?></td>
              <td style="color:var(--success); font-weight:600;"><?= e(date('M j, Y', strtotime($r['new_expiry']))) ?></td>
              <td><?= (float) $r['amount'] > 0 ? money($r['amount']) : '—' ?></td>
              <td><?= e($r['user_name'] ?? '—') ?></td>
              <td style="font-size:12.5px; color:var(--text-low);"><?= e(date('M j, Y H:i', strtotime($r['created_at']))) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- Hidden renew form, populated by samsRenew() -->
<form method="post" action="<?= url('renewals/renew') ?>" id="renewForm" class="d-none">
  <?= csrf_field() ?>
  <input type="hidden" name="item_type" id="renewType">
  <input type="hidden" name="item_id" id="renewId">
  <input type="hidden" name="months" id="renewMonths">
  <input type="hidden" name="amount" id="renewAmount">
</form>

<?php
$emailjsReady = setting('emailjs_service_id') && setting('emailjs_template_id') && setting('emailjs_public_key');
?>
<?php if ($emailjsReady): ?>
<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
<script>emailjs.init({ publicKey: '<?= e(setting('emailjs_public_key')) ?>' });</script>
<?php endif; ?>

<script>
/* Email reminder: EmailJS when configured in Settings, mailto fallback otherwise. */
const EMAILJS_READY = <?= $emailjsReady ? 'true' : 'false' ?>;

function samsEmailReminder(email, clientName, itemLabel, expiry) {
  const subject = 'Renewal reminder: ' + itemLabel;
  const message = 'Hello ' + (clientName || 'there') + ',\n\n"' + itemLabel + '" expires on ' + expiry +
    '. Please get in touch to renew and avoid any downtime.\n\n— <?= e(config('agency')) ?>';

  if (!EMAILJS_READY) {
    location.href = 'mailto:' + email + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(message);
    return;
  }

  const styles = getComputedStyle(document.documentElement);
  emailjs.send('<?= e(setting('emailjs_service_id')) ?>', '<?= e(setting('emailjs_template_id')) ?>', {
    to_email: email,
    to_name: clientName,
    item_label: itemLabel,
    expiry_date: expiry,
    message: message,
  }).then(
    () => Swal.fire({ icon: 'success', title: 'Reminder sent', text: 'Email delivered to ' + email,
      background: styles.getPropertyValue('--surface').trim(), color: styles.getPropertyValue('--text-hi').trim() }),
    (err) => Swal.fire({ icon: 'error', title: 'Send failed', text: String(err?.text || err),
      background: styles.getPropertyValue('--surface').trim(), color: styles.getPropertyValue('--text-hi').trim() })
  );
}

/* Renew dialog: pick extension period + optional amount, then submit. */
function samsRenew(type, id, itemLabel) {
  const styles = getComputedStyle(document.documentElement);
  Swal.fire({
    title: 'Renew ' + itemLabel,
    html:
      '<div style="text-align:left; font-size:14px;">' +
      '<label style="display:block; margin-bottom:6px;">Extend by</label>' +
      '<select id="swalMonths" class="form-control-sams" style="width:100%; margin-bottom:14px;">' +
      '<option value="1">1 month</option><option value="3">3 months</option>' +
      '<option value="6">6 months</option><option value="12" selected>1 year</option>' +
      '<option value="24">2 years</option>' +
      '</select>' +
      '<label style="display:block; margin-bottom:6px;">Amount charged (₦, optional)</label>' +
      '<input id="swalAmount" type="number" min="0" step="0.01" class="form-control-sams" style="width:100%;" placeholder="0.00">' +
      '</div>',
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'Mark renewed',
    confirmButtonColor: styles.getPropertyValue('--accent').trim() || '#E8342A',
    background: styles.getPropertyValue('--surface').trim(),
    color: styles.getPropertyValue('--text-hi').trim(),
  }).then((result) => {
    if (!result.isConfirmed) return;
    document.getElementById('renewType').value = type;
    document.getElementById('renewId').value = id;
    document.getElementById('renewMonths').value = document.getElementById('swalMonths').value;
    document.getElementById('renewAmount').value = document.getElementById('swalAmount').value || '0';
    document.getElementById('renewForm').submit();
  });
}
</script>
