<?php $user = auth(); ?>
<header class="topbar">
  <button class="icon-btn d-lg-none" id="sidebarToggle" aria-label="Toggle navigation">
    <i class="bi bi-list"></i>
  </button>

  <h1 class="topbar__title"><?= e($title ?? '') ?></h1>
  <div class="topbar__spacer"></div>

  <button class="icon-btn" id="themeToggle" aria-label="Toggle theme">
    <i class="bi bi-sun"></i>
  </button>

  <a href="<?= url('/') ?>" class="icon-btn" target="_blank" title="View public site" aria-label="View public site">
    <i class="bi bi-box-arrow-up-right"></i>
  </a>

  <?php if ($user): ?>
    <div class="topbar__user">
      <img src="<?= e(str_starts_with($user['avatar_url'] ?? '', 'http') ? $user['avatar_url'] : url($user['avatar_url'] ?? 'assets/img/chidi-photo.jpeg')) ?>"
           alt="<?= e($user['name']) ?>" class="topbar__avatar">
      <div class="d-none d-sm-block">
        <div class="topbar__user-name"><?= e($user['name']) ?></div>
        <div class="topbar__user-role"><?= e($user['role']) ?></div>
      </div>
      <form method="post" action="<?= url('logout') ?>" class="ms-1">
        <?= csrf_field() ?>
        <button type="submit" class="icon-btn" title="Sign out" aria-label="Sign out">
          <i class="bi bi-box-arrow-right"></i>
        </button>
      </form>
    </div>
  <?php endif; ?>
</header>
