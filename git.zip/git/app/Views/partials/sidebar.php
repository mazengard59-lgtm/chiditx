<?php
/**
 * Sidebar navigation. Modules from later phases render as disabled
 * entries with a phase badge, so the full product shape is visible now.
 */
$currentPath = (new App\Core\Request())->path;

$navGroups = [
    'Overview' => [
        ['icon' => 'grid-1x2', 'label' => 'Dashboard', 'path' => '/dashboard', 'phase' => null],
    ],
    'Business' => [
        ['icon' => 'people',        'label' => 'Clients',   'path' => '/clients',  'phase' => null],
        ['icon' => 'kanban',        'label' => 'Projects',  'path' => '/projects', 'phase' => null],
        ['icon' => 'globe2',        'label' => 'Domains',   'path' => '/domains',  'phase' => null],
        ['icon' => 'hdd-network',   'label' => 'Hosting',   'path' => '/hosting',  'phase' => null],
        ['icon' => 'arrow-repeat',  'label' => 'Renewals',  'path' => '/renewals', 'phase' => null],
        ['icon' => 'funnel',        'label' => 'CRM',       'path' => '/crm',      'phase' => null],
    ],
    'Operations' => [
        ['icon' => 'receipt',        'label' => 'Invoices',  'path' => '/invoices',  'phase' => null],
        ['icon' => 'life-preserver', 'label' => 'Support',   'path' => '/support',   'phase' => null],
        ['icon' => 'journal-text',   'label' => 'Blog',      'path' => '/posts',     'phase' => null],
        ['icon' => 'graph-up',       'label' => 'Analytics', 'path' => '/analytics', 'phase' => null],
    ],
    'System' => [
        ['icon' => 'robot', 'label' => 'AI Automation', 'path' => '/automations', 'phase' => null],
        ['icon' => 'gear',  'label' => 'Settings',      'path' => '/settings',    'phase' => null],
    ],
];
?>
<aside class="sidebar" id="sidebar">
  <a href="<?= url('dashboard') ?>" class="sidebar__brand">
    SAMS<span class="dot">.</span>
  </a>

  <nav class="sidebar__nav">
    <?php foreach ($navGroups as $group => $items): ?>
      <div class="sidebar__label"><?= e($group) ?></div>
      <?php foreach ($items as $item): ?>
        <?php if ($item['path'] !== null): ?>
          <a href="<?= url($item['path']) ?>"
             class="sidebar__link <?= ($currentPath === $item['path'] || str_starts_with($currentPath, $item['path'] . '/')) ? 'is-active' : '' ?>">
            <i class="bi bi-<?= e($item['icon']) ?>"></i>
            <span><?= e($item['label']) ?></span>
          </a>
        <?php else: ?>
          <span class="sidebar__link" style="opacity:.45; cursor:not-allowed;">
            <i class="bi bi-<?= e($item['icon']) ?>"></i>
            <span><?= e($item['label']) ?></span>
            <span class="badge-soon"><?= e($item['phase']) ?></span>
          </span>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php endforeach; ?>
  </nav>

  <div class="sidebar__footer">
    <?= e(config('agency')) ?> &middot; v0.1
  </div>
</aside>
