<?php
$flashes = [
    'success' => ['icon' => 'check-circle', 'class' => 'alert-sams--success'],
    'error'   => ['icon' => 'exclamation-triangle', 'class' => 'alert-sams--error'],
];
foreach ($flashes as $type => $meta):
    $message = flash($type);
    if ($message === null) continue;
?>
<div class="alert-sams <?= $meta['class'] ?> mb-3" data-flash role="alert">
  <i class="bi bi-<?= $meta['icon'] ?>"></i>
  <span><?= e($message) ?></span>
</div>
<?php endforeach; ?>
