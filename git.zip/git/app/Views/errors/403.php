<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>403 — Access Denied</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@700;800&family=Inter:wght@400;500&display=swap" rel="stylesheet">
<link href="<?= asset('css/admin.css') ?>" rel="stylesheet">
<script>document.documentElement.setAttribute('data-theme', localStorage.getItem('sams-theme') || 'dark');</script>
</head>
<body>
<div class="auth-wrap">
  <div class="text-center">
    <div style="font-family:var(--font-display); font-size:96px; font-weight:800; color:var(--accent); line-height:1;">403</div>
    <p style="color:var(--text-mid); margin:16px 0 28px;">You don't have permission to access this area.</p>
    <a href="<?= url('/') ?>" class="btn-sams" style="display:inline-block;">Back to home</a>
  </div>
</div>
</body>
</html>
