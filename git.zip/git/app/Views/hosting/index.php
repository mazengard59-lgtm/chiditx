<?php
/**
 * Hosting accounts list.
 * @var array $accounts Rows from HostingAccount::allWithClients()
 */
$statusBadge = ['active' => 'success', 'suspended' => 'warning', 'cancelled' => 'muted'];
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($accounts) ?> hosting account<?= count($accounts) === 1 ? '' : 's' ?></div>
  <a href="<?= url('hosting/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Hosting</a>
</div>

<div class="card-sams">
  <?php if ($accounts === []): ?>
    <div class="empty-state">
      <i class="bi bi-hdd-network"></i>
      <p>No hosting accounts tracked yet.</p>
      <a href="<?= url('hosting/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Add Hosting</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Provider</th>
            <th>Client</th>
            <th>Server</th>
            <th>PHP</th>
            <th>SSL</th>
            <th>Expiry</th>
            <th>Status</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($accounts as $h):
              [, $badge, $daysLabel] = expiry_tone(days_left($h['expiry_date']));
          ?>
            <tr>
              <td>
                <a href="<?= url('hosting/' . $h['id'] . '/edit') ?>"><?= e($h['provider']) ?></a>
                <div style="font-size:12px; color:var(--text-low);"><?= e($h['plan'] ?? '') ?></div>
              </td>
              <td><?= e($h['client_name'] ?? '—') ?></td>
              <td>
                <span style="font-family:var(--font-mono); font-size:12.5px;"><?= e($h['server_ip'] ?? '—') ?></span>
                <div style="font-size:12px; color:var(--text-low);"><?= e($h['disk_space'] ? $h['disk_space'] . ' / ' . ($h['bandwidth'] ?? '') : '') ?></div>
              </td>
              <td><?= e($h['php_version'] ?? '—') ?></td>
              <td>
                <i class="bi bi-<?= $h['has_ssl'] ? 'shield-check' : 'shield-x' ?>"
                   style="color:<?= $h['has_ssl'] ? 'var(--success)' : 'var(--text-low)' ?>;"></i>
              </td>
              <td data-order="<?= e($h['expiry_date'] ?? '9999') ?>">
                <div><?= $h['expiry_date'] ? e(date('M j, Y', strtotime($h['expiry_date']))) : '—' ?></div>
                <span class="badge-soft badge-soft--<?= $badge ?>"><?= $daysLabel ?></span>
              </td>
              <td><span class="badge-soft badge-soft--<?= $statusBadge[$h['status']] ?? 'muted' ?>"><?= e($h['status']) ?></span></td>
              <td class="text-end" style="white-space:nowrap;">
                <?php if ($h['control_panel_url']): ?>
                  <a href="<?= e($h['control_panel_url']) ?>" target="_blank" rel="noopener" class="icon-btn" title="Control panel"><i class="bi bi-box-arrow-up-right"></i></a>
                <?php endif; ?>
                <a href="<?= url('hosting/' . $h['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('hosting/' . $h['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete hosting account <?= e($h['provider']) ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
