<?php
/**
 * Hosting create/edit form.
 * @var array|null $account
 * @var array      $clientOptions id => label
 * @var array      $errors
 */
use App\Models\HostingAccount;

$editing = $account !== null;
$action  = $editing ? url('hosting/' . $account['id']) : url('hosting');
$value   = fn(string $f) => old($f, (string) ($account[$f] ?? ''));
$err     = fn(string $f) => isset($errors[$f])
    ? '<div class="invalid-feedback-sams">' . e($errors[$f]) . '</div>' : '';
?>
<form method="post" action="<?= $action ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-hdd-network me-2" style="color:var(--accent)"></i>Hosting details</h5>

        <div class="row g-3">
          <div class="col-md-6">
            <label for="provider" class="form-label-sams">Provider *</label>
            <input type="text" id="provider" name="provider" value="<?= $value('provider') ?>"
                   list="providerList" class="form-control-sams <?= isset($errors['provider']) ? 'is-invalid' : '' ?>">
            <datalist id="providerList">
              <option value="InfinityFree"><option value="Namecheap"><option value="Hostinger">
              <option value="Truehost"><option value="Whogohost"><option value="DigitalOcean">
            </datalist>
            <?= $err('provider') ?>
          </div>
          <div class="col-md-6">
            <label for="plan" class="form-label-sams">Plan</label>
            <input type="text" id="plan" name="plan" value="<?= $value('plan') ?>" class="form-control-sams">
          </div>

          <div class="col-md-6">
            <label for="client_id" class="form-label-sams">Client</label>
            <select id="client_id" name="client_id" class="form-control-sams <?= isset($errors['client_id']) ? 'is-invalid' : '' ?>">
              <option value="">— None / agency-owned —</option>
              <?php $currentClient = (int) old('client_id', (string) ($account['client_id'] ?? 0)); ?>
              <?php foreach ($clientOptions as $cid => $label): ?>
                <option value="<?= $cid ?>" <?= $currentClient === $cid ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
            <?= $err('client_id') ?>
          </div>
          <div class="col-md-6">
            <label for="username" class="form-label-sams">Account username</label>
            <input type="text" id="username" name="username" value="<?= $value('username') ?>" class="form-control-sams" autocomplete="off">
          </div>

          <div class="col-md-4">
            <label for="disk_space" class="form-label-sams">Disk</label>
            <input type="text" id="disk_space" name="disk_space" value="<?= $value('disk_space') ?>" placeholder="e.g. 5 GB" class="form-control-sams">
          </div>
          <div class="col-md-4">
            <label for="bandwidth" class="form-label-sams">Bandwidth</label>
            <input type="text" id="bandwidth" name="bandwidth" value="<?= $value('bandwidth') ?>" placeholder="e.g. Unlimited" class="form-control-sams">
          </div>
          <div class="col-md-4">
            <label for="php_version" class="form-label-sams">PHP version</label>
            <input type="text" id="php_version" name="php_version" value="<?= $value('php_version') ?>" placeholder="8.2" class="form-control-sams">
          </div>

          <div class="col-md-6">
            <label for="server_ip" class="form-label-sams">Server IP</label>
            <input type="text" id="server_ip" name="server_ip" value="<?= $value('server_ip') ?>" class="form-control-sams">
          </div>
          <div class="col-md-6">
            <label for="control_panel_url" class="form-label-sams">Control panel URL</label>
            <input type="url" id="control_panel_url" name="control_panel_url" value="<?= $value('control_panel_url') ?>" placeholder="https://" class="form-control-sams">
          </div>

          <div class="col-12">
            <label for="notes" class="form-label-sams">Notes</label>
            <textarea id="notes" name="notes" rows="3" class="form-control-sams"><?= $value('notes') ?></textarea>
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-calendar3 me-2" style="color:var(--accent)"></i>Expiry &amp; status</h5>

        <label for="expiry_date" class="form-label-sams">Expiry date</label>
        <input type="date" id="expiry_date" name="expiry_date" value="<?= $value('expiry_date') ?>"
               class="form-control-sams mb-3 <?= isset($errors['expiry_date']) ? 'is-invalid' : '' ?>">
        <?= $err('expiry_date') ?>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $currentStatus = old('status', $account['status'] ?? 'active'); ?>
          <?php foreach (HostingAccount::STATUSES as $s): ?>
            <option value="<?= $s ?>" <?= $currentStatus === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>

        <label class="form-label-sams d-flex align-items-center gap-2 mb-4" style="cursor:pointer;">
          <input type="checkbox" name="has_ssl" value="1" class="form-check-input m-0"
                 <?= old('has_ssl', (string) ($account['has_ssl'] ?? '0')) === '1' ? 'checked' : '' ?>>
          SSL certificate installed
        </label>

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save changes' : 'Add hosting' ?>
        </button>
        <a href="<?= url('hosting') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>
