<?php
/**
 * Domain create/edit form.
 * @var array|null $domain
 * @var array      $clientOptions  id => label
 * @var array      $hostingOptions id => label
 * @var array      $errors
 */
use App\Models\Domain;

$editing = $domain !== null;
$action  = $editing ? url('domains/' . $domain['id']) : url('domains');
$value   = fn(string $f) => old($f, (string) ($domain[$f] ?? ''));
$err     = fn(string $f) => isset($errors[$f])
    ? '<div class="invalid-feedback-sams">' . e($errors[$f]) . '</div>' : '';
?>
<form method="post" action="<?= $action ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-globe2 me-2" style="color:var(--accent)"></i>Domain details</h5>

        <div class="row g-3">
          <div class="col-md-7">
            <label for="domain_name" class="form-label-sams">Domain name *</label>
            <input type="text" id="domain_name" name="domain_name" value="<?= $value('domain_name') ?>"
                   placeholder="example.com" class="form-control-sams <?= isset($errors['domain_name']) ? 'is-invalid' : '' ?>">
            <?= $err('domain_name') ?>
          </div>
          <div class="col-md-5">
            <label for="registrar" class="form-label-sams">Registrar</label>
            <input type="text" id="registrar" name="registrar" value="<?= $value('registrar') ?>"
                   list="registrarList" class="form-control-sams">
            <datalist id="registrarList">
              <option value="Namecheap"><option value="GoDaddy"><option value="Qservers">
              <option value="Whogohost"><option value="Cloudflare"><option value="Truehost">
            </datalist>
          </div>

          <div class="col-md-6">
            <label for="client_id" class="form-label-sams">Client</label>
            <select id="client_id" name="client_id" class="form-control-sams <?= isset($errors['client_id']) ? 'is-invalid' : '' ?>">
              <option value="">— None / agency-owned —</option>
              <?php $currentClient = (int) old('client_id', (string) ($domain['client_id'] ?? 0)); ?>
              <?php foreach ($clientOptions as $cid => $label): ?>
                <option value="<?= $cid ?>" <?= $currentClient === $cid ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
            <?= $err('client_id') ?>
          </div>
          <div class="col-md-6">
            <label for="hosting_id" class="form-label-sams">Hosting account</label>
            <select id="hosting_id" name="hosting_id" class="form-control-sams">
              <option value="">— None —</option>
              <?php $currentHosting = (int) old('hosting_id', (string) ($domain['hosting_id'] ?? 0)); ?>
              <?php foreach ($hostingOptions as $hid => $label): ?>
                <option value="<?= $hid ?>" <?= $currentHosting === $hid ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-12">
            <label for="nameservers" class="form-label-sams">Nameservers (comma-separated)</label>
            <input type="text" id="nameservers" name="nameservers" value="<?= $value('nameservers') ?>"
                   placeholder="ns1.example.com, ns2.example.com" class="form-control-sams">
          </div>

          <div class="col-12">
            <label for="notes" class="form-label-sams">Notes / DNS records</label>
            <textarea id="notes" name="notes" rows="4" class="form-control-sams"><?= $value('notes') ?></textarea>
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-calendar3 me-2" style="color:var(--accent)"></i>Dates &amp; status</h5>

        <?php foreach ([['purchase_date', 'Purchase date'], ['expiry_date', 'Expiry date'], ['ssl_expiry', 'SSL expiry']] as [$field, $label]): ?>
          <label for="<?= $field ?>" class="form-label-sams"><?= $label ?></label>
          <input type="date" id="<?= $field ?>" name="<?= $field ?>" value="<?= $value($field) ?>"
                 class="form-control-sams mb-3 <?= isset($errors[$field]) ? 'is-invalid' : '' ?>">
          <?= $err($field) ?>
        <?php endforeach; ?>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $currentStatus = old('status', $domain['status'] ?? 'active'); ?>
          <?php foreach (Domain::STATUSES as $s): ?>
            <option value="<?= $s ?>" <?= $currentStatus === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>

        <label class="form-label-sams d-flex align-items-center gap-2 mb-4" style="cursor:pointer;">
          <input type="checkbox" name="auto_renew" value="1" class="form-check-input m-0"
                 <?= old('auto_renew', (string) ($domain['auto_renew'] ?? '0')) === '1' ? 'checked' : '' ?>>
          Auto-renew enabled at registrar
        </label>

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save changes' : 'Add domain' ?>
        </button>
        <a href="<?= url('domains') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>
