<?php
/**
 * Domains list with expiry color indicators.
 * @var array $domains Rows from Domain::allWithRelations()
 */
$statusBadge = ['active' => 'success', 'expired' => 'danger', 'transferred' => 'muted', 'cancelled' => 'muted'];
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($domains) ?> domain<?= count($domains) === 1 ? '' : 's' ?> tracked</div>
  <a href="<?= url('domains/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Domain</a>
</div>

<div class="card-sams">
  <?php if ($domains === []): ?>
    <div class="empty-state">
      <i class="bi bi-globe2"></i>
      <p>No domains tracked yet.</p>
      <a href="<?= url('domains/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Add Domain</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Domain</th>
            <th>Client</th>
            <th>Registrar</th>
            <th>Expiry</th>
            <th>SSL</th>
            <th>Auto-renew</th>
            <th>Status</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($domains as $d):
              [$tone, $badge, $daysLabel] = expiry_tone(days_left($d['expiry_date']));
              [, $sslBadge, $sslLabel]    = expiry_tone(days_left($d['ssl_expiry']));
          ?>
            <tr>
              <td>
                <a href="<?= url('domains/' . $d['id'] . '/edit') ?>"><?= e($d['domain_name']) ?></a>
                <div style="font-size:12px; color:var(--text-low);"><?= e($d['hosting_provider'] ?? '') ?></div>
              </td>
              <td><?= e($d['client_name'] ?? '—') ?></td>
              <td><?= e($d['registrar'] ?? '—') ?></td>
              <td data-order="<?= e($d['expiry_date'] ?? '9999') ?>">
                <div><?= $d['expiry_date'] ? e(date('M j, Y', strtotime($d['expiry_date']))) : '—' ?></div>
                <span class="badge-soft badge-soft--<?= $badge ?>"><?= $daysLabel ?></span>
              </td>
              <td data-order="<?= e($d['ssl_expiry'] ?? '9999') ?>">
                <?php if ($d['ssl_expiry']): ?>
                  <span class="badge-soft badge-soft--<?= $sslBadge ?>"><?= $sslLabel ?></span>
                <?php else: ?>—<?php endif; ?>
              </td>
              <td>
                <i class="bi bi-<?= $d['auto_renew'] ? 'check-circle-fill' : 'x-circle' ?>"
                   style="color:<?= $d['auto_renew'] ? 'var(--success)' : 'var(--text-low)' ?>;"></i>
              </td>
              <td><span class="badge-soft badge-soft--<?= $statusBadge[$d['status']] ?? 'muted' ?>"><?= e($d['status']) ?></span></td>
              <td class="text-end" style="white-space:nowrap;">
                <a href="<?= url('domains/' . $d['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('domains/' . $d['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete <?= e($d['domain_name']) ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
