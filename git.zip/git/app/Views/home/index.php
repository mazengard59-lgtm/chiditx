<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chidi — Director &amp; Full-Stack Developer | AI Automation Engineer</title>
<meta name="description" content="Chidi — Director and Senior Full-Stack Developer with 8+ years of experience building web platforms and AI automation systems.">

<meta property="og:title" content="Chidi — Director & Full-Stack Developer">
<meta property="og:description" content="Senior Full-Stack Developer & AI Automation Engineer. 8+ years building products that ship.">
<meta property="og:type" content="website">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

<style>
/* ==========================================================
   TOKENS
   ========================================================== */
:root {
  --void:        #0A0A0C;
  --elevated:    #151417;
  --elevated-2:  #1D1B1F;
  --signal-red:  #E8342A;
  --deep-red:    #7A1710;
  --ember:       #FF6A4D;
  --text-hi:     #F4F1EC;
  --text-mid:    #B9B6BE;
  --text-low:    #726F78;
  --border:      rgba(244, 241, 236, 0.1);

  --font-display: 'Sora', sans-serif;
  --font-body: 'Inter', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;

  --space-1: 8px;  --space-2: 16px; --space-3: 24px;
  --space-4: 32px; --space-5: 48px; --space-6: 64px;
  --space-7: 96px; --space-8: 128px;

  --radius-sm: 4px;
  --radius-md: 12px;
  --ease: cubic-bezier(.16,.84,.44,1);
}

/* ==========================================================
   RESET
   ========================================================== */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body {
  background: var(--void);
  color: var(--text-hi);
  font-family: var(--font-body);
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}
img { max-width: 100%; display: block; }
a { color: inherit; text-decoration: none; }
ul { list-style: none; }
button { font-family: inherit; cursor: pointer; border: none; background: none; color: inherit; }
input, textarea { font-family: inherit; }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: 0.001ms !important; animation-iteration-count: 1 !important; transition-duration: 0.001ms !important; scroll-behavior: auto !important; }
}

.container { max-width: 1160px; margin: 0 auto; padding: 0 var(--space-4); }
.section { padding: var(--space-8) 0; position: relative; }
.eyebrow {
  font-family: var(--font-mono);
  font-size: 13px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--signal-red);
  margin-bottom: var(--space-2);
}
.section-title {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: clamp(28px, 4vw, 44px);
  line-height: 1.15;
  max-width: 14ch;
  margin-bottom: var(--space-4);
}
.body-text { color: var(--text-mid); font-size: 16px; max-width: 56ch; margin-bottom: var(--space-3); }

/* ==========================================================
   BUTTONS
   ========================================================== */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 14px 28px;
  border-radius: var(--radius-sm);
  font-family: var(--font-mono);
  font-size: 14px;
  letter-spacing: 0.02em;
  transition: transform 0.25s var(--ease), background 0.25s var(--ease), border-color .25s var(--ease);
}
.btn--primary {
  background: var(--signal-red);
  color: var(--text-hi);
}
.btn--primary:hover { transform: translateY(-2px); background: var(--ember); }
.btn--ghost {
  border: 1px solid var(--border);
  color: var(--text-hi);
}
.btn--ghost:hover { border-color: var(--signal-red); transform: translateY(-2px); }

/* ==========================================================
   NAV
   ========================================================== */
.nav {
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 100;
  background: rgba(10, 10, 12, 0.7);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid transparent;
  transition: border-color 0.3s var(--ease);
}
.nav.is-scrolled { border-color: var(--border); }
.nav__inner {
  max-width: 1160px;
  margin: 0 auto;
  padding: 18px var(--space-4);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.nav__brand {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 18px;
  letter-spacing: 0.02em;
}
.nav__dot { color: var(--signal-red); }
.nav__links {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  font-size: 14px;
}
.nav__links a { color: var(--text-mid); transition: color 0.2s; position: relative; }
.nav__links a:hover, .nav__links a.is-active { color: var(--text-hi); }
.nav__links a.is-active::after {
  content: ''; position: absolute; left: 0; bottom: -6px;
  width: 100%; height: 2px; background: var(--signal-red);
}
.nav__cta {
  border: 1px solid var(--border);
  padding: 8px 16px;
  border-radius: var(--radius-sm);
  color: var(--text-hi) !important;
}
.nav__toggle {
  display: none;
  flex-direction: column;
  gap: 5px;
  width: 28px;
}
.nav__toggle span {
  height: 2px; width: 100%; background: var(--text-hi);
  transition: transform 0.3s var(--ease), opacity 0.3s var(--ease);
}
.nav__toggle[aria-expanded="true"] span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.nav__toggle[aria-expanded="true"] span:nth-child(2) { opacity: 0; }
.nav__toggle[aria-expanded="true"] span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

/* ==========================================================
   HERO
   ========================================================== */
.hero {
  position: relative;
  height: 100svh;
  min-height: 640px;
  display: flex;
  align-items: flex-end;
  overflow: hidden;
  width: 100%;
}
.hero__bg {
  position: absolute; inset: 0;
  z-index: 0;
}
.hero__photo {
  width: 100%; height: 100%;
  object-fit: cover;
  object-position: center 20%;
  filter: saturate(1.05) contrast(1.05);
}
.hero__scrim {
  position: absolute; inset: 0;
  background:
    linear-gradient(180deg, rgba(10,10,12,0.35) 0%, rgba(10,10,12,0.55) 55%, var(--void) 100%),
    linear-gradient(90deg, rgba(10,10,12,0.85) 0%, rgba(10,10,12,0.15) 55%, rgba(10,10,12,0.55) 100%);
}
.hero__grain {
  position: absolute; inset: 0;
  opacity: 0.05;
  mix-blend-mode: overlay;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>");
}

/* smoke layer */
.hero__smoke {
  position: absolute; inset: 0;
  z-index: 1;
  mix-blend-mode: screen;
  pointer-events: none;
}
.smoke {
  position: absolute;
  border-radius: 50%;
  filter: blur(40px);
  opacity: 0.55;
  background: radial-gradient(circle, rgba(232,52,42,0.55) 0%, rgba(122,23,16,0.25) 45%, transparent 70%);
  animation: drift 22s ease-in-out infinite;
}
.smoke--1 { width: 480px; height: 480px; top: -10%; left: -10%; animation-duration: 26s; }
.smoke--2 { width: 380px; height: 380px; bottom: -5%; left: 20%; animation-duration: 30s; animation-delay: -6s; opacity: 0.4;}
.smoke--3 { width: 520px; height: 520px; top: 20%; right: -15%; animation-duration: 34s; animation-delay: -12s; background: radial-gradient(circle, rgba(20,20,22,0.6) 0%, rgba(10,10,12,0.2) 50%, transparent 70%);}
.smoke--4 { width: 300px; height: 300px; bottom: 10%; right: 10%; animation-duration: 24s; animation-delay: -3s; opacity: 0.35; }

@keyframes drift {
  0%   { transform: translate(0, 0) scale(1); }
  33%  { transform: translate(4%, -6%) scale(1.15); }
  66%  { transform: translate(-5%, 4%) scale(0.95); }
  100% { transform: translate(0, 0) scale(1); }
}

.hero__content {
  position: relative;
  z-index: 2;
  padding: 0 var(--space-4) var(--space-8);
  max-width: 620px;
}
.hero__name {
  font-family: var(--font-display);
  font-weight: 800;
  font-size: clamp(48px, 9vw, 96px);
  line-height: 0.95;
  margin-bottom: var(--space-2);
}
.hero__role {
  font-family: var(--font-mono);
  font-size: clamp(15px, 2vw, 18px);
  color: var(--ember);
  margin-bottom: var(--space-3);
  min-height: 1.4em;
}
.terminal-prompt { color: var(--text-low); margin-right: 8px; }
.cursor { animation: blink 1s step-end infinite; color: var(--signal-red); }
@keyframes blink { 50% { opacity: 0; } }

.hero__lede {
  color: var(--text-mid);
  font-size: 17px;
  max-width: 46ch;
  margin-bottom: var(--space-4);
}
.hero__actions { display: flex; gap: var(--space-2); flex-wrap: wrap; }

.hero__scroll-cue {
  position: absolute;
  bottom: var(--space-3);
  right: var(--space-4);
  z-index: 2;
  width: 24px; height: 40px;
  border: 1px solid var(--border);
  border-radius: 20px;
  display: flex;
  justify-content: center;
  padding-top: 6px;
}
.hero__scroll-cue span {
  width: 4px; height: 8px;
  background: var(--signal-red);
  border-radius: 2px;
  animation: scrollcue 1.6s ease-in-out infinite;
}
@keyframes scrollcue { 0%,100% { transform: translateY(0); opacity: 1; } 50% { transform: translateY(10px); opacity: 0.3; } }

/* ==========================================================
   ABOUT
   ========================================================== */
.about__grid {
  display: grid;
  grid-template-columns: 1.4fr 1fr;
  gap: var(--space-6);
  align-items: start;
}
.about__stats {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  border-left: 1px solid var(--border);
  padding-left: var(--space-4);
}
.stat { display: flex; flex-direction: column; }
.stat__num, .stat__suffix {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 40px;
  color: var(--signal-red);
  display: inline;
}
.stat__label {
  font-size: 13px;
  color: var(--text-low);
  font-family: var(--font-mono);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-top: 4px;
}

/* ==========================================================
   SKILLS
   ========================================================== */
.skills__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: var(--space-3);
}
.skill-card {
  background: var(--elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: var(--space-4);
  transition: transform 0.3s var(--ease), border-color 0.3s var(--ease);
}
.skill-card:hover { transform: translateY(-4px); border-color: var(--signal-red); }
.skill-card--accent { background: linear-gradient(160deg, var(--elevated) 0%, var(--deep-red) 220%); }
.skill-card h3 {
  font-family: var(--font-display);
  font-size: 16px;
  margin-bottom: var(--space-2);
}
.tag-list li {
  font-size: 14px;
  color: var(--text-mid);
  padding: 6px 0;
  border-bottom: 1px dashed var(--border);
}
.tag-list li:last-child { border-bottom: none; }

/* ==========================================================
   PROJECTS
   ========================================================== */
.project-list { display: flex; flex-direction: column; gap: var(--space-3); }
.project-card {
  background: var(--elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: var(--space-5);
  transition: border-color 0.3s var(--ease), transform 0.3s var(--ease);
}
.project-card:hover { border-color: var(--signal-red); transform: translateY(-3px); }
.project-card h3 { font-family: var(--font-display); font-size: 22px; margin-bottom: 6px; }
.project-card__role {
  font-family: var(--font-mono);
  font-size: 13px;
  color: var(--signal-red);
  margin-bottom: var(--space-2);
}
.project-card__desc { color: var(--text-mid); margin-bottom: var(--space-2); max-width: 64ch; }
.project-card__outcomes li {
  font-size: 14px;
  color: var(--text-mid);
  padding-left: 18px;
  position: relative;
  margin-bottom: 4px;
}
.project-card__outcomes li::before {
  content: '→'; position: absolute; left: 0; color: var(--signal-red);
}
.project-card__tag {
  display: inline-block;
  margin-top: var(--space-2);
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--text-low);
  border: 1px solid var(--border);
  padding: 4px 10px;
  border-radius: 20px;
}

/* Featured showcase cards (screenshot + live link, managed from SAMS) */
.project-card--shot {
  display: grid;
  grid-template-columns: minmax(0, 5fr) minmax(0, 6fr);
  gap: var(--space-4);
  align-items: center;
  overflow: hidden;
}
.project-card__shot {
  position: relative;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  overflow: hidden;
  background: var(--elevated-2);
  aspect-ratio: 16 / 10;
}
.shot-track {
  display: flex;
  height: 100%;
  transition: transform .5s var(--ease);
}
.shot-slide {
  flex: 0 0 100%;
  width: 100%;
  height: 100%;
  object-fit: contain;   /* whole frame visible — never cropped */
  display: block;
  cursor: zoom-in;
}
.shot-arrow {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 34px;
  height: 34px;
  border-radius: 50%;
  border: 1px solid var(--border);
  background: rgba(10, 10, 12, .65);
  backdrop-filter: blur(6px);
  color: var(--text-hi);
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  opacity: 0;
  transition: opacity .25s var(--ease), background .2s;
  z-index: 2;
}
.shot-carousel:hover .shot-arrow { opacity: 1; }
.shot-arrow:hover { background: var(--signal-red); border-color: var(--signal-red); }
.shot-arrow--prev { left: 10px; }
.shot-arrow--next { right: 10px; }
.shot-dots {
  position: absolute;
  bottom: 10px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 6px;
  z-index: 2;
}
.shot-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  border: none;
  background: rgba(244, 241, 236, .35);
  cursor: pointer;
  padding: 0;
  transition: background .2s, transform .2s;
}
.shot-dot.is-active { background: var(--signal-red); transform: scale(1.25); }

/* Zoom lightbox */
.shot-lightbox {
  position: fixed;
  inset: 0;
  z-index: 300;
  background: rgba(5, 5, 6, .92);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  pointer-events: none;
  transition: opacity .25s var(--ease);
}
.shot-lightbox.is-open { opacity: 1; pointer-events: auto; }
.shot-lightbox img {
  max-width: 92vw;
  max-height: 86vh;
  border-radius: 10px;
  border: 1px solid var(--border);
  box-shadow: 0 24px 80px rgba(0, 0, 0, .7);
  transform: scale(.92);
  transition: transform .25s var(--ease);
  cursor: zoom-out;
}
.shot-lightbox.is-open img { transform: scale(1); }
.shot-lightbox__close {
  position: absolute;
  top: 20px;
  right: 24px;
  width: 42px;
  height: 42px;
  border-radius: 50%;
  border: 1px solid var(--border);
  background: rgba(10, 10, 12, .6);
  color: var(--text-hi);
  font-size: 22px;
  line-height: 1;
  cursor: pointer;
}
.shot-lightbox__close:hover { background: var(--signal-red); border-color: var(--signal-red); }
.project-card__tech {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin: var(--space-2) 0;
}
.project-card__tech span {
  font-family: var(--font-mono);
  font-size: 11.5px;
  color: var(--text-mid);
  background: var(--elevated-2);
  border-radius: 20px;
  padding: 3px 10px;
}
.project-card__visit {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-top: var(--space-2);
  font-family: var(--font-mono);
  font-size: 13.5px;
  color: var(--signal-red);
  transition: color .2s var(--ease), gap .25s var(--ease);
}
.project-card__visit:hover { color: var(--ember); gap: 12px; }
@media (max-width: 720px) {
  .project-card--shot { grid-template-columns: 1fr; gap: var(--space-3); }
}

/* Work section: only the first card shows until "View more" */
.project-card.project-hidden { display: none; }
.projects__more {
  display: block;
  margin: var(--space-4) auto 0;
}

/* ==========================================================
   AUTOMATION
   ========================================================== */
.automation { background: var(--elevated); }
.automation__grid {
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: var(--space-6);
}
.flow {
  display: flex;
  align-items: stretch;
  gap: var(--space-2);
  margin-top: var(--space-4);
  flex-wrap: wrap;
}
.flow__step {
  flex: 1;
  min-width: 140px;
  background: var(--void);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: var(--space-2);
}
.flow__step--accent { border-color: var(--signal-red); }
.flow__label {
  font-family: var(--font-mono);
  font-size: 11px;
  text-transform: uppercase;
  color: var(--signal-red);
  letter-spacing: 0.05em;
}
.flow__step p { font-size: 13px; color: var(--text-mid); margin-top: 4px; }
.flow__arrow { display: flex; align-items: center; color: var(--text-low); font-size: 18px; }

.automation__cases { display: flex; flex-direction: column; gap: var(--space-2); }
.case-card {
  background: var(--void);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: var(--space-3);
}
.case-card h3 { font-family: var(--font-display); font-size: 16px; margin-bottom: 6px; }
.case-card p { font-size: 14px; color: var(--text-mid); }

/* ==========================================================
   EXPERIENCE / TIMELINE
   ========================================================== */
.timeline { position: relative; padding-left: var(--space-4); }
.timeline::before {
  content: ''; position: absolute; left: 5px; top: 6px; bottom: 6px;
  width: 1px; background: var(--border);
}
.timeline__item { position: relative; padding-bottom: var(--space-5); }
.timeline__item:last-child { padding-bottom: 0; }
.timeline__dot {
  position: absolute; left: -27px; top: 4px;
  width: 11px; height: 11px; border-radius: 50%;
  background: var(--signal-red);
  box-shadow: 0 0 0 4px var(--void), 0 0 0 5px var(--border);
}
.timeline__date {
  font-family: var(--font-mono);
  font-size: 13px;
  color: var(--signal-red);
}
.timeline__content h3 { font-family: var(--font-display); font-size: 19px; margin: 6px 0; }
.timeline__content p { color: var(--text-mid); max-width: 60ch; font-size: 15px; }

/* ==========================================================
   CONTACT
   ========================================================== */
.contact__inner { max-width: 640px; }
.contact__lede { margin-bottom: var(--space-4); }
.contact-form { display: flex; flex-direction: column; gap: var(--space-3); margin-bottom: var(--space-4); }
.form-row { display: flex; flex-direction: column; gap: 6px; }
.form-row label {
  font-family: var(--font-mono);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-low);
}
.form-row input, .form-row textarea {
  background: var(--elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 12px 14px;
  color: var(--text-hi);
  font-size: 15px;
  resize: vertical;
  transition: border-color 0.2s;
}
.form-row input:focus, .form-row textarea:focus {
  outline: none;
  border-color: var(--signal-red);
}
.contact-form .btn { align-self: flex-start; }
.form-status { font-size: 14px; color: var(--text-mid); min-height: 1.2em; }
.contact__links { display: flex; gap: var(--space-3); flex-wrap: wrap; }
.social-link {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-family: var(--font-mono);
  font-size: 14px;
  color: var(--text-mid);
  border: 1px solid var(--border);
  padding: 10px 16px;
  border-radius: 20px;
  transition: color 0.2s, border-color 0.2s, transform 0.2s var(--ease);
}
.social-link svg { width: 18px; height: 18px; flex-shrink: 0; }
.social-link:hover { color: var(--signal-red); border-color: var(--signal-red); transform: translateY(-2px); }

@media (max-width: 480px) {
  .social-link span { display: none; }
  .social-link { padding: 12px; }
}

/* ==========================================================
   FOOTER
   ========================================================== */
.footer { border-top: 1px solid var(--border); padding: var(--space-4) 0; }
.footer__inner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: var(--space-2);
  font-size: 13px;
  color: var(--text-low);
}
.footer__links { display: flex; gap: var(--space-3); }
.footer__links a:hover { color: var(--signal-red); }

/* ==========================================================
   SCROLL REVEAL
   ========================================================== */
[data-reveal] {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity 0.7s var(--ease), transform 0.7s var(--ease);
}
[data-reveal].is-visible { opacity: 1; transform: translateY(0); }

/* ==========================================================
   RESPONSIVE
   ========================================================== */
@media (min-width: 1024px) {
  .hero {
    align-items: center;
    padding: 0 var(--space-7);
    gap: var(--space-7);
  }
  .hero__bg {
    position: relative;
    inset: auto;
    order: 2;
    flex-shrink: 0;
    width: min(34vw, 460px);
    height: min(64vh, 560px);
    border-radius: var(--radius-md);
    overflow: hidden;
    box-shadow: 0 30px 80px -20px rgba(0,0,0,0.6);
  }
  .hero__scrim {
    background:
      linear-gradient(180deg, rgba(10,10,12,0) 40%, rgba(10,10,12,0.5) 100%),
      linear-gradient(0deg, rgba(122,23,16,0.15), transparent 60%);
  }
  .hero__content {
    order: 1;
    padding: 0;
    max-width: 480px;
    flex-shrink: 0;
  }
  .hero__scroll-cue { right: var(--space-7); }
}

@media (max-width: 900px) {
  .about__grid, .automation__grid { grid-template-columns: 1fr; }
  .about__stats { border-left: none; border-top: 1px solid var(--border); padding-left: 0; padding-top: var(--space-3); flex-direction: row; justify-content: space-between; flex-wrap: nowrap; gap: var(--space-2); }
  .skills__grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 720px) {
  .about__stats { flex-direction: row; justify-content: space-between; flex-wrap: nowrap; gap: var(--space-1); }
  .stat { flex: 1; align-items: flex-start; }
  .stat__num, .stat__suffix { font-size: 26px; }
  .stat__label { font-size: 10px; }
  .nav__links {
    position: fixed;
    top: 64px; right: 0;
    height: calc(100svh - 64px);
    width: min(280px, 80vw);
    background: var(--elevated);
    flex-direction: column;
    align-items: flex-start;
    padding: var(--space-4);
    gap: var(--space-3);
    transform: translateX(100%);
    transition: transform 0.35s var(--ease);
    border-left: 1px solid var(--border);
  }
  .nav__links.is-open { transform: translateX(0); }
  .nav__toggle { display: flex; }
  .skills__grid { grid-template-columns: 1fr; }
  .flow { flex-direction: column; }
  .flow__arrow { transform: rotate(90deg); align-self: center; }
}

</style>
</head>
<body>

<!-- ================= NAV ================= -->
<header class="nav" id="nav">
  <div class="nav__inner">
    <a href="#home" class="nav__brand">CHIDI<span class="nav__dot">.</span></a>

    <nav class="nav__links" id="navLinks">
      <a href="#about" data-nav>About</a>
      <a href="#skills" data-nav>Skills</a>
      <a href="#projects" data-nav>Work</a>
      <a href="#automation" data-nav>Automation</a>
      <a href="#experience" data-nav>Experience</a>
      <a href="#contact" data-nav class="nav__cta">Contact</a>
    </nav>

    <button class="nav__toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<!-- ================= HERO ================= -->
<section class="hero" id="home">

  <div class="hero__bg">
    <img src="<?= asset('img/chidi-photo.jpeg') ?>" alt="Chidi, Director and Full-Stack Developer" class="hero__photo">
    <div class="hero__smoke" aria-hidden="true">
      <span class="smoke smoke--1"></span>
      <span class="smoke smoke--2"></span>
      <span class="smoke smoke--3"></span>
      <span class="smoke smoke--4"></span>
    </div>
    <div class="hero__scrim"></div>
    <div class="hero__grain" aria-hidden="true"></div>
  </div>

  <div class="hero__content">
    <p class="eyebrow">Director &middot; Full-Stack Developer</p>
    <h1 class="hero__name">Chidi</h1>
    <p class="hero__role">
      <span class="terminal-prompt">&gt;</span>
      <span class="typed" id="typedRole"></span><span class="cursor">&#9608;</span>
    </p>
    <p class="hero__lede">
      8+ years designing and shipping full-stack platforms — and lately,
      the AI automation systems that run behind them.
    </p>

    <div class="hero__actions">
      <a href="#projects" class="btn btn--primary">View Work</a>
      <a href="#contact" class="btn btn--ghost">Get in Touch</a>
    </div>
  </div>

  <a href="#about" class="hero__scroll-cue" aria-label="Scroll to about section">
    <span></span>
  </a>
</section>

<!-- ================= ABOUT ================= -->
<section class="section about" id="about">
  <div class="container about__grid">
    <div class="about__text">
      <p class="eyebrow">01 &mdash; About</p>
      <h2 class="section-title">I build the systems businesses run on.</h2>
      <p class="body-text">
        I'm Chidi — Director and Senior Full-Stack Developer with 8+ years
        of experience taking products from a blank repo to something real
        users depend on daily. My work spans full-stack web platforms,
        internal tools, and — increasingly — the AI-driven automation
        that removes the manual work behind the scenes.
      </p>
      <p class="body-text">
        I lead teams and projects end-to-end: architecture, backend,
        interface, and the automation layer that ties it all together.
        I care as much about how a product feels to use as how it holds
        up under load.
      </p>
    </div>

    <div class="about__stats">
      <div class="stat">
        <span class="stat__num" data-count="8">0</span><span class="stat__suffix">+</span>
        <span class="stat__label">Years Experience</span>
      </div>
      <div class="stat">
        <span class="stat__num" data-count="30">0</span><span class="stat__suffix">+</span>
        <span class="stat__label">Projects Shipped</span>
      </div>
      <div class="stat">
        <span class="stat__num" data-count="15">0</span><span class="stat__suffix">+</span>
        <span class="stat__label">Automation Workflows Built</span>
      </div>
    </div>
  </div>
</section>

<!-- ================= SKILLS ================= -->
<section class="section skills" id="skills">
  <div class="container">
    <p class="eyebrow">02 &mdash; Skills</p>
    <h2 class="section-title">What I work with.</h2>

    <div class="skills__grid">
      <div class="skill-card">
        <h3>Languages &amp; Frameworks</h3>
        <ul class="tag-list">
          <li>PHP</li><li>Laravel</li><li>JavaScript</li>
          <li>React</li><li>HTML5 / CSS3</li>
          <li>MySQL</li><li>Node.js</li>
        </ul>
      </div>

      <div class="skill-card skill-card--accent">
        <h3>AI &amp; Automation</h3>
        <ul class="tag-list">
          <li>LLM Integration</li><li>Workflow Automation</li>
          <li>API Orchestration</li><li>Prompt Engineering</li>
          <li>Chatbot Systems</li>
        </ul>
      </div>

      <div class="skill-card">
        <h3>Infrastructure</h3>
        <ul class="tag-list">
          <li>Firebase</li><li>WebSockets</li>
          <li>Deployment &amp; Hosting</li><li>Version Control</li>
        </ul>
      </div>

      <div class="skill-card">
        <h3>Design</h3>
        <ul class="tag-list">
          <li>UI / UX</li><li>Design Systems</li>
          <li>Responsive Design</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- ================= PROJECTS ================= -->
<section class="section projects" id="projects">
  <div class="container">
    <p class="eyebrow">03 &mdash; Selected Work</p>
    <h2 class="section-title">Things I've shipped.</h2>

    <div class="project-list">

      <?php /** @var array $featuredProjects Featured projects managed in SAMS (Projects → "Feature on portfolio") */ ?>
      <?php foreach (($featuredProjects ?? []) as $fp):
          $shots = array_map(
              static fn($img) => preg_match('#^https?://#i', $img['image_url']) ? $img['image_url'] : url($img['image_url']),
              $fp['images'] ?? []
          );
      ?>
        <article class="project-card project-card--shot">
          <?php if ($shots !== []): ?>
            <div class="project-card__shot shot-carousel" data-carousel>
              <div class="shot-track">
                <?php foreach ($shots as $i => $shot): ?>
                  <img class="shot-slide" src="<?= e($shot) ?>"
                       alt="Screenshot <?= $i + 1 ?> of <?= e($fp['name']) ?>" loading="lazy"
                       title="Click to zoom">
                <?php endforeach; ?>
              </div>
              <?php if (count($shots) > 1): ?>
                <button type="button" class="shot-arrow shot-arrow--prev" data-dir="-1" aria-label="Previous screenshot">&#8249;</button>
                <button type="button" class="shot-arrow shot-arrow--next" data-dir="1" aria-label="Next screenshot">&#8250;</button>
                <div class="shot-dots" role="tablist">
                  <?php foreach ($shots as $i => $shot): ?>
                    <button type="button" class="shot-dot <?= $i === 0 ? 'is-active' : '' ?>" data-index="<?= $i ?>" aria-label="Go to screenshot <?= $i + 1 ?>"></button>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          <div class="project-card__meta">
            <h3><?= e($fp['name']) ?></h3>
            <?php if (!empty($fp['category'])): ?>
              <p class="project-card__role"><?= e($fp['category']) ?></p>
            <?php endif; ?>
            <?php if (!empty($fp['description'])): ?>
              <p class="project-card__desc"><?= e(mb_substr($fp['description'], 0, 260)) ?><?= mb_strlen($fp['description'] ?? '') > 260 ? '…' : '' ?></p>
            <?php endif; ?>
            <?php if (!empty($fp['technologies'])): ?>
              <div class="project-card__tech">
                <?php foreach (array_filter(array_map('trim', explode(',', $fp['technologies']))) as $tech): ?>
                  <span><?= e($tech) ?></span>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
            <?php if (!empty($fp['live_url'])): ?>
              <a href="<?= e($fp['live_url']) ?>" target="_blank" rel="noopener" class="project-card__visit">
                Check it out live <span aria-hidden="true">&rarr;</span>
              </a>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>

      <article class="project-card">
        <div class="project-card__meta">
          <h3>Fintech Platform Suite</h3>
          <p class="project-card__role">Director &amp; Lead Developer &middot; PHP, MySQL, JavaScript</p>
          <p class="project-card__desc">
            Led design and development of multiple banking and financial
            platforms — customer dashboards, transactional email systems,
            and secure backend infrastructure handling real user funds.
          </p>
          <ul class="project-card__outcomes">
            <li>Hardened backend security across authentication and payments</li>
            <li>Built branded, on-brand communication systems for each platform</li>
          </ul>
          <span class="project-card__tag">Private client work</span>
        </div>
      </article>

      <article class="project-card">
        <div class="project-card__meta">
          <h3>Live Support &amp; Chat System</h3>
          <p class="project-card__role">Full-Stack Developer &middot; Firebase, JavaScript</p>
          <p class="project-card__desc">
            Real-time visitor chat and agent dashboard with file uploads,
            built on Firebase — enabling instant customer support at scale.
          </p>
          <ul class="project-card__outcomes">
            <li>Real-time messaging with zero page reloads</li>
            <li>Agent + visitor dual interface, deployed to production</li>
          </ul>
          <span class="project-card__tag">Private client work</span>
        </div>
      </article>

    </div>
  </div>
</section>

<!-- ================= AUTOMATION ================= -->
<section class="section automation" id="automation">
  <div class="container automation__grid">
    <div class="automation__text">
      <p class="eyebrow">04 &mdash; AI Automation</p>
      <h2 class="section-title">The part most developers skip.</h2>
      <p class="body-text">
        Beyond writing the interface and the backend, I design the
        automation layer that removes manual, repetitive work — customer
        replies, follow-ups, data processing — and replaces it with a
        system that runs on its own.
      </p>

      <div class="flow">
        <div class="flow__step">
          <span class="flow__label">Input</span>
          <p>Customer message, form, or event</p>
        </div>
        <div class="flow__arrow">&#8594;</div>
        <div class="flow__step flow__step--accent">
          <span class="flow__label">AI Processing</span>
          <p>Understands intent, decides next action</p>
        </div>
        <div class="flow__arrow">&#8594;</div>
        <div class="flow__step">
          <span class="flow__label">Action</span>
          <p>Reply sent, record updated, task triggered</p>
        </div>
      </div>
    </div>

    <div class="automation__cases">
      <div class="case-card">
        <h3>WhatsApp Automation Bot</h3>
        <p>Full customer journey mapping and automated messaging flow for a subscription-based service — from first contact to renewal reminders.</p>
      </div>
      <div class="case-card">
        <h3>Automated Customer Communications</h3>
        <p>Transactional and support-acknowledgment email systems that trigger automatically based on customer actions, no manual sending required.</p>
      </div>
      <div class="case-card">
        <h3>Referral &amp; Engagement Nudging</h3>
        <p>Automated follow-up sequences that re-engage users at the right moment, built into a referral-driven web app.</p>
      </div>
    </div>
  </div>
</section>

<!-- ================= EXPERIENCE ================= -->
<section class="section experience" id="experience">
  <div class="container">
    <p class="eyebrow">05 &mdash; Experience</p>
    <h2 class="section-title">Where I've been.</h2>

    <div class="timeline">
      <div class="timeline__item">
        <div class="timeline__dot"></div>
        <div class="timeline__content">
          <span class="timeline__date">2023 &mdash; Present</span>
          <h3>Director &amp; Independent Full-Stack Developer</h3>
          <p>Leading development across multiple web and fintech platforms — full-stack builds, AI automation systems, and brand-consistent customer communications for several clients simultaneously.</p>
        </div>
      </div>

      <div class="timeline__item">
        <div class="timeline__dot"></div>
        <div class="timeline__content">
          <span class="timeline__date">2020 &mdash; 2023</span>
          <h3>Senior Full-Stack Developer</h3>
          <p>Built and secured production web platforms end-to-end — from database architecture to interface — with a growing focus on automation and workflow tooling.</p>
        </div>
      </div>

      <div class="timeline__item">
        <div class="timeline__dot"></div>
        <div class="timeline__content">
          <span class="timeline__date">2017 &mdash; 2020</span>
          <h3>Full-Stack Developer</h3>
          <p>Started building production web applications, developing a foundation in PHP, JavaScript, and database design that everything since has built on.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= CONTACT ================= -->
<section class="section contact" id="contact">
  <div class="container contact__inner">
    <p class="eyebrow">06 &mdash; Contact</p>
    <h2 class="section-title">Let's build something.</h2>
    <p class="body-text contact__lede">
      Open to new projects and collaborations. Tell me what you're building.
    </p>

    <form class="contact-form" id="contactForm">
      <div class="form-row">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
      </div>
      <div class="form-row">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
      </div>
      <div class="form-row">
        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5" required></textarea>
      </div>
      <button type="submit" class="btn btn--primary">Send Message</button>
      <p class="form-status" id="formStatus" role="status"></p>
    </form>

    <div class="contact__links">
      <a href="mailto:opreciouschidi@gmail.com" class="social-link" aria-label="Email">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
        <span>Email</span>
      </a>
      <a href="#" target="_blank" rel="noopener" class="social-link" aria-label="GitHub">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49 0-.24-.01-.87-.01-1.71-2.78.62-3.37-1.36-3.37-1.36-.46-1.19-1.11-1.51-1.11-1.51-.91-.63.07-.62.07-.62 1 .07 1.53 1.05 1.53 1.05.89 1.56 2.34 1.11 2.91.85.09-.66.35-1.11.63-1.37-2.22-.26-4.56-1.14-4.56-5.05 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.32.1-2.75 0 0 .84-.28 2.75 1.05a9.3 9.3 0 0 1 5 0c1.9-1.33 2.75-1.05 2.75-1.05.55 1.43.2 2.49.1 2.75.64.72 1.03 1.63 1.03 2.75 0 3.92-2.34 4.79-4.57 5.04.36.32.68.95.68 1.92 0 1.39-.01 2.51-.01 2.85 0 .27.18.6.69.49A10.26 10.26 0 0 0 22 12.25C22 6.58 17.52 2 12 2Z"/></svg>
        <span>GitHub</span>
      </a>
      <a href="#" target="_blank" rel="noopener" class="social-link" aria-label="LinkedIn">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3 9h4v12H3V9Zm7 0h3.8v1.64h.05c.53-1 1.83-2.06 3.77-2.06 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.6c0-1.34-.02-3.06-1.87-3.06-1.87 0-2.16 1.46-2.16 2.96V21h-4V9Z"/></svg>
        <span>LinkedIn</span>
      </a>
      <a href="https://www.instagram.com/iamtshuga?igsh=Z3Zmc3d5NTd5bjFt" target="_blank" rel="noopener" class="social-link" aria-label="Instagram">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
        <span>Instagram</span>
      </a>
      <a href="https://wa.me/2348084508767" target="_blank" rel="noopener" class="social-link" aria-label="WhatsApp">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.33 4.95L2 22l5.29-1.39a9.87 9.87 0 0 0 4.75 1.21h.01c5.46 0 9.9-4.45 9.9-9.91C22 6.45 17.5 2 12.04 2Zm5.8 14.09c-.24.68-1.4 1.33-1.93 1.4-.49.07-1.1.1-1.78-.11a16.3 16.3 0 0 1-1.63-.6c-2.87-1.24-4.74-4.13-4.88-4.32-.14-.19-1.17-1.55-1.17-2.96s.73-2.1.99-2.39c.26-.29.56-.36.75-.36h.54c.17 0 .4-.03.63.48.24.53.8 1.93.87 2.07.07.14.12.31.02.5-.09.19-.14.31-.28.47-.14.16-.29.36-.42.48-.14.14-.28.29-.12.57.16.28.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.22 1.37.28.14.44.12.6-.07.16-.19.68-.79.87-1.06.19-.28.37-.23.63-.14.26.1 1.63.77 1.91.91.28.14.47.21.53.33.07.12.07.68-.17 1.36Z"/></svg>
        <span>WhatsApp</span>
      </a>
    </div>
  </div>
</section>

<footer class="footer">
  <div class="container footer__inner">
    <span>&copy; <span id="year"></span> Chidi. All rights reserved.</span>
    <div class="footer__links">
      <a href="#home">Home</a>
      <a href="#projects">Work</a>
      <a href="#contact">Contact</a>
    </div>
  </div>
</footer>

<script>
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Year ---------- */
  document.getElementById('year').textContent = new Date().getFullYear();

  /* ---------- Nav scroll state + mobile toggle ---------- */
  const nav = document.getElementById('nav');
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  window.addEventListener('scroll', () => {
    nav.classList.toggle('is-scrolled', window.scrollY > 20);
  });

  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', isOpen);
  });

  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('is-open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });

  /* ---------- Scroll-spy ---------- */
  const sections = document.querySelectorAll('section[id]');
  const navAnchors = document.querySelectorAll('[data-nav]');

  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navAnchors.forEach(a => a.classList.remove('is-active'));
        const active = document.querySelector(`[data-nav][href="#${entry.target.id}"]`);
        if (active) active.classList.add('is-active');
      }
    });
  }, { rootMargin: '-45% 0px -50% 0px' });

  sections.forEach(s => spyObserver.observe(s));

  /* ---------- Typewriter role text ---------- */
  const roles = [
    'Director',
    'Senior Full-Stack Developer',
    'AI Automation Engineer',
    'Building systems that ship.'
  ];
  const typedEl = document.getElementById('typedRole');
  let roleIndex = 0, charIndex = 0, deleting = false;

  function typeLoop() {
    const current = roles[roleIndex];
    if (!deleting) {
      charIndex++;
      typedEl.textContent = current.slice(0, charIndex);
      if (charIndex === current.length) {
        deleting = true;
        setTimeout(typeLoop, 1400);
        return;
      }
    } else {
      charIndex--;
      typedEl.textContent = current.slice(0, charIndex);
      if (charIndex === 0) {
        deleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
      }
    }
    setTimeout(typeLoop, deleting ? 35 : 55);
  }
  typeLoop();

  /* ---------- Scroll reveal ---------- */
  const revealTargets = document.querySelectorAll(
    '.section-title, .about__stats, .skill-card, .project-card, .case-card, .timeline__item, .contact-form'
  );
  revealTargets.forEach(el => el.setAttribute('data-reveal', ''));

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealTargets.forEach(el => revealObserver.observe(el));

  /* ---------- Animated stat counters ---------- */
  const statNums = document.querySelectorAll('.stat__num');
  const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count, 10);
        let current = 0;
        const step = Math.max(1, Math.ceil(target / 40));
        const tick = () => {
          current += step;
          if (current >= target) { el.textContent = target; return; }
          el.textContent = current;
          requestAnimationFrame(tick);
        };
        tick();
        countObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  statNums.forEach(el => countObserver.observe(el));

  /* ---------- Contact form (placeholder handler) ---------- */
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    status.textContent = 'Sending…';

    // Replace this block with EmailJS or a PHP mail endpoint when ready.
    setTimeout(() => {
      status.textContent = "Thanks — I'll get back to you soon.";
      form.reset();
    }, 900);
  });

});

</script>

<!-- Shared zoom lightbox for showcase screenshots -->
<div class="shot-lightbox" id="shotLightbox" role="dialog" aria-label="Screenshot zoom">
  <button type="button" class="shot-lightbox__close" aria-label="Close">&times;</button>
  <img src="" alt="Zoomed screenshot">
</div>

<script>
/* Showcase carousels: slide animation, auto-advance, click-to-zoom. */
(function () {
  document.querySelectorAll('[data-carousel]').forEach(function (carousel) {
    var track = carousel.querySelector('.shot-track');
    var slides = carousel.querySelectorAll('.shot-slide');
    var dots = carousel.querySelectorAll('.shot-dot');
    var index = 0;
    var timer = null;

    function go(i) {
      index = (i + slides.length) % slides.length;
      track.style.transform = 'translateX(-' + (index * 100) + '%)';
      dots.forEach(function (d, di) { d.classList.toggle('is-active', di === index); });
    }

    carousel.querySelectorAll('.shot-arrow').forEach(function (arrow) {
      arrow.addEventListener('click', function () { go(index + parseInt(arrow.dataset.dir, 10)); restart(); });
    });
    dots.forEach(function (dot) {
      dot.addEventListener('click', function () { go(parseInt(dot.dataset.index, 10)); restart(); });
    });

    function restart() {
      if (slides.length < 2) return;
      clearInterval(timer);
      timer = setInterval(function () { go(index + 1); }, 4500);
    }
    carousel.addEventListener('mouseenter', function () { clearInterval(timer); });
    carousel.addEventListener('mouseleave', restart);
    restart();
  });

  /* Lightbox: clicking a screenshot zooms it — never navigates. */
  var lightbox = document.getElementById('shotLightbox');
  var lightboxImg = lightbox.querySelector('img');

  document.addEventListener('click', function (e) {
    var slide = e.target.closest('.shot-slide');
    if (slide) {
      lightboxImg.src = slide.src;
      lightbox.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      return;
    }
    if (lightbox.classList.contains('is-open') &&
        (e.target === lightbox || e.target === lightboxImg || e.target.closest('.shot-lightbox__close'))) {
      lightbox.classList.remove('is-open');
      document.body.style.overflow = '';
    }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && lightbox.classList.contains('is-open')) {
      lightbox.classList.remove('is-open');
      document.body.style.overflow = '';
    }
  });
})();
</script>

<script>
/* Work section: show 1 project, reveal the rest on demand. */
(function () {
  var list = document.querySelector('.project-list');
  if (!list) return;
  var cards = list.querySelectorAll('.project-card');
  if (cards.length <= 1) return;

  cards.forEach(function (card, i) {
    if (i > 0) card.classList.add('project-hidden');
  });

  var btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'btn btn--ghost projects__more';
  btn.textContent = 'View more work (' + (cards.length - 1) + ')';
  btn.setAttribute('aria-expanded', 'false');
  list.insertAdjacentElement('afterend', btn);

  btn.addEventListener('click', function () {
    var expanded = btn.getAttribute('aria-expanded') === 'true';
    cards.forEach(function (card, i) {
      if (i > 0) card.classList.toggle('project-hidden', expanded);
    });
    btn.setAttribute('aria-expanded', String(!expanded));
    btn.textContent = expanded ? 'View more work (' + (cards.length - 1) + ')' : 'View less';
    if (expanded) list.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
})();
</script>

<!-- ================= FLOATING WHATSAPP ================= -->
<style>
  .wa-fab {
    position: fixed;
    right: 22px;
    bottom: 22px;
    z-index: 200;
    width: 58px;
    height: 58px;
    border-radius: 50%;
    background: #25D366;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 24px rgba(0,0,0,.45);
    cursor: pointer;
    border: none;
    transition: transform .25s var(--ease);
    animation: wa-pulse 2.6s infinite;
  }
  .wa-fab:hover { transform: scale(1.08); }
  .wa-fab svg { width: 30px; height: 30px; }
  @keyframes wa-pulse {
    0%   { box-shadow: 0 8px 24px rgba(0,0,0,.45), 0 0 0 0 rgba(37,211,102,.45); }
    70%  { box-shadow: 0 8px 24px rgba(0,0,0,.45), 0 0 0 16px rgba(37,211,102,0); }
    100% { box-shadow: 0 8px 24px rgba(0,0,0,.45), 0 0 0 0 rgba(37,211,102,0); }
  }
  .wa-card {
    position: fixed;
    right: 22px;
    bottom: 92px;
    z-index: 200;
    width: min(320px, calc(100vw - 44px));
    background: var(--elevated);
    border: 1px solid var(--border);
    border-radius: 16px;
    box-shadow: 0 16px 48px rgba(0,0,0,.55);
    overflow: hidden;
    opacity: 0;
    transform: translateY(12px) scale(.97);
    pointer-events: none;
    transition: opacity .25s var(--ease), transform .25s var(--ease);
  }
  .wa-card.is-open { opacity: 1; transform: none; pointer-events: auto; }
  .wa-card__head {
    background: #075E54;
    color: #fff;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .wa-card__head img { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,.5); }
  .wa-card__head .who { font-family: var(--font-display); font-weight: 700; font-size: 14.5px; line-height: 1.2; }
  .wa-card__head .status { font-size: 11.5px; opacity: .8; }
  .wa-card__body { padding: 16px; }
  .wa-card__hint {
    background: var(--elevated-2);
    border-radius: 10px;
    padding: 10px 12px;
    font-size: 13px;
    color: var(--text-mid);
    margin-bottom: 14px;
  }
  .wa-card__body label {
    display: block;
    font-family: var(--font-mono);
    font-size: 10.5px;
    letter-spacing: .08em;
    text-transform: uppercase;
    color: var(--text-low);
    margin-bottom: 5px;
  }
  .wa-card__body input,
  .wa-card__body textarea {
    width: 100%;
    background: var(--elevated-2);
    border: 1px solid var(--border);
    border-radius: 8px;
    color: var(--text-hi);
    padding: 10px 12px;
    font-size: 14px;
    margin-bottom: 12px;
    font-family: var(--font-body);
  }
  .wa-card__body input:focus,
  .wa-card__body textarea:focus { outline: none; border-color: #25D366; }
  .wa-send {
    width: 100%;
    background: #25D366;
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 12px;
    font-weight: 600;
    font-size: 14.5px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: background .2s;
  }
  .wa-send:hover { background: #1EBE5B; }
</style>

<div class="wa-card" id="waCard" role="dialog" aria-label="Chat on WhatsApp">
  <div class="wa-card__head">
    <img src="<?= asset('img/chidi-photo.jpeg') ?>" alt="Chidi">
    <div>
      <div class="who">Chidi</div>
      <div class="status">Typically replies within minutes</div>
    </div>
  </div>
  <div class="wa-card__body">
    <div class="wa-card__hint">👋 Hi there! Tell me your name and I'll continue with you on WhatsApp.</div>
    <label for="waName">Your name</label>
    <input type="text" id="waName" maxlength="60" placeholder="e.g. John" autocomplete="name">
    <label for="waMsg">Message (optional)</label>
    <textarea id="waMsg" rows="2" maxlength="300" placeholder="I need a website for my business…"></textarea>
    <button type="button" class="wa-send" id="waSend">
      <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.33 4.95L2 22l5.29-1.39a9.87 9.87 0 0 0 4.75 1.21c5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2Zm0 18.02c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.05-.2-.31a8.26 8.26 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24 4.54 0 8.24 3.7 8.24 8.24 0 4.55-3.7 8.25-8.24 8.25Zm4.52-6.16c-.25-.13-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.25-.64.8-.78.97-.14.16-.29.18-.54.06-.25-.13-1.05-.39-2-1.23-.73-.66-1.23-1.47-1.38-1.72-.14-.25-.01-.38.11-.51.11-.11.25-.29.37-.43.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.13-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.22.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.13.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.6.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.1-.23-.16-.48-.29Z"/></svg>
      Continue to WhatsApp
    </button>
  </div>
</div>

<button type="button" class="wa-fab" id="waFab" aria-label="Contact me on WhatsApp" aria-expanded="false">
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.33 4.95L2 22l5.29-1.39a9.87 9.87 0 0 0 4.75 1.21c5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2Zm0 18.02c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.05-.2-.31a8.26 8.26 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24 4.54 0 8.24 3.7 8.24 8.24 0 4.55-3.7 8.25-8.24 8.25Zm4.52-6.16c-.25-.13-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.25-.64.8-.78.97-.14.16-.29.18-.54.06-.25-.13-1.05-.39-2-1.23-.73-.66-1.23-1.47-1.38-1.72-.14-.25-.01-.38.11-.51.11-.11.25-.29.37-.43.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.13-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.22.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.13.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.6.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.1-.23-.16-.48-.29Z"/></svg>
</button>

<script>
(function () {
  var WA_NUMBER = '2348084508767';
  var fab = document.getElementById('waFab');
  var card = document.getElementById('waCard');
  var nameInput = document.getElementById('waName');
  var msgInput = document.getElementById('waMsg');

  fab.addEventListener('click', function () {
    var open = card.classList.toggle('is-open');
    fab.setAttribute('aria-expanded', open);
    if (open) setTimeout(function () { nameInput.focus(); }, 250);
  });

  // Close when tapping outside the widget
  document.addEventListener('click', function (e) {
    if (card.classList.contains('is-open') && !card.contains(e.target) && !fab.contains(e.target)) {
      card.classList.remove('is-open');
      fab.setAttribute('aria-expanded', 'false');
    }
  });

  function send() {
    var name = nameInput.value.trim();
    if (!name) {
      nameInput.style.borderColor = '#E8342A';
      nameInput.focus();
      return;
    }
    var extra = msgInput.value.trim();
    var text = "Hi Chidi! I'm " + name + '.' + (extra ? ' ' + extra : ' I found your portfolio and would like to talk about a project.');
    window.open('https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
    card.classList.remove('is-open');
    fab.setAttribute('aria-expanded', 'false');
  }

  nameInput.addEventListener('input', function () { nameInput.style.borderColor = ''; });
  document.getElementById('waSend').addEventListener('click', send);
  msgInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  });
  nameInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); send(); }
  });
})();
</script>
</body>
</html>