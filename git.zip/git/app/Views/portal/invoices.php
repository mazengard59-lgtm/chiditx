<?php
/**
 * Portal: client's invoices.
 * @var array $invoices
 */
use App\Models\Invoice;
?>
<div class="card-sams">
  <?php if ($invoices === []): ?>
    <div class="empty-state"><i class="bi bi-receipt"></i><p>No invoices yet.</p></div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams w-100">
        <thead>
          <tr><th>Invoice</th><th>Issued</th><th>Due</th><th>Total</th><th>Balance</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($invoices as $inv):
              $balance = (float) $inv['total'] - (float) $inv['amount_paid'];
          ?>
            <tr>
              <td style="font-family:var(--font-mono); color:var(--text-hi);"><?= e($inv['invoice_number']) ?></td>
              <td><?= e(date('M j, Y', strtotime($inv['issue_date']))) ?></td>
              <td><?= e(date('M j, Y', strtotime($inv['due_date']))) ?></td>
              <td style="font-weight:600; color:var(--text-hi);"><?= money($inv['total']) ?></td>
              <td style="color:<?= $balance > 0 ? 'var(--warning)' : 'var(--success)' ?>;"><?= money($balance) ?></td>
              <td><span class="badge-soft badge-soft--<?= Invoice::STATUS_COLORS[$inv['status']] ?? 'muted' ?>"><?= e($inv['status']) ?></span></td>
              <td class="text-end">
                <a href="<?= url('portal/invoices/' . $inv['id'] . '/print') ?>" target="_blank" class="icon-btn" title="View / download PDF">
                  <i class="bi bi-file-earmark-arrow-down"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
