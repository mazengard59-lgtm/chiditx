<?php
/**
 * Portal: ticket thread (internal notes already filtered out).
 * @var array $ticket
 * @var array $replies
 * @var array $client
 */
use App\Models\Ticket;
?>
<div class="page-head">
  <a href="<?= url('portal/tickets') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> All tickets</a>
  <span class="badge-soft badge-soft--<?= Ticket::STATUS_COLORS[$ticket['status']] ?? 'muted' ?>"><?= e($ticket['status']) ?></span>
</div>

<div class="card-sams p-4 mb-3">
  <h4 class="m-0">#<?= (int) $ticket['id'] ?> — <?= e($ticket['subject']) ?></h4>
  <div style="color:var(--text-low); font-size:13px; margin-top:4px;">opened <?= e(date('M j, Y H:i', strtotime($ticket['created_at']))) ?></div>
</div>

<?php foreach ($replies as $r): $mine = $r['user_id'] === null; ?>
  <div class="card-sams p-3 mb-2" style="<?= $mine ? '' : 'border-left:3px solid var(--accent);' ?>">
    <div class="d-flex justify-content-between mb-2" style="font-size:12.5px;">
      <strong style="color:var(--text-hi);"><?= $mine ? 'You' : e($r['user_name'] ?? 'Support') ?></strong>
      <span style="color:var(--text-low);"><?= e(date('M j, Y H:i', strtotime($r['created_at']))) ?></span>
    </div>
    <div style="color:var(--text-mid); font-size:14px; white-space:pre-line;"><?= e($r['message']) ?></div>
  </div>
<?php endforeach; ?>

<div class="card-sams p-4 mt-3">
  <form method="post" action="<?= url('portal/tickets/' . $ticket['id'] . '/reply') ?>">
    <?= csrf_field() ?>
    <label for="message" class="form-label-sams">Reply</label>
    <textarea id="message" name="message" rows="4" class="form-control-sams mb-3" required></textarea>
    <button type="submit" class="btn-sams"><i class="bi bi-send me-1"></i> Send</button>
  </form>
</div>
