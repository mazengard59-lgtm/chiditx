<?php
/**
 * Portal: client's projects.
 * @var array $projects
 */
use App\Models\Project;
?>
<div class="row g-3">
  <?php if ($projects === []): ?>
    <div class="col-12"><div class="card-sams"><div class="empty-state"><i class="bi bi-kanban"></i><p>No projects yet.</p></div></div></div>
  <?php endif; ?>

  <?php foreach ($projects as $p):
      $balance = (float) $p['price'] - (float) $p['deposit'];
  ?>
    <div class="col-12 col-lg-6">
      <div class="card-sams p-4 h-100">
        <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
          <h5 class="m-0"><?= e($p['name']) ?></h5>
          <span class="badge-soft badge-soft--<?= Project::STATUS_COLORS[$p['status']] ?? 'muted' ?>"><?= label($p['status']) ?></span>
        </div>
        <?php if ($p['description']): ?>
          <p style="color:var(--text-mid); font-size:13.5px;"><?= e(mb_substr($p['description'], 0, 180)) ?><?= mb_strlen($p['description']) > 180 ? '…' : '' ?></p>
        <?php endif; ?>

        <div class="d-flex align-items-center gap-2 mb-3">
          <div class="progress flex-grow-1" style="height:8px; background:var(--surface-2);">
            <div class="progress-bar" style="width:<?= (int) $p['progress'] ?>%; background:var(--accent);"></div>
          </div>
          <strong style="font-family:var(--font-mono); font-size:12px;"><?= (int) $p['progress'] ?>%</strong>
        </div>

        <div class="row g-2" style="font-size:13px;">
          <div class="col-6">
            <div class="page-head__sub">Deadline</div>
            <div style="font-weight:600;"><?= $p['deadline'] ? e(date('M j, Y', strtotime($p['deadline']))) : '—' ?></div>
          </div>
          <div class="col-6">
            <div class="page-head__sub">Balance</div>
            <div style="font-weight:600; color:<?= $balance > 0 ? 'var(--warning)' : 'var(--success)' ?>;"><?= money($balance) ?></div>
          </div>
        </div>

        <?php if ($p['live_url']): ?>
          <a href="<?= e($p['live_url']) ?>" target="_blank" rel="noopener" class="btn-ghost-sams mt-3 d-inline-block">
            <i class="bi bi-box-arrow-up-right me-1"></i> View live site
          </a>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>
