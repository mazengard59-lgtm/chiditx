<?php
/**
 * Portal: profile + password.
 * @var array $client
 * @var array $errors
 */
?>
<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-sams p-4">
      <h5 class="mb-4"><i class="bi bi-person me-2" style="color:var(--accent)"></i>Profile details</h5>
      <form method="post" action="<?= url('portal/profile') ?>">
        <?= csrf_field() ?>
        <div class="row g-3">
          <div class="col-md-6">
            <label for="name" class="form-label-sams">Full name *</label>
            <input type="text" id="name" name="name" value="<?= old('name', $client['name']) ?>"
                   class="form-control-sams <?= isset($errors['name']) ? 'is-invalid' : '' ?>">
            <?php if (isset($errors['name'])): ?><div class="invalid-feedback-sams"><?= e($errors['name']) ?></div><?php endif; ?>
          </div>
          <div class="col-md-6">
            <label class="form-label-sams">Email (login)</label>
            <input type="email" value="<?= e($client['email'] ?? '') ?>" class="form-control-sams" disabled>
          </div>
          <div class="col-md-6">
            <label for="phone" class="form-label-sams">Phone</label>
            <input type="text" id="phone" name="phone" value="<?= old('phone', (string) ($client['phone'] ?? '')) ?>" class="form-control-sams">
          </div>
          <div class="col-md-6">
            <label for="whatsapp" class="form-label-sams">WhatsApp</label>
            <input type="text" id="whatsapp" name="whatsapp" value="<?= old('whatsapp', (string) ($client['whatsapp'] ?? '')) ?>" class="form-control-sams">
          </div>
          <div class="col-12">
            <label for="address" class="form-label-sams">Address</label>
            <input type="text" id="address" name="address" value="<?= old('address', (string) ($client['address'] ?? '')) ?>" class="form-control-sams">
          </div>
        </div>
        <button type="submit" class="btn-sams mt-4"><i class="bi bi-check-lg me-1"></i> Save profile</button>
      </form>
    </div>
  </div>

  <div class="col-12 col-lg-5">
    <div class="card-sams p-4">
      <h5 class="mb-4"><i class="bi bi-shield-lock me-2" style="color:var(--accent)"></i>Change password</h5>
      <form method="post" action="<?= url('portal/password') ?>">
        <?= csrf_field() ?>

        <label for="current_password" class="form-label-sams">Current password</label>
        <input type="password" id="current_password" name="current_password"
               class="form-control-sams mb-1 <?= isset($errors['current_password']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['current_password'])): ?><div class="invalid-feedback-sams"><?= e($errors['current_password']) ?></div><?php endif; ?>

        <label for="new_password" class="form-label-sams mt-3">New password (min 8 chars)</label>
        <input type="password" id="new_password" name="new_password"
               class="form-control-sams mb-1 <?= isset($errors['new_password']) ? 'is-invalid' : '' ?>" required minlength="8">
        <?php if (isset($errors['new_password'])): ?><div class="invalid-feedback-sams"><?= e($errors['new_password']) ?></div><?php endif; ?>

        <button type="submit" class="btn-sams w-100 mt-4"><i class="bi bi-key me-1"></i> Update password</button>
      </form>
    </div>
  </div>
</div>
