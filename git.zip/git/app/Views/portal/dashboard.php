<?php
/**
 * Portal overview.
 * @var array $client
 * @var array $projects
 * @var int   $activeProjects
 * @var float $amountDue
 * @var int   $openTickets
 * @var array $renewals
 */
use App\Models\Project;
?>
<div class="page-head">
  <div>
    <h4 class="mb-1">Welcome back, <?= e(explode(' ', $client['name'])[0]) ?> 👋</h4>
    <div class="page-head__sub">Here's where everything stands.</div>
  </div>
</div>

<div class="row g-3 mb-4">
  <?php
  $tiles = [
      ['kanban', 'Active projects', (string) $activeProjects],
      ['receipt', 'Amount due', money($amountDue)],
      ['life-preserver', 'Open tickets', (string) $openTickets],
      ['arrow-repeat', 'Upcoming renewals', (string) count($renewals)],
  ];
  foreach ($tiles as [$icon, $label, $value]): ?>
    <div class="col-6 col-xl-3">
      <div class="card-sams stat-card">
        <div class="stat-card__icon"><i class="bi bi-<?= $icon ?>"></i></div>
        <div>
          <div class="stat-card__value" style="font-size:22px;"><?= e($value) ?></div>
          <div class="stat-card__label"><?= e($label) ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-sams">
      <div class="panel-header">
        <h5><i class="bi bi-kanban me-2" style="color:var(--accent)"></i>Your projects</h5>
        <a href="<?= url('portal/projects') ?>" class="btn-ghost-sams">View all</a>
      </div>
      <?php if ($projects === []): ?>
        <div class="empty-state"><i class="bi bi-kanban"></i><p>No projects yet.</p></div>
      <?php else: ?>
        <?php foreach (array_slice($projects, 0, 4) as $p): ?>
          <div class="activity-item">
            <span class="activity-item__dot"></span>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between gap-2">
                <strong style="color:var(--text-hi);"><?= e($p['name']) ?></strong>
                <span class="badge-soft badge-soft--<?= Project::STATUS_COLORS[$p['status']] ?? 'muted' ?>"><?= label($p['status']) ?></span>
              </div>
              <div class="d-flex align-items-center gap-2 mt-2">
                <div class="progress flex-grow-1" style="height:6px; background:var(--surface-2);">
                  <div class="progress-bar" style="width:<?= (int) $p['progress'] ?>%; background:var(--accent);"></div>
                </div>
                <span style="font-family:var(--font-mono); font-size:11px;"><?= (int) $p['progress'] ?>%</span>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-5">
    <div class="card-sams">
      <div class="panel-header"><h5><i class="bi bi-arrow-repeat me-2" style="color:var(--accent)"></i>Upcoming renewals</h5></div>
      <?php if ($renewals === []): ?>
        <div class="empty-state"><i class="bi bi-check2-circle" style="color:var(--success); opacity:1;"></i><p>Nothing due in the next 60 days.</p></div>
      <?php else: ?>
        <?php foreach ($renewals as $r):
            [$tone, , $daysLabel] = expiry_tone(days_left($r['expiry']));
        ?>
          <div class="activity-item">
            <span class="activity-item__dot" style="background:<?= $tone ?>;"></span>
            <div class="flex-grow-1 d-flex justify-content-between gap-2">
              <div>
                <strong style="color:var(--text-hi);"><?= e($r['label']) ?></strong>
                <div class="activity-item__meta"><?= e(date('M j, Y', strtotime($r['expiry']))) ?></div>
              </div>
              <span style="font-family:var(--font-mono); font-size:11.5px; color:<?= $tone ?>;"><?= $daysLabel ?></span>
            </div>
          </div>
        <?php endforeach; ?>
        <div class="p-3">
          <a href="https://wa.me/<?= e(config('owner.whatsapp')) ?>?text=<?= rawurlencode('Hello! I would like to renew my services.') ?>"
             target="_blank" rel="noopener" class="btn-sams w-100 d-block text-center">
            <i class="bi bi-whatsapp me-1"></i> Renew via WhatsApp
          </a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
