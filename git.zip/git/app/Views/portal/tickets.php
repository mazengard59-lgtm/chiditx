<?php
/**
 * Portal: support tickets list + open-new form.
 * @var array $tickets
 * @var array $errors
 */
use App\Models\Ticket;
?>
<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-sams">
      <div class="panel-header"><h5><i class="bi bi-life-preserver me-2" style="color:var(--accent)"></i>Your tickets</h5></div>
      <?php if ($tickets === []): ?>
        <div class="empty-state"><i class="bi bi-chat"></i><p>No tickets yet. Need help? Open one on the right.</p></div>
      <?php else: ?>
        <?php foreach ($tickets as $t): ?>
          <a href="<?= url('portal/tickets/' . $t['id']) ?>" class="activity-item" style="display:flex;">
            <span class="activity-item__dot"></span>
            <div class="flex-grow-1 d-flex justify-content-between gap-2">
              <div>
                <strong style="color:var(--text-hi);">#<?= (int) $t['id'] ?> — <?= e($t['subject']) ?></strong>
                <div class="activity-item__meta"><?= (int) $t['reply_count'] ?> message<?= (int) $t['reply_count'] === 1 ? '' : 's' ?> &middot; <?= e(date('M j, Y', strtotime($t['updated_at']))) ?></div>
              </div>
              <span class="badge-soft badge-soft--<?= Ticket::STATUS_COLORS[$t['status']] ?? 'muted' ?>" style="align-self:center;"><?= e($t['status']) ?></span>
            </div>
          </a>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-5">
    <div class="card-sams p-4">
      <h5 class="mb-3"><i class="bi bi-plus-circle me-2" style="color:var(--accent)"></i>Open a new ticket</h5>
      <form method="post" action="<?= url('portal/tickets') ?>">
        <?= csrf_field() ?>

        <label for="subject" class="form-label-sams">Subject *</label>
        <input type="text" id="subject" name="subject" value="<?= old('subject') ?>"
               class="form-control-sams mb-1 <?= isset($errors['subject']) ? 'is-invalid' : '' ?>">
        <?php if (isset($errors['subject'])): ?><div class="invalid-feedback-sams"><?= e($errors['subject']) ?></div><?php endif; ?>

        <label for="message" class="form-label-sams mt-3">How can we help? *</label>
        <textarea id="message" name="message" rows="5"
                  class="form-control-sams mb-1 <?= isset($errors['message']) ? 'is-invalid' : '' ?>"><?= old('message') ?></textarea>
        <?php if (isset($errors['message'])): ?><div class="invalid-feedback-sams"><?= e($errors['message']) ?></div><?php endif; ?>

        <button type="submit" class="btn-sams w-100 mt-3"><i class="bi bi-send me-1"></i> Submit ticket</button>
      </form>
    </div>
  </div>
</div>
