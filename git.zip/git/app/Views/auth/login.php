<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign in — <?= e(config('name')) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= asset('css/admin.css') ?>" rel="stylesheet">
<script>
document.documentElement.setAttribute('data-theme', localStorage.getItem('sams-theme') || 'dark');
</script>
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-card__brand">SAMS<span class="dot">.</span></div>
    <p class="auth-card__sub">Sign in to <?= e(config('agency')) ?></p>

    <?php require BASE_PATH . '/app/Views/partials/flash.php'; ?>

    <form method="post" action="<?= url('login') ?>" novalidate>
      <?= csrf_field() ?>

      <div class="mb-3">
        <label for="email" class="form-label-sams">Email address</label>
        <input type="email" id="email" name="email" required autofocus
               value="<?= old('email') ?>"
               class="form-control-sams <?= isset($errors['email']) ? 'is-invalid' : '' ?>">
        <?php if (isset($errors['email'])): ?>
          <div class="invalid-feedback-sams"><?= e($errors['email']) ?></div>
        <?php endif; ?>
      </div>

      <div class="mb-4">
        <label for="password" class="form-label-sams">Password</label>
        <input type="password" id="password" name="password" required
               class="form-control-sams <?= isset($errors['password']) ? 'is-invalid' : '' ?>">
        <?php if (isset($errors['password'])): ?>
          <div class="invalid-feedback-sams"><?= e($errors['password']) ?></div>
        <?php endif; ?>
      </div>

      <button type="submit" class="btn-sams w-100">
        <i class="bi bi-box-arrow-in-right me-1"></i> Sign in
      </button>
    </form>

    <p class="text-center mt-4 mb-0" style="font-size:12.5px; color:var(--text-low);">
      <a href="<?= url('/') ?>" style="color:var(--text-mid);">
        <i class="bi bi-arrow-left me-1"></i>Back to website
      </a>
    </p>
  </div>
</div>
<script src="<?= asset('js/admin.js') ?>"></script>
</body>
</html>
