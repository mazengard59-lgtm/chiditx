<?php
/**
 * Dashboard view — variables provided by DashboardController::index().
 * @var array $stats
 * @var array $activities
 * @var array $deadlines Upcoming project deadlines
 */
?>
<div class="row g-3 mb-4">
  <?php foreach ($stats as $stat): ?>
    <div class="col-6 col-xl-3">
      <div class="card-sams stat-card">
        <div class="stat-card__icon"><i class="bi bi-<?= e($stat['icon']) ?>"></i></div>
        <div>
          <div class="stat-card__value">
            <?= e($stat['prefix'] ?? '') ?><?= number_format((float) $stat['value']) ?>
          </div>
          <div class="stat-card__label"><?= e($stat['label']) ?></div>
          <span class="stat-card__trend"><?= e($stat['trend']) ?></span>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-sams">
      <div class="panel-header">
        <h5><i class="bi bi-activity me-2" style="color:var(--accent)"></i>Recent Activity</h5>
      </div>
      <?php if ($activities === []): ?>
        <div class="empty-state">
          <i class="bi bi-hourglass"></i>
          <p>No activity yet. Actions across the system will appear here.</p>
        </div>
      <?php else: ?>
        <?php foreach ($activities as $activity): ?>
          <div class="activity-item">
            <span class="activity-item__dot"></span>
            <div>
              <div>
                <strong><?= e($activity['user_name'] ?? 'System') ?></strong>
                — <?= e($activity['description']) ?>
              </div>
              <div class="activity-item__meta">
                <?= e($activity['action']) ?> &middot; <?= e($activity['created_at']) ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-5">
    <div class="card-sams mb-3">
      <div class="panel-header">
        <h5><i class="bi bi-flag me-2" style="color:var(--accent)"></i>Upcoming Deadlines</h5>
        <a href="<?= url('projects') ?>" class="btn-ghost-sams">All projects</a>
      </div>

      <?php if ($deadlines === []): ?>
        <div class="empty-state">
          <i class="bi bi-calendar-check"></i>
          <p>No active project deadlines. Nice and calm.</p>
        </div>
      <?php else: ?>
        <?php foreach ($deadlines as $d):
            $days = (int) floor((strtotime($d['deadline']) - time()) / 86400);
            $tone = $days < 0 ? 'var(--danger)' : ($days <= 7 ? 'var(--warning)' : 'var(--text-low)');
        ?>
          <div class="activity-item">
            <span class="activity-item__dot" style="background:<?= $tone ?>;"></span>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between gap-2">
                <a href="<?= url('projects/' . $d['id']) ?>" style="color:var(--text-hi); font-weight:600;"><?= e($d['name']) ?></a>
                <span style="font-family:var(--font-mono); font-size:11.5px; color:<?= $tone ?>; white-space:nowrap;">
                  <?= $days < 0 ? abs($days) . 'd overdue' : ($days === 0 ? 'today' : $days . 'd left') ?>
                </span>
              </div>
              <div class="activity-item__meta">
                <?= e($d['client_name']) ?> &middot; <?= e(date('M j, Y', strtotime($d['deadline']))) ?> &middot; <?= (int) $d['progress'] ?>% done
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="card-sams p-3 d-flex flex-row gap-2 flex-wrap">
      <a href="<?= url('clients/create') ?>" class="btn-ghost-sams flex-grow-1 text-center"><i class="bi bi-person-plus me-1"></i> New client</a>
      <a href="<?= url('projects/create') ?>" class="btn-ghost-sams flex-grow-1 text-center"><i class="bi bi-plus-square me-1"></i> New project</a>
    </div>
  </div>
</div>
