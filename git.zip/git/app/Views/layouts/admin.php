<?php
/**
 * Admin layout — variables provided by App\Core\View::render().
 * @var string $content Rendered page HTML
 * @var string $title   Page title
 */
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($title ?? 'Admin') ?> — <?= e(config('name')) ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.0.8/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<link href="<?= asset('css/admin.css') ?>" rel="stylesheet">

<script>
/* Apply saved theme before paint to avoid a flash of wrong theme */
document.documentElement.setAttribute('data-theme', localStorage.getItem('sams-theme') || 'dark');
</script>
</head>
<body>
<div class="app-shell">

  <?php require BASE_PATH . '/app/Views/partials/sidebar.php'; ?>
  <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

  <div class="app-main">
    <?php require BASE_PATH . '/app/Views/partials/topbar.php'; ?>

    <main class="app-content">
      <?php require BASE_PATH . '/app/Views/partials/flash.php'; ?>
      <?= $content ?>
    </main>

    <?php
    $footPath = (new App\Core\Request())->path;
    $footLinks = [
        ['/dashboard', 'grid-1x2',     'Dashboard'],
        ['/clients',   'people',       'Clients'],
        ['/projects',  'kanban',       'Projects'],
        ['/renewals',  'arrow-repeat', 'Renewals'],
    ];
    ?>
    <footer class="app-footer" aria-label="Quick navigation">
      <?php foreach ($footLinks as [$path, $icon, $label]): ?>
        <a href="<?= url($path) ?>"
           class="app-footer__link <?= ($footPath === $path || str_starts_with($footPath, $path . '/')) ? 'is-active' : '' ?>">
          <i class="bi bi-<?= $icon ?>"></i><span><?= $label ?></span>
        </a>
      <?php endforeach; ?>
      <form method="post" action="<?= url('logout') ?>" class="d-inline m-0">
        <?= csrf_field() ?>
        <button type="submit" class="app-footer__link app-footer__link--danger">
          <i class="bi bi-box-arrow-right"></i><span>Logout</span>
        </button>
      </form>
    </footer>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.0.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.0.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= asset('js/admin.js') ?>"></script>
</body>
</html>
