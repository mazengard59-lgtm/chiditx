<?php
/**
 * Client portal layout — top nav + mobile dock, reuses the SAMS theme.
 * @var string $content Rendered page HTML
 * @var string $title   Page title
 */
$portalPath = (new App\Core\Request())->path;
$portalLinks = [
    ['/portal',          'grid-1x2',       'Overview'],
    ['/portal/projects', 'kanban',         'Projects'],
    ['/portal/invoices', 'receipt',        'Invoices'],
    ['/portal/tickets',  'life-preserver', 'Support'],
    ['/portal/profile',  'person',         'Profile'],
];
$isActive = fn(string $p) => $portalPath === $p || ($p !== '/portal' && str_starts_with($portalPath, $p . '/'))
    ? 'is-active' : '';
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($title ?? 'Portal') ?> — <?= e(config('name')) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= asset('css/admin.css') ?>" rel="stylesheet">
<style>
  .portal-nav { display: flex; gap: 4px; }
  .portal-nav .app-footer__link { flex: 0 0 auto; flex-direction: row; gap: 8px; font-size: 13px; padding: 8px 16px; }
  @media (max-width: 767.98px) { .portal-nav { display: none; } }
</style>
<script>
document.documentElement.setAttribute('data-theme', localStorage.getItem('sams-theme') || 'dark');
</script>
</head>
<body>
<div class="app-main" style="margin-left:0;">
  <header class="topbar">
    <a href="<?= url('portal') ?>" class="sidebar__brand" style="border:none; height:auto; padding:0;">
      CHIDI<span class="dot" style="color:var(--accent);">.</span>
    </a>
    <nav class="portal-nav ms-3">
      <?php foreach ($portalLinks as [$path, $icon, $label]): ?>
        <a href="<?= url($path) ?>" class="app-footer__link <?= $isActive($path) ?>" style="display:inline-flex;">
          <i class="bi bi-<?= $icon ?>"></i><span><?= $label ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="topbar__spacer"></div>
    <button class="icon-btn" id="themeToggle" aria-label="Toggle theme"><i class="bi bi-sun"></i></button>
    <form method="post" action="<?= url('logout') ?>">
      <?= csrf_field() ?>
      <button type="submit" class="icon-btn" title="Sign out"><i class="bi bi-box-arrow-right"></i></button>
    </form>
  </header>

  <main class="app-content">
    <?php require BASE_PATH . '/app/Views/partials/flash.php'; ?>
    <?= $content ?>
  </main>

  <footer class="app-footer" aria-label="Portal navigation">
    <?php foreach ($portalLinks as [$path, $icon, $label]): ?>
      <a href="<?= url($path) ?>" class="app-footer__link <?= $isActive($path) ?>">
        <i class="bi bi-<?= $icon ?>"></i><span><?= $label ?></span>
      </a>
    <?php endforeach; ?>
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.0.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= asset('js/admin.js') ?>"></script>
</body>
</html>
