<?php
/**
 * Lead create/edit form.
 * @var array|null $lead
 * @var array      $errors
 */
use App\Models\Lead;

$editing = $lead !== null;
$action  = $editing ? url('crm/' . $lead['id']) : url('crm');
$value   = fn(string $f) => old($f, (string) ($lead[$f] ?? ''));
$err     = fn(string $f) => isset($errors[$f])
    ? '<div class="invalid-feedback-sams">' . e($errors[$f]) . '</div>' : '';
?>
<form method="post" action="<?= $action ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-funnel me-2" style="color:var(--accent)"></i>Lead details</h5>

        <div class="row g-3">
          <?php
          $fields = [
              ['name',     'Full name *', 'text',  'col-md-6'],
              ['company',  'Company',     'text',  'col-md-6'],
              ['email',    'Email',       'email', 'col-md-6'],
              ['phone',    'Phone',       'text',  'col-md-6'],
              ['whatsapp', 'WhatsApp',    'text',  'col-md-6'],
          ];
          foreach ($fields as [$field, $label, $type, $col]): ?>
            <div class="<?= $col ?>">
              <label for="<?= $field ?>" class="form-label-sams"><?= $label ?></label>
              <input type="<?= $type ?>" id="<?= $field ?>" name="<?= $field ?>" value="<?= $value($field) ?>"
                     class="form-control-sams <?= isset($errors[$field]) ? 'is-invalid' : '' ?>">
              <?= $err($field) ?>
            </div>
          <?php endforeach; ?>

          <div class="col-md-6">
            <label for="services" class="form-label-sams">Interested services</label>
            <input type="text" id="services" name="services" value="<?= $value('services') ?>"
                   placeholder="Website, AI automation…" class="form-control-sams">
          </div>

          <div class="col-md-6">
            <label for="last_contact_at" class="form-label-sams">Last contact</label>
            <input type="date" id="last_contact_at" name="last_contact_at" value="<?= $value('last_contact_at') ?>"
                   class="form-control-sams <?= isset($errors['last_contact_at']) ? 'is-invalid' : '' ?>">
            <?= $err('last_contact_at') ?>
          </div>
          <div class="col-md-6">
            <label for="follow_up_at" class="form-label-sams">Next follow-up</label>
            <input type="date" id="follow_up_at" name="follow_up_at" value="<?= $value('follow_up_at') ?>"
                   class="form-control-sams <?= isset($errors['follow_up_at']) ? 'is-invalid' : '' ?>">
            <?= $err('follow_up_at') ?>
          </div>

          <div class="col-12">
            <label for="notes" class="form-label-sams">Notes</label>
            <textarea id="notes" name="notes" rows="4" class="form-control-sams"><?= $value('notes') ?></textarea>
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-sliders me-2" style="color:var(--accent)"></i>Pipeline</h5>

        <label for="source" class="form-label-sams">Source</label>
        <select id="source" name="source" class="form-control-sams mb-3">
          <?php $currentSource = old('source', $lead['source'] ?? 'website'); ?>
          <?php foreach (Lead::SOURCES as $s): ?>
            <option value="<?= $s ?>" <?= $currentSource === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $currentStatus = old('status', $lead['status'] ?? 'new'); ?>
          <?php foreach (Lead::STATUSES as $s): ?>
            <option value="<?= $s ?>" <?= $currentStatus === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="score" class="form-label-sams d-flex justify-content-between">
          Lead score <span id="scoreVal" style="font-family:var(--font-mono);"><?= old('score', (string) ($lead['score'] ?? 50)) ?></span>
        </label>
        <input type="range" id="score" name="score" min="0" max="100" step="5"
               value="<?= old('score', (string) ($lead['score'] ?? 50)) ?>"
               class="form-range mb-4"
               oninput="document.getElementById('scoreVal').textContent = this.value">

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save changes' : 'Add lead' ?>
        </button>
        <a href="<?= url('crm') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>

        <?php if ($editing && $lead['converted_client_id'] === null): ?>
          <hr style="border-color:var(--border);">
          <button type="submit" form="convertForm" class="btn-ghost-sams w-100" style="color:var(--success); border-color:rgba(52,199,123,0.4);">
            <i class="bi bi-person-check me-1"></i> Convert to client
          </button>
        <?php endif; ?>
      </div>
    </div>
  </div>
</form>

<?php if ($editing && $lead['converted_client_id'] === null): ?>
  <form method="post" action="<?= url('crm/' . $lead['id'] . '/convert') ?>" id="convertForm"
        data-confirm="Convert <?= e($lead['name']) ?> into a client?"></form>
  <script>
    /* csrf token for the out-of-flow convert form */
    document.getElementById('convertForm').insertAdjacentHTML('afterbegin',
      '<input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">');
  </script>
<?php endif; ?>
