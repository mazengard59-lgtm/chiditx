<?php
/**
 * CRM lead pipeline.
 * @var array $leads Rows from Lead::pipeline()
 */
use App\Models\Lead;

$sourceIcons = [
    'website' => 'globe', 'facebook' => 'facebook', 'instagram' => 'instagram',
    'referral' => 'people', 'whatsapp' => 'whatsapp', 'other' => 'three-dots',
];
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($leads) ?> lead<?= count($leads) === 1 ? '' : 's' ?> in the pipeline</div>
  <a href="<?= url('crm/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Lead</a>
</div>

<div class="card-sams">
  <?php if ($leads === []): ?>
    <div class="empty-state">
      <i class="bi bi-funnel"></i>
      <p>No leads yet. Every inquiry from your website, WhatsApp, or socials belongs here.</p>
      <a href="<?= url('crm/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Add Lead</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Lead</th>
            <th>Source</th>
            <th>Status</th>
            <th>Score</th>
            <th>Interested in</th>
            <th>Follow-up</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($leads as $l):
              $followDays = days_left($l['follow_up_at']);
              $followTone = $followDays !== null && $followDays <= 0 && !in_array($l['status'], ['won', 'lost'], true)
                  ? 'var(--danger)' : 'var(--text-mid)';
          ?>
            <tr>
              <td>
                <a href="<?= url('crm/' . $l['id'] . '/edit') ?>"><?= e($l['name']) ?></a>
                <div style="font-size:12px; color:var(--text-low);"><?= e($l['company'] ?? ($l['email'] ?? '')) ?></div>
              </td>
              <td><i class="bi bi-<?= $sourceIcons[$l['source']] ?? 'dot' ?> me-1" style="color:var(--text-low);"></i><?= e($l['source']) ?></td>
              <td><span class="badge-soft badge-soft--<?= Lead::STATUS_COLORS[$l['status']] ?? 'muted' ?>"><?= e($l['status']) ?></span></td>
              <td data-order="<?= (int) $l['score'] ?>" style="min-width:90px;">
                <div class="d-flex align-items-center gap-2">
                  <div class="progress flex-grow-1" style="height:5px; background:var(--surface-2);">
                    <div class="progress-bar" style="width:<?= (int) $l['score'] ?>%; background:<?= $l['score'] >= 70 ? 'var(--success)' : ($l['score'] >= 40 ? 'var(--warning)' : 'var(--danger)') ?>;"></div>
                  </div>
                  <span style="font-family:var(--font-mono); font-size:11px;"><?= (int) $l['score'] ?></span>
                </div>
              </td>
              <td style="font-size:12.5px;"><?= e($l['services'] ?? '—') ?></td>
              <td data-order="<?= e($l['follow_up_at'] ?? '9999') ?>" style="color:<?= $followTone ?>;">
                <?= $l['follow_up_at'] ? e(date('M j', strtotime($l['follow_up_at']))) : '—' ?>
                <?= $followDays !== null && $followDays < 0 ? ' <i class="bi bi-exclamation-circle"></i>' : '' ?>
              </td>
              <td class="text-end" style="white-space:nowrap;">
                <?php if ($l['whatsapp']): ?>
                  <a class="icon-btn" title="WhatsApp" target="_blank" rel="noopener"
                     href="https://wa.me/<?= e(preg_replace('/\D/', '', $l['whatsapp'])) ?>"><i class="bi bi-whatsapp"></i></a>
                <?php endif; ?>
                <?php if ($l['converted_client_id'] === null && $l['status'] !== 'lost'): ?>
                  <form method="post" action="<?= url('crm/' . $l['id'] . '/convert') ?>" class="d-inline"
                        data-confirm="Convert <?= e($l['name']) ?> into a client?">
                    <?= csrf_field() ?>
                    <button type="submit" class="icon-btn" title="Convert to client" style="color:var(--success); border-color:rgba(52,199,123,0.4);">
                      <i class="bi bi-person-check"></i>
                    </button>
                  </form>
                <?php elseif ($l['converted_client_id'] !== null): ?>
                  <a href="<?= url('clients/' . $l['converted_client_id']) ?>" class="icon-btn" title="View client"><i class="bi bi-person"></i></a>
                <?php endif; ?>
                <a href="<?= url('crm/' . $l['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('crm/' . $l['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete lead <?= e($l['name']) ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
