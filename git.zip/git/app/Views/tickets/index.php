<?php
/**
 * Support tickets list.
 * @var array $tickets
 */
use App\Models\Ticket;

$priorityBadge = ['low' => 'muted', 'medium' => 'info', 'high' => 'warning', 'urgent' => 'danger'];
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($tickets) ?> ticket<?= count($tickets) === 1 ? '' : 's' ?></div>
  <a href="<?= url('support/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Ticket</a>
</div>

<div class="card-sams">
  <?php if ($tickets === []): ?>
    <div class="empty-state">
      <i class="bi bi-life-preserver"></i>
      <p>No support tickets. When clients report issues, log them here.</p>
      <a href="<?= url('support/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Open Ticket</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Ticket</th>
            <th>Client</th>
            <th>Category</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Replies</th>
            <th>Updated</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tickets as $t): ?>
            <tr>
              <td>
                <a href="<?= url('support/' . $t['id']) ?>">#<?= (int) $t['id'] ?> — <?= e($t['subject']) ?></a>
              </td>
              <td><?= e($t['client_name']) ?></td>
              <td><span class="badge-soft badge-soft--muted"><?= e($t['category']) ?></span></td>
              <td><span class="badge-soft badge-soft--<?= $priorityBadge[$t['priority']] ?? 'muted' ?>"><?= e($t['priority']) ?></span></td>
              <td><span class="badge-soft badge-soft--<?= Ticket::STATUS_COLORS[$t['status']] ?? 'muted' ?>"><?= e($t['status']) ?></span></td>
              <td><?= (int) $t['reply_count'] ?></td>
              <td data-order="<?= e($t['updated_at']) ?>" style="font-size:12.5px; color:var(--text-low);"><?= e(date('M j, H:i', strtotime($t['updated_at']))) ?></td>
              <td class="text-end" style="white-space:nowrap;">
                <a href="<?= url('support/' . $t['id']) ?>" class="icon-btn" title="Open"><i class="bi bi-chat-dots"></i></a>
                <form method="post" action="<?= url('support/' . $t['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete ticket #<?= (int) $t['id'] ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
