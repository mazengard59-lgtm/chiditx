<?php
/**
 * Ticket thread with replies + internal notes.
 * @var array $ticket
 * @var array $replies
 */
use App\Models\Ticket;

$priorityBadge = ['low' => 'muted', 'medium' => 'info', 'high' => 'warning', 'urgent' => 'danger'];
?>
<div class="page-head">
  <a href="<?= url('support') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> All tickets</a>
  <form method="post" action="<?= url('support/' . $ticket['id'] . '/status') ?>" class="d-flex gap-2 align-items-center">
    <?= csrf_field() ?>
    <select name="status" class="form-control-sams" style="width:auto; padding:8px 14px;">
      <?php foreach (Ticket::STATUSES as $s): ?>
        <option value="<?= $s ?>" <?= $ticket['status'] === $s ? 'selected' : '' ?>><?= label($s) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-ghost-sams">Update</button>
  </form>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-8">
    <div class="card-sams p-4 mb-3">
      <div class="d-flex justify-content-between flex-wrap gap-2">
        <div>
          <h4 class="mb-1">#<?= (int) $ticket['id'] ?> — <?= e($ticket['subject']) ?></h4>
          <div style="color:var(--text-mid); font-size:13.5px;">
            <?= e($ticket['client_name']) ?> &middot; opened <?= e(date('M j, Y H:i', strtotime($ticket['created_at']))) ?>
          </div>
        </div>
        <div class="d-flex gap-2" style="align-items:flex-start;">
          <span class="badge-soft badge-soft--muted"><?= e($ticket['category']) ?></span>
          <span class="badge-soft badge-soft--<?= $priorityBadge[$ticket['priority']] ?? 'muted' ?>"><?= e($ticket['priority']) ?></span>
          <span class="badge-soft badge-soft--<?= Ticket::STATUS_COLORS[$ticket['status']] ?? 'muted' ?>"><?= e($ticket['status']) ?></span>
        </div>
      </div>
    </div>

    <?php foreach ($replies as $r): ?>
      <div class="card-sams p-3 mb-2" style="<?= $r['is_internal'] ? 'border-left:3px solid var(--warning);' : '' ?>">
        <div class="d-flex justify-content-between mb-2" style="font-size:12.5px;">
          <strong style="color:var(--text-hi);">
            <?= e($r['user_name'] ?? $ticket['client_name']) ?>
            <?php if ($r['is_internal']): ?>
              <span class="badge-soft badge-soft--warning ms-1">internal note</span>
            <?php endif; ?>
          </strong>
          <span style="color:var(--text-low);"><?= e(date('M j, Y H:i', strtotime($r['created_at']))) ?></span>
        </div>
        <div style="color:var(--text-mid); font-size:14px; white-space:pre-line;"><?= e($r['message']) ?></div>
      </div>
    <?php endforeach; ?>

    <?php if ($replies === []): ?>
      <div class="card-sams"><div class="empty-state"><i class="bi bi-chat"></i><p>No messages yet.</p></div></div>
    <?php endif; ?>

    <div class="card-sams p-4 mt-3">
      <form method="post" action="<?= url('support/' . $ticket['id'] . '/reply') ?>">
        <?= csrf_field() ?>
        <label for="message" class="form-label-sams">Reply</label>
        <textarea id="message" name="message" rows="4" class="form-control-sams mb-3" required></textarea>
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <label class="form-label-sams d-flex align-items-center gap-2 m-0" style="cursor:pointer;">
            <input type="checkbox" name="is_internal" value="1" class="form-check-input m-0">
            Internal note (hidden from client portal)
          </label>
          <button type="submit" class="btn-sams"><i class="bi bi-send me-1"></i> Send reply</button>
        </div>
      </form>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="card-sams p-4">
      <h5 class="mb-3"><i class="bi bi-person me-2" style="color:var(--accent)"></i>Client</h5>
      <dl class="info-list">
        <dt>Name</dt><dd><a href="<?= url('clients/' . $ticket['client_id']) ?>" style="color:var(--accent);"><?= e($ticket['client_name']) ?></a></dd>
        <?php if ($ticket['client_email']): ?><dt>Email</dt><dd><?= e($ticket['client_email']) ?></dd><?php endif; ?>
      </dl>
      <?php if ($ticket['client_whatsapp']): ?>
        <a class="btn-ghost-sams w-100 d-block text-center mt-3" target="_blank" rel="noopener"
           href="https://wa.me/<?= e(preg_replace('/\D/', '', $ticket['client_whatsapp'])) ?>">
          <i class="bi bi-whatsapp me-1"></i> WhatsApp client
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>
