<?php
/**
 * New ticket form.
 * @var array $clientOptions id => label
 * @var array $errors
 */
use App\Models\Ticket;
?>
<form method="post" action="<?= url('support') ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-life-preserver me-2" style="color:var(--accent)"></i>Ticket details</h5>

        <label for="subject" class="form-label-sams">Subject *</label>
        <input type="text" id="subject" name="subject" value="<?= old('subject') ?>"
               class="form-control-sams mb-1 <?= isset($errors['subject']) ? 'is-invalid' : '' ?>">
        <?php if (isset($errors['subject'])): ?><div class="invalid-feedback-sams mb-2"><?= e($errors['subject']) ?></div><?php endif; ?>

        <label for="message" class="form-label-sams mt-3">First message</label>
        <textarea id="message" name="message" rows="6" class="form-control-sams"
                  placeholder="Describe the issue…"><?= old('message') ?></textarea>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-sliders me-2" style="color:var(--accent)"></i>Classification</h5>

        <label for="client_id" class="form-label-sams">Client *</label>
        <select id="client_id" name="client_id" class="form-control-sams mb-1 <?= isset($errors['client_id']) ? 'is-invalid' : '' ?>">
          <option value="">— Choose client —</option>
          <?php $currentClient = (int) old('client_id', '0'); ?>
          <?php foreach ($clientOptions as $cid => $label): ?>
            <option value="<?= $cid ?>" <?= $currentClient === $cid ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (isset($errors['client_id'])): ?><div class="invalid-feedback-sams mb-2"><?= e($errors['client_id']) ?></div><?php endif; ?>

        <label for="category" class="form-label-sams mt-3">Category</label>
        <select id="category" name="category" class="form-control-sams mb-3">
          <?php foreach (Ticket::CATEGORIES as $c): ?>
            <option value="<?= $c ?>" <?= old('category', 'general') === $c ? 'selected' : '' ?>><?= label($c) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="priority" class="form-label-sams">Priority</label>
        <select id="priority" name="priority" class="form-control-sams mb-4">
          <?php foreach (Ticket::PRIORITIES as $p): ?>
            <option value="<?= $p ?>" <?= old('priority', 'medium') === $p ? 'selected' : '' ?>><?= label($p) ?></option>
          <?php endforeach; ?>
        </select>

        <button type="submit" class="btn-sams w-100 mb-2"><i class="bi bi-check-lg me-1"></i> Open ticket</button>
        <a href="<?= url('support') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>
