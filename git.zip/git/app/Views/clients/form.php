<?php
/**
 * Client create/edit form (shared).
 * @var array|null $client Existing client row when editing, null when creating
 * @var array      $errors Validation errors keyed by field
 */
$editing = $client !== null;
$action  = $editing ? url('clients/' . $client['id']) : url('clients');
$value   = fn(string $f) => old($f, (string) ($client[$f] ?? ''));
?>
<form method="post" action="<?= $action ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-person me-2" style="color:var(--accent)"></i>Client details</h5>

        <div class="row g-3">
          <?php
          $fields = [
              ['name',     'Full name *',  'text',  'col-md-6'],
              ['company',  'Company',      'text',  'col-md-6'],
              ['industry', 'Industry',     'text',  'col-md-6'],
              ['email',    'Email',        'email', 'col-md-6'],
              ['phone',    'Phone',        'text',  'col-md-6'],
              ['whatsapp', 'WhatsApp',     'text',  'col-md-6'],
              ['country',  'Country',      'text',  'col-md-6'],
              ['timezone', 'Timezone',     'text',  'col-md-6'],
              ['address',  'Address',      'text',  'col-12'],
              ['photo_url','Photo URL',    'url',   'col-12'],
              ['tags',     'Tags (comma-separated)', 'text', 'col-12'],
          ];
          foreach ($fields as [$field, $label, $type, $col]): ?>
            <div class="<?= $col ?>">
              <label for="<?= $field ?>" class="form-label-sams"><?= $label ?></label>
              <input type="<?= $type ?>" id="<?= $field ?>" name="<?= $field ?>"
                     value="<?= $value($field) ?>"
                     class="form-control-sams <?= isset($errors[$field]) ? 'is-invalid' : '' ?>">
              <?php if (isset($errors[$field])): ?>
                <div class="invalid-feedback-sams"><?= e($errors[$field]) ?></div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>

          <div class="col-12">
            <label for="notes" class="form-label-sams">Notes</label>
            <textarea id="notes" name="notes" rows="4" class="form-control-sams"><?= $value('notes') ?></textarea>
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-sliders me-2" style="color:var(--accent)"></i>Classification</h5>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $current = old('status', $client['status'] ?? 'regular'); ?>
          <?php foreach (App\Models\Client::STATUSES as $s): ?>
            <option value="<?= $s ?>" <?= $current === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (isset($errors['status'])): ?>
          <div class="invalid-feedback-sams mb-3"><?= e($errors['status']) ?></div>
        <?php endif; ?>

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save changes' : 'Add client' ?>
        </button>
        <a href="<?= $editing ? url('clients/' . $client['id']) : url('clients') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>
