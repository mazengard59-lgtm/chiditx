<?php
/**
 * Clients list.
 * @var array $clients Rows from Client::allWithProjectCounts()
 */
$statusBadge = ['vip' => 'accent', 'regular' => 'info', 'inactive' => 'muted'];
?>
<div class="page-head">
  <div>
    <div class="page-head__sub"><?= count($clients) ?> client<?= count($clients) === 1 ? '' : 's' ?> total</div>
  </div>
  <a href="<?= url('clients/create') ?>" class="btn-sams">
    <i class="bi bi-plus-lg me-1"></i> New Client
  </a>
</div>

<div class="card-sams">
  <?php if ($clients === []): ?>
    <div class="empty-state">
      <i class="bi bi-people"></i>
      <p>No clients yet. Add your first client to get started.</p>
      <a href="<?= url('clients/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Add Client</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Client</th>
            <th>Contact</th>
            <th>Country</th>
            <th>Status</th>
            <th>Projects</th>
            <th>Value</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($clients as $c): ?>
            <tr>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <img class="avatar-sm"
                       src="<?= e($c['photo_url'] ?: 'https://ui-avatars.com/api/?background=1D1B1F&color=E8342A&name=' . urlencode($c['name'])) ?>"
                       alt="">
                  <div>
                    <a href="<?= url('clients/' . $c['id']) ?>"><?= e($c['name']) ?></a>
                    <div style="font-size:12px; color:var(--text-low);"><?= e($c['company'] ?? '') ?></div>
                  </div>
                </div>
              </td>
              <td>
                <?= e($c['email'] ?? '') ?>
                <div style="font-size:12px; color:var(--text-low);"><?= e($c['phone'] ?? '') ?></div>
              </td>
              <td><?= e($c['country'] ?? '—') ?></td>
              <td><span class="badge-soft badge-soft--<?= $statusBadge[$c['status']] ?? 'muted' ?>"><?= e($c['status']) ?></span></td>
              <td><?= (int) $c['project_count'] ?></td>
              <td data-order="<?= (float) $c['total_value'] ?>"><?= money($c['total_value']) ?></td>
              <td class="text-end" style="white-space:nowrap;">
                <a href="<?= url('clients/' . $c['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('clients/' . $c['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete <?= e($c['name']) ?>? Their projects will be deleted too.">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
