<?php
/**
 * Client profile.
 * @var array $client
 * @var array $projects Projects belonging to this client
 */
$statusBadge = ['vip' => 'accent', 'regular' => 'info', 'inactive' => 'muted'];
?>
<div class="page-head">
  <a href="<?= url('clients') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> All clients</a>
  <div class="d-flex gap-2">
    <?php if (!empty($client['whatsapp'])): ?>
      <a href="https://wa.me/<?= e(preg_replace('/\D/', '', $client['whatsapp'])) ?>" target="_blank" class="btn-ghost-sams">
        <i class="bi bi-whatsapp me-1"></i> WhatsApp
      </a>
    <?php endif; ?>
    <a href="<?= url('clients/' . $client['id'] . '/edit') ?>" class="btn-sams"><i class="bi bi-pencil me-1"></i> Edit</a>
  </div>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-4">
    <div class="card-sams p-4">
      <div class="d-flex align-items-center gap-3 mb-3">
        <img class="avatar-lg"
             src="<?= e($client['photo_url'] ?: 'https://ui-avatars.com/api/?background=1D1B1F&color=E8342A&size=168&name=' . urlencode($client['name'])) ?>"
             alt="<?= e($client['name']) ?>">
        <div>
          <h4 class="mb-1"><?= e($client['name']) ?></h4>
          <span class="badge-soft badge-soft--<?= $statusBadge[$client['status']] ?? 'muted' ?>"><?= e($client['status']) ?></span>
        </div>
      </div>

      <dl class="info-list">
        <?php
        $rows = [
            'Company'  => $client['company'],
            'Industry' => $client['industry'],
            'Email'    => $client['email'],
            'Phone'    => $client['phone'],
            'WhatsApp' => $client['whatsapp'],
            'Country'  => $client['country'],
            'Timezone' => $client['timezone'],
            'Address'  => $client['address'],
        ];
        foreach ($rows as $dt => $dd): if (!$dd) continue; ?>
          <dt><?= $dt ?></dt><dd><?= e($dd) ?></dd>
        <?php endforeach; ?>

        <?php if (!empty($client['tags'])): ?>
          <dt>Tags</dt>
          <dd>
            <?php foreach (array_filter(array_map('trim', explode(',', $client['tags']))) as $tag): ?>
              <span class="badge-soft badge-soft--muted me-1"><?= e($tag) ?></span>
            <?php endforeach; ?>
          </dd>
        <?php endif; ?>

        <dt>Client since</dt><dd><?= e(date('M j, Y', strtotime($client['created_at']))) ?></dd>
        <dt>Portal access</dt>
        <dd>
          <?php if ($client['user_id'] !== null): ?>
            <span class="badge-soft badge-soft--success"><i class="bi bi-check-lg me-1"></i>enabled</span>
          <?php else: ?>
            <form method="post" action="<?= url('clients/' . $client['id'] . '/portal') ?>" class="mt-1"
                  data-confirm="Create a portal login for <?= e($client['name']) ?>? A one-time password will be generated.">
              <?= csrf_field() ?>
              <button type="submit" class="btn-ghost-sams" style="padding:6px 14px; font-size:12.5px;">
                <i class="bi bi-key me-1"></i> Create portal account
              </button>
            </form>
          <?php endif; ?>
        </dd>
      </dl>

      <?php if (!empty($client['notes'])): ?>
        <hr style="border-color:var(--border);">
        <dt class="info-list" style="font-family:var(--font-mono); font-size:10.5px; text-transform:uppercase; letter-spacing:.08em; color:var(--text-low);">Notes</dt>
        <p style="font-size:13.5px; color:var(--text-mid); margin-top:6px; white-space:pre-line;"><?= e($client['notes']) ?></p>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-8">
    <div class="card-sams">
      <div class="panel-header">
        <h5><i class="bi bi-kanban me-2" style="color:var(--accent)"></i>Projects (<?= count($projects) ?>)</h5>
        <a href="<?= url('projects/create') ?>" class="btn-ghost-sams"><i class="bi bi-plus-lg me-1"></i> New project</a>
      </div>

      <?php if ($projects === []): ?>
        <div class="empty-state">
          <i class="bi bi-kanban"></i>
          <p>No projects for this client yet.</p>
        </div>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table-sams w-100">
            <thead>
              <tr><th>Project</th><th>Status</th><th>Progress</th><th>Price</th><th>Deadline</th></tr>
            </thead>
            <tbody>
              <?php foreach ($projects as $p): ?>
                <tr>
                  <td><a href="<?= url('projects/' . $p['id']) ?>"><?= e($p['name']) ?></a></td>
                  <td><span class="badge-soft badge-soft--<?= App\Models\Project::STATUS_COLORS[$p['status']] ?? 'muted' ?>"><?= label($p['status']) ?></span></td>
                  <td style="min-width:120px;">
                    <div class="d-flex align-items-center gap-2">
                      <div class="progress flex-grow-1" style="height:6px; background:var(--surface-2);">
                        <div class="progress-bar" style="width:<?= (int) $p['progress'] ?>%; background:var(--accent);"></div>
                      </div>
                      <span style="font-family:var(--font-mono); font-size:11px;"><?= (int) $p['progress'] ?>%</span>
                    </div>
                  </td>
                  <td><?= money($p['price']) ?></td>
                  <td><?= $p['deadline'] ? e(date('M j, Y', strtotime($p['deadline']))) : '—' ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
