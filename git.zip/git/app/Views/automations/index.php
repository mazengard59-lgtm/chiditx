<?php
/**
 * AI automations list.
 * @var array $automations
 */
use App\Models\Automation;
?>
<div class="page-head">
  <div class="page-head__sub"><?= count($automations) ?> automation<?= count($automations) === 1 ? '' : 's' ?></div>
  <a href="<?= url('automations/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Automation</a>
</div>

<div class="card-sams">
  <?php if ($automations === []): ?>
    <div class="empty-state">
      <i class="bi bi-robot"></i>
      <p>No automation projects yet. Track every bot, workflow, and AI integration here.</p>
      <a href="<?= url('automations/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Add Automation</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Automation</th>
            <th>Platform</th>
            <th>Client</th>
            <th>Version</th>
            <th>Status</th>
            <th>Errors</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($automations as $a): ?>
            <tr>
              <td><a href="<?= url('automations/' . $a['id']) ?>"><?= e($a['name']) ?></a></td>
              <td>
                <i class="bi bi-<?= Automation::PLATFORM_ICONS[$a['platform']] ?? 'robot' ?> me-1" style="color:var(--text-low);"></i>
                <?= label($a['platform']) ?>
              </td>
              <td><?= e($a['client_name'] ?? '— internal —') ?></td>
              <td style="font-family:var(--font-mono); font-size:12px;"><?= e($a['version']) ?></td>
              <td><span class="badge-soft badge-soft--<?= Automation::STATUS_COLORS[$a['status']] ?? 'muted' ?>"><?= e($a['status']) ?></span></td>
              <td>
                <?php if ((int) $a['error_count'] > 0): ?>
                  <span class="badge-soft badge-soft--danger"><?= (int) $a['error_count'] ?></span>
                <?php else: ?>—<?php endif; ?>
              </td>
              <td class="text-end" style="white-space:nowrap;">
                <a href="<?= url('automations/' . $a['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('automations/' . $a['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete automation <?= e($a['name']) ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
