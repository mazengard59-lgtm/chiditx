<?php
/**
 * Automation create/edit form.
 * @var array|null $automation
 * @var array      $clientOptions
 * @var array      $errors
 */
use App\Models\Automation;

$editing = $automation !== null;
$action  = $editing ? url('automations/' . $automation['id']) : url('automations');
$value   = fn(string $f) => old($f, (string) ($automation[$f] ?? ''));
?>
<form method="post" action="<?= $action ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4 mb-3">
        <h5 class="mb-4"><i class="bi bi-robot me-2" style="color:var(--accent)"></i>Automation details</h5>

        <div class="row g-3">
          <div class="col-md-8">
            <label for="name" class="form-label-sams">Name *</label>
            <input type="text" id="name" name="name" value="<?= $value('name') ?>"
                   placeholder="e.g. WhatsApp Order Bot" class="form-control-sams <?= isset($errors['name']) ? 'is-invalid' : '' ?>">
            <?php if (isset($errors['name'])): ?><div class="invalid-feedback-sams"><?= e($errors['name']) ?></div><?php endif; ?>
          </div>
          <div class="col-md-4">
            <label for="platform" class="form-label-sams">Platform</label>
            <select id="platform" name="platform" class="form-control-sams">
              <?php $currentPlatform = old('platform', $automation['platform'] ?? 'whatsapp'); ?>
              <?php foreach (Automation::PLATFORMS as $p): ?>
                <option value="<?= $p ?>" <?= $currentPlatform === $p ? 'selected' : '' ?>><?= label($p) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-12">
            <label for="description" class="form-label-sams">What does it do?</label>
            <textarea id="description" name="description" rows="2" class="form-control-sams"><?= $value('description') ?></textarea>
          </div>

          <div class="col-12">
            <label for="prompt" class="form-label-sams">System prompt / AI instructions</label>
            <textarea id="prompt" name="prompt" rows="6" class="form-control-sams" style="font-family:var(--font-mono); font-size:13px;"
                      placeholder="You are a customer support assistant for…"><?= $value('prompt') ?></textarea>
          </div>

          <div class="col-12">
            <label for="workflow" class="form-label-sams">Workflow (steps, triggers, actions)</label>
            <textarea id="workflow" name="workflow" rows="5" class="form-control-sams" style="font-family:var(--font-mono); font-size:13px;"
                      placeholder="1. Customer messages → 2. Intent detection → 3. …"><?= $value('workflow') ?></textarea>
          </div>

          <div class="col-12">
            <label for="webhook_url" class="form-label-sams">Webhook URL</label>
            <input type="url" id="webhook_url" name="webhook_url" value="<?= $value('webhook_url') ?>"
                   placeholder="https://" class="form-control-sams">
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-sliders me-2" style="color:var(--accent)"></i>Tracking</h5>

        <label for="client_id" class="form-label-sams">Client</label>
        <select id="client_id" name="client_id" class="form-control-sams mb-3">
          <option value="">— Internal / agency —</option>
          <?php $currentClient = (int) old('client_id', (string) ($automation['client_id'] ?? 0)); ?>
          <?php foreach ($clientOptions as $cid => $label): ?>
            <option value="<?= $cid ?>" <?= $currentClient === $cid ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="status" class="form-label-sams">Status</label>
        <select id="status" name="status" class="form-control-sams mb-3">
          <?php $currentStatus = old('status', $automation['status'] ?? 'development'); ?>
          <?php foreach (Automation::STATUSES as $s): ?>
            <option value="<?= $s ?>" <?= $currentStatus === $s ? 'selected' : '' ?>><?= label($s) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="version" class="form-label-sams">Version</label>
        <input type="text" id="version" name="version" value="<?= old('version', $automation['version'] ?? 'v1.0') ?>"
               class="form-control-sams mb-4" style="font-family:var(--font-mono);">

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save changes' : 'Create automation' ?>
        </button>
        <a href="<?= $editing ? url('automations/' . $automation['id']) : url('automations') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>
