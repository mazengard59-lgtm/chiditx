<?php
/**
 * Automation detail + execution logs.
 * @var array $automation
 * @var array $logs
 */
use App\Models\Automation;

$levelTone = ['info' => 'var(--info)', 'success' => 'var(--success)', 'error' => 'var(--danger)'];
?>
<div class="page-head">
  <a href="<?= url('automations') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> All automations</a>
  <a href="<?= url('automations/' . $automation['id'] . '/edit') ?>" class="btn-sams"><i class="bi bi-pencil me-1"></i> Edit</a>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-7">
    <div class="card-sams p-4 mb-3">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
        <div>
          <h3 class="mb-1">
            <i class="bi bi-<?= Automation::PLATFORM_ICONS[$automation['platform']] ?? 'robot' ?> me-2" style="color:var(--accent);"></i>
            <?= e($automation['name']) ?>
          </h3>
          <div style="color:var(--text-mid); font-size:13.5px;">
            <?= label($automation['platform']) ?>
            <?= $automation['client_name'] ? ' · ' . e($automation['client_name']) : ' · internal' ?>
            · <span style="font-family:var(--font-mono);"><?= e($automation['version']) ?></span>
          </div>
        </div>
        <span class="badge-soft badge-soft--<?= Automation::STATUS_COLORS[$automation['status']] ?? 'muted' ?>"><?= e($automation['status']) ?></span>
      </div>

      <?php if ($automation['description']): ?>
        <p style="color:var(--text-mid);"><?= e($automation['description']) ?></p>
      <?php endif; ?>

      <?php if ($automation['prompt']): ?>
        <div class="page-head__sub mb-1 mt-3">SYSTEM PROMPT</div>
        <pre style="background:var(--surface-2); border:1px solid var(--border); border-radius:var(--radius-sm); padding:14px; font-family:var(--font-mono); font-size:12.5px; color:var(--text-mid); white-space:pre-wrap; max-height:260px; overflow:auto;"><?= e($automation['prompt']) ?></pre>
      <?php endif; ?>

      <?php if ($automation['workflow']): ?>
        <div class="page-head__sub mb-1 mt-3">WORKFLOW</div>
        <pre style="background:var(--surface-2); border:1px solid var(--border); border-radius:var(--radius-sm); padding:14px; font-family:var(--font-mono); font-size:12.5px; color:var(--text-mid); white-space:pre-wrap; max-height:220px; overflow:auto;"><?= e($automation['workflow']) ?></pre>
      <?php endif; ?>

      <?php if ($automation['webhook_url']): ?>
        <div class="page-head__sub mb-1 mt-3">WEBHOOK</div>
        <code style="font-size:12.5px; color:var(--accent); word-break:break-all;"><?= e($automation['webhook_url']) ?></code>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-5">
    <div class="card-sams mb-3">
      <div class="panel-header"><h5><i class="bi bi-journal-code me-2" style="color:var(--accent)"></i>Logs</h5></div>
      <?php if ($logs === []): ?>
        <div class="empty-state"><i class="bi bi-journal"></i><p>No log entries yet.</p></div>
      <?php else: ?>
        <div style="max-height:420px; overflow-y:auto;">
          <?php foreach ($logs as $log): ?>
            <div class="activity-item">
              <span class="activity-item__dot" style="background:<?= $levelTone[$log['level']] ?? 'var(--text-low)' ?>;"></span>
              <div>
                <div style="font-size:13.5px; color:var(--text-mid);"><?= e($log['message']) ?></div>
                <div class="activity-item__meta"><?= e($log['level']) ?> &middot; <?= e(date('M j, Y H:i', strtotime($log['created_at']))) ?></div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="card-sams p-4">
      <h6 class="mb-3">Add log entry</h6>
      <form method="post" action="<?= url('automations/' . $automation['id'] . '/log') ?>">
        <?= csrf_field() ?>
        <div class="d-flex gap-2 mb-2">
          <select name="level" class="form-control-sams" style="max-width:120px;">
            <option value="info">Info</option>
            <option value="success">Success</option>
            <option value="error">Error</option>
          </select>
          <input type="text" name="message" class="form-control-sams" placeholder="What happened?" required maxlength="1000">
        </div>
        <button type="submit" class="btn-ghost-sams w-100">Add entry</button>
      </form>
    </div>
  </div>
</div>
