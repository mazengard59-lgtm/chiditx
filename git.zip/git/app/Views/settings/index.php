<?php
/**
 * Settings — tabbed: general, integrations, AI keys, users, activity, backup.
 * @var array  $settings   key => value
 * @var array  $users
 * @var array  $activities
 * @var string $tab        active tab
 * @var array  $errors
 */
$v = fn(string $key) => e($settings[$key] ?? '');
$tabs = [
    'general'      => ['building', 'Agency'],
    'integrations' => ['plug', 'Integrations'],
    'ai'           => ['robot', 'AI Keys'],
    'users'        => ['people', 'Users'],
    'activity'     => ['activity', 'Activity'],
    'backup'       => ['database-down', 'Backup'],
];
if (!isset($tabs[$tab])) { $tab = 'general'; }

/** Renders a labeled input bound to a setting key. */
$field = function (string $key, string $label, string $type = 'text', string $hint = '') use ($v): string {
    $hintHtml = $hint ? '<div class="page-head__sub mb-2">' . e($hint) . '</div>' : '';
    return <<<HTML
      <div class="col-md-6">
        <label for="{$key}" class="form-label-sams">{$label}</label>
        <input type="{$type}" id="{$key}" name="{$key}" value="{$v($key)}" class="form-control-sams" autocomplete="off">
        {$hintHtml}
      </div>
    HTML;
};
?>
<ul class="nav nav-pills mb-4 flex-wrap" style="gap:6px;">
  <?php foreach ($tabs as $key => [$icon, $label]): ?>
    <li class="nav-item">
      <a href="<?= url('settings?tab=' . $key) ?>"
         class="app-footer__link <?= $tab === $key ? 'is-active' : '' ?>"
         style="display:inline-flex; flex-direction:row; gap:8px; font-size:13px; padding:8px 16px; border:1px solid var(--border); border-radius:10px;">
        <i class="bi bi-<?= $icon ?>"></i><span><?= $label ?></span>
      </a>
    </li>
  <?php endforeach; ?>
</ul>

<?php if ($tab === 'general'): ?>
  <div class="card-sams p-4">
    <h5 class="mb-4"><i class="bi bi-building me-2" style="color:var(--accent)"></i>Agency information &amp; branding</h5>
    <form method="post" action="<?= url('settings/save') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="group" value="general">
      <div class="row g-3">
        <?= $field('agency_name', 'Agency name') ?>
        <?= $field('agency_tagline', 'Tagline') ?>
        <?= $field('agency_logo_url', 'Logo URL', 'url') ?>
        <?= $field('agency_email', 'Public email', 'email') ?>
        <?= $field('agency_whatsapp', 'WhatsApp number', 'text', 'International format, digits only — e.g. 2348084508767') ?>
        <div class="col-md-6">
          <label for="default_theme" class="form-label-sams">Default theme</label>
          <select id="default_theme" name="default_theme" class="form-control-sams">
            <option value="dark" <?= ($settings['default_theme'] ?? 'dark') === 'dark' ? 'selected' : '' ?>>Dark</option>
            <option value="light" <?= ($settings['default_theme'] ?? '') === 'light' ? 'selected' : '' ?>>Light</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn-sams mt-4"><i class="bi bi-check-lg me-1"></i> Save agency settings</button>
    </form>
  </div>

<?php elseif ($tab === 'integrations'): ?>
  <div class="card-sams p-4">
    <h5 class="mb-4"><i class="bi bi-plug me-2" style="color:var(--accent)"></i>Integrations</h5>
    <form method="post" action="<?= url('settings/save') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="group" value="integrations">
      <div class="row g-3">
        <?= $field('emailjs_service_id', 'EmailJS service ID', 'text', 'Used for renewal reminder emails') ?>
        <?= $field('emailjs_template_id', 'EmailJS template ID') ?>
        <?= $field('emailjs_public_key', 'EmailJS public key') ?>
        <?= $field('cloudinary_cloud_name', 'Cloudinary cloud name') ?>
        <?= $field('cloudinary_upload_preset', 'Cloudinary upload preset', 'text', 'Unsigned preset for browser uploads') ?>
        <?= $field('paystack_public_key', 'Paystack public key') ?>
        <?= $field('flutterwave_public_key', 'Flutterwave public key') ?>
        <?= $field('ga_measurement_id', 'Google Analytics ID', 'text', 'e.g. G-XXXXXXXXXX') ?>
      </div>
      <button type="submit" class="btn-sams mt-4"><i class="bi bi-check-lg me-1"></i> Save integrations</button>
    </form>
  </div>

<?php elseif ($tab === 'ai'): ?>
  <div class="card-sams p-4">
    <h5 class="mb-2"><i class="bi bi-robot me-2" style="color:var(--accent)"></i>AI provider keys</h5>
    <p class="page-head__sub mb-4">Stored server-side, never exposed to public pages. Used by automation integrations.</p>
    <form method="post" action="<?= url('settings/save') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="group" value="ai">
      <div class="row g-3">
        <?= $field('openai_api_key', 'OpenAI API key', 'password') ?>
        <?= $field('claude_api_key', 'Claude (Anthropic) API key', 'password') ?>
        <?= $field('gemini_api_key', 'Gemini API key', 'password') ?>
      </div>
      <button type="submit" class="btn-sams mt-4"><i class="bi bi-check-lg me-1"></i> Save AI keys</button>
    </form>
  </div>

<?php elseif ($tab === 'users'): ?>
  <div class="row g-3">
    <div class="col-12 col-lg-7">
      <div class="card-sams">
        <div class="panel-header"><h5><i class="bi bi-people me-2" style="color:var(--accent)"></i>Team &amp; portal users</h5></div>
        <div class="table-wrap">
          <table class="table-sams w-100">
            <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Last login</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($users as $u): ?>
                <tr>
                  <td>
                    <strong style="color:var(--text-hi);"><?= e($u['name']) ?></strong>
                    <div style="font-size:12px; color:var(--text-low);"><?= e($u['email']) ?></div>
                  </td>
                  <td><span class="badge-soft badge-soft--<?= $u['role'] === 'admin' ? 'accent' : ($u['role'] === 'client' ? 'info' : 'muted') ?>"><?= e($u['role']) ?></span></td>
                  <td><span class="badge-soft badge-soft--<?= $u['status'] === 'active' ? 'success' : 'muted' ?>"><?= e($u['status']) ?></span></td>
                  <td style="font-size:12px; color:var(--text-low);"><?= $u['last_login_at'] ? e(date('M j, H:i', strtotime($u['last_login_at']))) : 'never' ?></td>
                  <td class="text-end" style="white-space:nowrap;">
                    <form method="post" action="<?= url('settings/users/' . $u['id'] . '/reset') ?>" class="d-inline" data-confirm="Generate a new password for <?= e($u['name']) ?>?">
                      <?= csrf_field() ?>
                      <button type="submit" class="icon-btn" title="Reset password"><i class="bi bi-key"></i></button>
                    </form>
                    <?php if ((int) $u['id'] !== (int) auth()['id']): ?>
                      <form method="post" action="<?= url('settings/users/' . $u['id'] . '/toggle') ?>" class="d-inline"
                            data-confirm="<?= $u['status'] === 'active' ? 'Deactivate' : 'Activate' ?> <?= e($u['name']) ?>?">
                        <?= csrf_field() ?>
                        <button type="submit" class="icon-btn" title="<?= $u['status'] === 'active' ? 'Deactivate' : 'Activate' ?>">
                          <i class="bi bi-<?= $u['status'] === 'active' ? 'pause-circle' : 'play-circle' ?>"></i>
                        </button>
                      </form>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-5">
      <div class="card-sams p-4">
        <h5 class="mb-3"><i class="bi bi-person-plus me-2" style="color:var(--accent)"></i>Add team member</h5>
        <form method="post" action="<?= url('settings/users') ?>">
          <?= csrf_field() ?>
          <label for="name" class="form-label-sams">Name *</label>
          <input type="text" id="name" name="name" value="<?= old('name') ?>"
                 class="form-control-sams mb-1 <?= isset($errors['name']) ? 'is-invalid' : '' ?>">
          <?php if (isset($errors['name'])): ?><div class="invalid-feedback-sams"><?= e($errors['name']) ?></div><?php endif; ?>

          <label for="email" class="form-label-sams mt-3">Email *</label>
          <input type="email" id="email" name="email" value="<?= old('email') ?>"
                 class="form-control-sams mb-1 <?= isset($errors['email']) ? 'is-invalid' : '' ?>">
          <?php if (isset($errors['email'])): ?><div class="invalid-feedback-sams"><?= e($errors['email']) ?></div><?php endif; ?>

          <label for="role" class="form-label-sams mt-3">Role</label>
          <select id="role" name="role" class="form-control-sams mb-4">
            <option value="staff">Staff</option>
            <option value="admin">Admin</option>
          </select>

          <button type="submit" class="btn-sams w-100"><i class="bi bi-check-lg me-1"></i> Create user</button>
          <div class="page-head__sub mt-2">A one-time password is generated and shown after creation. Client portal accounts are created from each client's profile page.</div>
        </form>
      </div>
    </div>
  </div>

<?php elseif ($tab === 'activity'): ?>
  <div class="card-sams">
    <div class="panel-header"><h5><i class="bi bi-activity me-2" style="color:var(--accent)"></i>Activity log (last 30)</h5></div>
    <?php foreach ($activities as $a): ?>
      <div class="activity-item">
        <span class="activity-item__dot"></span>
        <div>
          <div><strong><?= e($a['user_name'] ?? 'System') ?></strong> — <?= e($a['description']) ?></div>
          <div class="activity-item__meta">
            <?= e($a['action']) ?> &middot; <?= e($a['created_at']) ?>
            <?= $a['ip_address'] ? '&middot; ' . e($a['ip_address']) : '' ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

<?php elseif ($tab === 'backup'): ?>
  <div class="card-sams p-4">
    <h5 class="mb-2"><i class="bi bi-database-down me-2" style="color:var(--accent)"></i>Database backup</h5>
    <p class="page-head__sub mb-4">
      Downloads a full SQL dump of every table (structure + data), generated in pure PHP —
      works on shared hosting with no shell access. Store backups somewhere safe off the server.
    </p>
    <a href="<?= url('settings/backup') ?>" class="btn-sams" style="display:inline-block;">
      <i class="bi bi-download me-1"></i> Download backup (.sql)
    </a>
  </div>
<?php endif; ?>
