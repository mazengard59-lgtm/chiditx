<?php
/**
 * Print-optimized invoice — browser print dialog = PDF download.
 * @var array $invoice Full invoice from Invoice::findFull()
 */
$balance = (float) $invoice['total'] - (float) $invoice['amount_paid'];
$owner = config('owner');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= e($invoice['invoice_number']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Inter', sans-serif; color: #17161A; background: #fff; padding: 48px; font-size: 14px; }
  .head { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; }
  .brand { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 26px; }
  .brand .dot { color: #E8342A; }
  .brand-sub { color: #666; font-size: 12.5px; margin-top: 4px; }
  .inv-no { font-family: 'JetBrains Mono', monospace; font-size: 18px; text-align: right; }
  .inv-status { display: inline-block; margin-top: 6px; padding: 3px 12px; border-radius: 999px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;
    background: <?= $invoice['status'] === 'paid' ? '#e8f8ef; color:#1d7a4b' : ($invoice['status'] === 'overdue' ? '#fdeceb; color:#c02418' : '#eef4fd; color:#2563b5') ?>; }
  .meta { display: flex; justify-content: space-between; gap: 24px; margin-bottom: 36px; }
  .meta h4 { font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: #999; margin-bottom: 8px; }
  .meta p { line-height: 1.55; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: #999; padding: 10px 12px; border-bottom: 2px solid #eee; }
  th.r, td.r { text-align: right; }
  td { padding: 12px; border-bottom: 1px solid #f0f0f0; }
  .totals { margin-left: auto; width: 280px; }
  .totals .row { display: flex; justify-content: space-between; padding: 6px 12px; }
  .totals .grand { border-top: 2px solid #17161A; font-weight: 700; font-size: 16px; padding-top: 10px; margin-top: 4px; }
  .notes { margin-top: 32px; padding: 16px; background: #fafafa; border-radius: 8px; font-size: 12.5px; color: #555; white-space: pre-line; }
  .foot { margin-top: 48px; text-align: center; color: #aaa; font-size: 11.5px; }
  .print-bar { position: fixed; top: 16px; right: 16px; }
  .print-bar button { background: #E8342A; color: #fff; border: none; padding: 10px 22px; border-radius: 8px; font-family: 'Inter', sans-serif; font-weight: 600; cursor: pointer; }
  @media print { .print-bar { display: none; } body { padding: 24px; } }
</style>
</head>
<body>
<div class="print-bar"><button onclick="window.print()">🖨 Print / Save PDF</button></div>

<div class="head">
  <div>
    <div class="brand">CHIDI<span class="dot">.</span></div>
    <div class="brand-sub">
      <?= e($owner['name']) ?> — Software Agency<br>
      <?= e($owner['email']) ?> · WhatsApp +<?= e($owner['whatsapp']) ?>
    </div>
  </div>
  <div>
    <div class="inv-no"><?= e($invoice['invoice_number']) ?></div>
    <div style="text-align:right;"><span class="inv-status"><?= e($invoice['status']) ?></span></div>
  </div>
</div>

<div class="meta">
  <div>
    <h4>Billed to</h4>
    <p>
      <strong><?= e($invoice['client_name']) ?></strong><br>
      <?= $invoice['client_company'] ? e($invoice['client_company']) . '<br>' : '' ?>
      <?= $invoice['client_email'] ? e($invoice['client_email']) . '<br>' : '' ?>
      <?= $invoice['client_address'] ? e($invoice['client_address']) : '' ?>
    </p>
  </div>
  <div style="text-align:right;">
    <h4>Dates</h4>
    <p>
      Issued: <strong><?= e(date('M j, Y', strtotime($invoice['issue_date']))) ?></strong><br>
      Due: <strong><?= e(date('M j, Y', strtotime($invoice['due_date']))) ?></strong>
      <?= $invoice['project_name'] ? '<br>Project: <strong>' . e($invoice['project_name']) . '</strong>' : '' ?>
    </p>
  </div>
</div>

<table>
  <thead><tr><th>Description</th><th class="r">Qty</th><th class="r">Unit price</th><th class="r">Amount</th></tr></thead>
  <tbody>
    <?php foreach ($invoice['items'] as $item): ?>
      <tr>
        <td><?= e($item['description']) ?></td>
        <td class="r"><?= rtrim(rtrim(number_format((float) $item['quantity'], 2), '0'), '.') ?></td>
        <td class="r"><?= money($item['unit_price']) ?></td>
        <td class="r"><strong><?= money($item['line_total']) ?></strong></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<div class="totals">
  <div class="row"><span>Subtotal</span><span><?= money($invoice['subtotal']) ?></span></div>
  <?php if ((float) $invoice['discount'] > 0): ?>
    <div class="row"><span>Discount</span><span>−<?= money($invoice['discount']) ?></span></div>
  <?php endif; ?>
  <?php if ((float) $invoice['tax_rate'] > 0): ?>
    <div class="row"><span>Tax (<?= rtrim(rtrim(number_format((float) $invoice['tax_rate'], 2), '0'), '.') ?>%)</span><span><?= money($invoice['tax_amount']) ?></span></div>
  <?php endif; ?>
  <div class="row grand"><span>Total</span><span><?= money($invoice['total']) ?></span></div>
  <?php if ((float) $invoice['amount_paid'] > 0): ?>
    <div class="row"><span>Paid</span><span><?= money($invoice['amount_paid']) ?></span></div>
    <div class="row" style="font-weight:700;"><span>Balance due</span><span><?= money($balance) ?></span></div>
  <?php endif; ?>
</div>

<?php if ($invoice['notes']): ?>
  <div class="notes"><?= e($invoice['notes']) ?></div>
<?php endif; ?>

<div class="foot">Thank you for your business. — <?= e(config('agency')) ?></div>
</body>
</html>
