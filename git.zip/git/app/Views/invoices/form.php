<?php
/**
 * Invoice create/edit form with dynamic line items.
 * @var array|null $invoice        Full invoice (with items) when editing
 * @var array      $clientOptions  id => label
 * @var array      $projectOptions project rows (client_id used for filtering)
 * @var array      $errors
 */
use App\Models\Invoice;

$editing = $invoice !== null;
$action  = $editing ? url('invoices/' . $invoice['id']) : url('invoices');
$items   = $invoice['items'] ?? [];
?>
<form method="post" action="<?= $action ?>" novalidate>
  <?= csrf_field() ?>

  <div class="row g-3">
    <div class="col-12 col-lg-8">
      <div class="card-sams p-4 mb-3">
        <h5 class="mb-4"><i class="bi bi-receipt me-2" style="color:var(--accent)"></i>Invoice details</h5>

        <div class="row g-3">
          <div class="col-md-6">
            <label for="client_id" class="form-label-sams">Client *</label>
            <select id="client_id" name="client_id" class="form-control-sams <?= isset($errors['client_id']) ? 'is-invalid' : '' ?>">
              <option value="">— Choose client —</option>
              <?php $currentClient = (int) old('client_id', (string) ($invoice['client_id'] ?? 0)); ?>
              <?php foreach ($clientOptions as $cid => $label): ?>
                <option value="<?= $cid ?>" <?= $currentClient === $cid ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
            <?php if (isset($errors['client_id'])): ?><div class="invalid-feedback-sams"><?= e($errors['client_id']) ?></div><?php endif; ?>
          </div>
          <div class="col-md-6">
            <label for="project_id" class="form-label-sams">Project (optional)</label>
            <select id="project_id" name="project_id" class="form-control-sams">
              <option value="">— None —</option>
              <?php $currentProject = (int) old('project_id', (string) ($invoice['project_id'] ?? 0)); ?>
              <?php foreach ($projectOptions as $p): ?>
                <option value="<?= (int) $p['id'] ?>" <?= $currentProject === (int) $p['id'] ? 'selected' : '' ?>>
                  <?= e($p['name'] . ' (' . $p['client_name'] . ')') ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-6 col-md-4">
            <label for="issue_date" class="form-label-sams">Issue date *</label>
            <input type="date" id="issue_date" name="issue_date"
                   value="<?= old('issue_date', $invoice['issue_date'] ?? date('Y-m-d')) ?>"
                   class="form-control-sams <?= isset($errors['issue_date']) ? 'is-invalid' : '' ?>">
          </div>
          <div class="col-6 col-md-4">
            <label for="due_date" class="form-label-sams">Due date *</label>
            <input type="date" id="due_date" name="due_date"
                   value="<?= old('due_date', $invoice['due_date'] ?? date('Y-m-d', strtotime('+14 days'))) ?>"
                   class="form-control-sams <?= isset($errors['due_date']) ? 'is-invalid' : '' ?>">
          </div>
          <div class="col-12 col-md-4">
            <label for="status" class="form-label-sams">Status</label>
            <select id="status" name="status" class="form-control-sams">
              <?php $currentStatus = old('status', $invoice['status'] ?? 'pending'); ?>
              <?php foreach (Invoice::STATUSES as $s): ?>
                <option value="<?= $s ?>" <?= $currentStatus === $s ? 'selected' : '' ?>><?= label($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>

      <div class="card-sams p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="m-0"><i class="bi bi-list-ul me-2" style="color:var(--accent)"></i>Line items</h5>
          <button type="button" class="btn-ghost-sams" onclick="addItemRow()"><i class="bi bi-plus-lg me-1"></i> Add item</button>
        </div>
        <?php if (isset($errors['items'])): ?>
          <div class="invalid-feedback-sams mb-2"><?= e($errors['items']) ?></div>
        <?php endif; ?>

        <div id="itemRows"></div>

        <div class="d-flex justify-content-end mt-3">
          <div style="min-width:240px; font-size:14px;">
            <div class="d-flex justify-content-between py-1">
              <span style="color:var(--text-low);">Subtotal</span>
              <span id="calcSubtotal" style="font-family:var(--font-mono);">₦0</span>
            </div>
            <div class="d-flex justify-content-between py-1">
              <span style="color:var(--text-low);">Total (after discount + tax)</span>
              <span id="calcTotal" style="font-family:var(--font-mono); font-weight:700; color:var(--text-hi);">₦0</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-12 col-lg-4">
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-percent me-2" style="color:var(--accent)"></i>Adjustments</h5>

        <label for="discount" class="form-label-sams">Discount (₦ flat)</label>
        <input type="number" step="0.01" min="0" id="discount" name="discount"
               value="<?= old('discount', (string) ($invoice['discount'] ?? '0')) ?>"
               class="form-control-sams mb-3" oninput="recalcTotals()">

        <label for="tax_rate" class="form-label-sams">Tax rate (%)</label>
        <input type="number" step="0.01" min="0" max="100" id="tax_rate" name="tax_rate"
               value="<?= old('tax_rate', (string) ($invoice['tax_rate'] ?? '0')) ?>"
               class="form-control-sams mb-3" oninput="recalcTotals()">

        <label for="notes" class="form-label-sams">Notes (shown on invoice)</label>
        <textarea id="notes" name="notes" rows="3" class="form-control-sams mb-4"
                  placeholder="Bank details, payment terms…"><?= old('notes', (string) ($invoice['notes'] ?? '')) ?></textarea>

        <button type="submit" class="btn-sams w-100 mb-2">
          <i class="bi bi-check-lg me-1"></i> <?= $editing ? 'Save invoice' : 'Create invoice' ?>
        </button>
        <a href="<?= $editing ? url('invoices/' . $invoice['id']) : url('invoices') ?>" class="btn-ghost-sams w-100 d-block text-center">Cancel</a>
      </div>
    </div>
  </div>
</form>

<script>
/* Dynamic line items: server receives item_desc[]/item_qty[]/item_price[]. */
const existingItems = <?= json_encode(array_map(
    static fn($i) => ['d' => $i['description'], 'q' => (float) $i['quantity'], 'p' => (float) $i['unit_price']],
    $items
), JSON_UNESCAPED_UNICODE) ?>;

function addItemRow(item) {
  item = item || { d: '', q: 1, p: 0 };
  const row = document.createElement('div');
  row.className = 'row g-2 mb-2 align-items-center item-row';
  row.innerHTML = `
    <div class="col-12 col-md-6">
      <input type="text" name="item_desc[]" class="form-control-sams" placeholder="Description" value="${item.d.replace(/"/g, '&quot;')}">
    </div>
    <div class="col-3 col-md-2">
      <input type="number" name="item_qty[]" class="form-control-sams" min="0.01" step="0.01" value="${item.q}" oninput="recalcTotals()">
    </div>
    <div class="col-6 col-md-3">
      <input type="number" name="item_price[]" class="form-control-sams" min="0" step="0.01" value="${item.p}" oninput="recalcTotals()">
    </div>
    <div class="col-3 col-md-1 text-end">
      <button type="button" class="icon-btn" onclick="this.closest('.item-row').remove(); recalcTotals();" title="Remove">
        <i class="bi bi-x-lg"></i>
      </button>
    </div>`;
  document.getElementById('itemRows').appendChild(row);
  recalcTotals();
}

function recalcTotals() {
  let subtotal = 0;
  document.querySelectorAll('.item-row').forEach((row) => {
    const q = parseFloat(row.querySelector('[name="item_qty[]"]').value) || 0;
    const p = parseFloat(row.querySelector('[name="item_price[]"]').value) || 0;
    subtotal += q * p;
  });
  const discount = Math.min(parseFloat(document.getElementById('discount').value) || 0, subtotal);
  const taxRate = parseFloat(document.getElementById('tax_rate').value) || 0;
  const total = (subtotal - discount) * (1 + taxRate / 100);
  const fmt = (n) => '₦' + n.toLocaleString(undefined, { maximumFractionDigits: 2 });
  document.getElementById('calcSubtotal').textContent = fmt(subtotal);
  document.getElementById('calcTotal').textContent = fmt(total);
}

(existingItems.length ? existingItems : [null]).forEach((i) => addItemRow(i || undefined));
</script>
