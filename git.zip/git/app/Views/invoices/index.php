<?php
/**
 * Invoices list.
 * @var array $invoices
 * @var float $outstanding
 */
use App\Models\Invoice;
?>
<div class="page-head">
  <div>
    <div class="page-head__sub">
      <?= count($invoices) ?> invoice<?= count($invoices) === 1 ? '' : 's' ?>
      &middot; outstanding: <strong style="color:var(--warning);"><?= money($outstanding) ?></strong>
    </div>
  </div>
  <a href="<?= url('invoices/create') ?>" class="btn-sams"><i class="bi bi-plus-lg me-1"></i> New Invoice</a>
</div>

<div class="card-sams">
  <?php if ($invoices === []): ?>
    <div class="empty-state">
      <i class="bi bi-receipt"></i>
      <p>No invoices yet. Create your first invoice.</p>
      <a href="<?= url('invoices/create') ?>" class="btn-sams mt-2" style="display:inline-block;">Create Invoice</a>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table-sams sams-datatable w-100">
        <thead>
          <tr>
            <th>Invoice</th>
            <th>Client</th>
            <th>Issued</th>
            <th>Due</th>
            <th>Total</th>
            <th>Paid</th>
            <th>Status</th>
            <th data-dt-order="disable"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($invoices as $inv): ?>
            <tr>
              <td>
                <a href="<?= url('invoices/' . $inv['id']) ?>" style="font-family:var(--font-mono);"><?= e($inv['invoice_number']) ?></a>
                <div style="font-size:12px; color:var(--text-low);"><?= e($inv['project_name'] ?? '') ?></div>
              </td>
              <td><?= e($inv['client_name']) ?></td>
              <td data-order="<?= e($inv['issue_date']) ?>"><?= e(date('M j, Y', strtotime($inv['issue_date']))) ?></td>
              <td data-order="<?= e($inv['due_date']) ?>"><?= e(date('M j, Y', strtotime($inv['due_date']))) ?></td>
              <td data-order="<?= (float) $inv['total'] ?>"><strong style="color:var(--text-hi);"><?= money($inv['total']) ?></strong></td>
              <td data-order="<?= (float) $inv['amount_paid'] ?>"><?= money($inv['amount_paid']) ?></td>
              <td><span class="badge-soft badge-soft--<?= Invoice::STATUS_COLORS[$inv['status']] ?? 'muted' ?>"><?= e($inv['status']) ?></span></td>
              <td class="text-end" style="white-space:nowrap;">
                <a href="<?= url('invoices/' . $inv['id'] . '/print') ?>" target="_blank" class="icon-btn" title="Print / PDF"><i class="bi bi-printer"></i></a>
                <a href="<?= url('invoices/' . $inv['id'] . '/edit') ?>" class="icon-btn" title="Edit"><i class="bi bi-pencil"></i></a>
                <form method="post" action="<?= url('invoices/' . $inv['id'] . '/delete') ?>" class="d-inline" data-confirm="Delete invoice <?= e($inv['invoice_number']) ?>?">
                  <?= csrf_field() ?>
                  <button type="submit" class="icon-btn" title="Delete"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
