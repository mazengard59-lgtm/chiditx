<?php
/**
 * Invoice detail with payment recording.
 * @var array $invoice Full invoice from Invoice::findFull()
 */
use App\Models\Invoice;
use App\Models\Payment;

$balance = (float) $invoice['total'] - (float) $invoice['amount_paid'];
?>
<div class="page-head">
  <a href="<?= url('invoices') ?>" class="btn-ghost-sams"><i class="bi bi-arrow-left me-1"></i> All invoices</a>
  <div class="d-flex gap-2 flex-wrap">
    <?php if (!empty($invoice['client_whatsapp'])): ?>
      <a class="btn-ghost-sams" target="_blank" rel="noopener"
         href="https://wa.me/<?= e(preg_replace('/\D/', '', $invoice['client_whatsapp'])) ?>?text=<?= rawurlencode("Hello {$invoice['client_name']}, invoice {$invoice['invoice_number']} for " . money($invoice['total']) . " is due on " . date('M j, Y', strtotime($invoice['due_date'])) . ". Thank you!") ?>">
        <i class="bi bi-whatsapp me-1"></i> Send reminder
      </a>
    <?php endif; ?>
    <a href="<?= url('invoices/' . $invoice['id'] . '/print') ?>" target="_blank" class="btn-ghost-sams"><i class="bi bi-printer me-1"></i> Print / PDF</a>
    <a href="<?= url('invoices/' . $invoice['id'] . '/edit') ?>" class="btn-sams"><i class="bi bi-pencil me-1"></i> Edit</a>
  </div>
</div>

<div class="row g-3">
  <div class="col-12 col-lg-8">
    <div class="card-sams p-4 mb-3">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-4">
        <div>
          <h3 class="mb-1" style="font-family:var(--font-mono);"><?= e($invoice['invoice_number']) ?></h3>
          <div style="color:var(--text-mid);">
            <?= e($invoice['client_name']) ?><?= $invoice['client_company'] ? ' — ' . e($invoice['client_company']) : '' ?>
            <?= $invoice['project_name'] ? '&middot; ' . e($invoice['project_name']) : '' ?>
          </div>
        </div>
        <span class="badge-soft badge-soft--<?= Invoice::STATUS_COLORS[$invoice['status']] ?? 'muted' ?>" style="font-size:13px;"><?= e($invoice['status']) ?></span>
      </div>

      <div class="table-wrap">
        <table class="table-sams w-100">
          <thead><tr><th>Description</th><th class="text-end">Qty</th><th class="text-end">Unit price</th><th class="text-end">Total</th></tr></thead>
          <tbody>
            <?php foreach ($invoice['items'] as $item): ?>
              <tr>
                <td style="color:var(--text-hi);"><?= e($item['description']) ?></td>
                <td class="text-end"><?= rtrim(rtrim(number_format((float) $item['quantity'], 2), '0'), '.') ?></td>
                <td class="text-end"><?= money($item['unit_price']) ?></td>
                <td class="text-end" style="color:var(--text-hi); font-weight:600;"><?= money($item['line_total']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="d-flex justify-content-end mt-3">
        <div style="min-width:260px; font-size:14px;">
          <div class="d-flex justify-content-between py-1"><span style="color:var(--text-low);">Subtotal</span><span><?= money($invoice['subtotal']) ?></span></div>
          <?php if ((float) $invoice['discount'] > 0): ?>
            <div class="d-flex justify-content-between py-1"><span style="color:var(--text-low);">Discount</span><span style="color:var(--success);">−<?= money($invoice['discount']) ?></span></div>
          <?php endif; ?>
          <?php if ((float) $invoice['tax_rate'] > 0): ?>
            <div class="d-flex justify-content-between py-1"><span style="color:var(--text-low);">Tax (<?= rtrim(rtrim(number_format((float) $invoice['tax_rate'], 2), '0'), '.') ?>%)</span><span><?= money($invoice['tax_amount']) ?></span></div>
          <?php endif; ?>
          <div class="d-flex justify-content-between py-2 mt-1" style="border-top:1px solid var(--border); font-weight:700; color:var(--text-hi);">
            <span>Total</span><span><?= money($invoice['total']) ?></span>
          </div>
          <div class="d-flex justify-content-between py-1"><span style="color:var(--text-low);">Paid</span><span style="color:var(--success);"><?= money($invoice['amount_paid']) ?></span></div>
          <div class="d-flex justify-content-between py-1" style="font-weight:700;">
            <span style="color:var(--text-low);">Balance</span>
            <span style="color:<?= $balance > 0 ? 'var(--warning)' : 'var(--success)' ?>;"><?= money($balance) ?></span>
          </div>
        </div>
      </div>

      <?php if ($invoice['notes']): ?>
        <hr style="border-color:var(--border);">
        <p style="font-size:13px; color:var(--text-mid); margin:0; white-space:pre-line;"><?= e($invoice['notes']) ?></p>
      <?php endif; ?>
    </div>

    <div class="card-sams">
      <div class="panel-header"><h5><i class="bi bi-credit-card me-2" style="color:var(--accent)"></i>Payment history</h5></div>
      <?php if ($invoice['payments'] === []): ?>
        <div class="empty-state"><i class="bi bi-credit-card"></i><p>No payments recorded yet.</p></div>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table-sams w-100">
            <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Reference</th></tr></thead>
            <tbody>
              <?php foreach ($invoice['payments'] as $pay): ?>
                <tr>
                  <td><?= e(date('M j, Y', strtotime($pay['paid_at']))) ?></td>
                  <td style="color:var(--success); font-weight:600;"><?= money($pay['amount']) ?></td>
                  <td><?= label($pay['method']) ?></td>
                  <td style="font-family:var(--font-mono); font-size:12px;"><?= e($pay['reference'] ?: '—') ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <?php if ($balance > 0 && !in_array($invoice['status'], ['draft', 'cancelled'], true)): ?>
      <div class="card-sams p-4">
        <h5 class="mb-4"><i class="bi bi-cash me-2" style="color:var(--accent)"></i>Record payment</h5>
        <form method="post" action="<?= url('invoices/' . $invoice['id'] . '/payment') ?>">
          <?= csrf_field() ?>

          <label for="amount" class="form-label-sams">Amount (₦) *</label>
          <input type="number" step="0.01" min="0.01" max="<?= $balance ?>" id="amount" name="amount"
                 value="<?= $balance ?>" class="form-control-sams mb-3" required>

          <label for="method" class="form-label-sams">Method</label>
          <select id="method" name="method" class="form-control-sams mb-3">
            <?php foreach (Payment::METHODS as $m): ?>
              <option value="<?= $m ?>"><?= label($m) ?></option>
            <?php endforeach; ?>
          </select>

          <label for="paid_at" class="form-label-sams">Payment date</label>
          <input type="date" id="paid_at" name="paid_at" value="<?= date('Y-m-d') ?>" class="form-control-sams mb-3">

          <label for="reference" class="form-label-sams">Reference (optional)</label>
          <input type="text" id="reference" name="reference" class="form-control-sams mb-4" placeholder="Transfer ref, Paystack ID…">

          <button type="submit" class="btn-sams w-100"><i class="bi bi-check-lg me-1"></i> Record payment</button>
        </form>
      </div>
    <?php else: ?>
      <div class="card-sams p-4 text-center">
        <i class="bi bi-check2-circle" style="font-size:38px; color:var(--success);"></i>
        <p style="color:var(--text-mid); margin:10px 0 0;">
          <?= $invoice['status'] === 'paid' ? 'Fully paid — nothing outstanding.' : 'No payment expected in this status.' ?>
        </p>
      </div>
    <?php endif; ?>
  </div>
</div>
