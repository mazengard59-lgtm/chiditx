<?php

declare(strict_types=1);

namespace App\Core;

use Throwable;

/**
 * Application kernel: boots the environment, dispatches the router,
 * runs the middleware pipeline, and handles errors centrally.
 */
final class App
{
    public readonly Router $router;
    private Request $request;

    /** Middleware aliases usable in route definitions. */
    private const MIDDLEWARE = [
        'auth'  => \App\Middleware\AuthMiddleware::class,
        'guest' => \App\Middleware\GuestMiddleware::class,
        'admin'  => \App\Middleware\AdminMiddleware::class,
        'client' => \App\Middleware\ClientMiddleware::class,
        'csrf'   => \App\Middleware\CsrfMiddleware::class,
    ];

    public function __construct()
    {
        date_default_timezone_set((string) config('timezone', 'UTC'));

        if (config('debug')) {
            error_reporting(E_ALL);
            ini_set('display_errors', '1');
        } else {
            error_reporting(E_ALL);
            ini_set('display_errors', '0');
            ini_set('log_errors', '1');
            ini_set('error_log', BASE_PATH . '/storage/logs/php-error.log');
        }

        Session::start();
        $this->router  = new Router();
        $this->request = new Request();
    }

    public function run(): void
    {
        try {
            echo $this->dispatch();
        } catch (Throwable $e) {
            $this->handleError($e);
        }
    }

    private function dispatch(): string
    {
        $match = $this->router->match($this->request);

        if ($match === null) {
            http_response_code(404);
            return View::render('errors.404', [], null);
        }

        // CSRF is enforced globally on all state-changing requests.
        $middleware = $match['middleware'];
        if (!in_array($this->request->method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            array_unshift($middleware, 'csrf');
        }

        foreach ($middleware as $alias) {
            $class = self::MIDDLEWARE[$alias]
                ?? throw new \RuntimeException("Unknown middleware: {$alias}");
            (new $class())->handle($this->request);
        }

        [$controllerClass, $method] = $match['handler'];
        $controller = new $controllerClass($this->request);

        return (string) $controller->{$method}(...array_values($match['args']));
    }

    private function handleError(Throwable $e): void
    {
        error_log(sprintf(
            '[SAMS] %s in %s:%d — %s',
            $e::class,
            $e->getFile(),
            $e->getLine(),
            $e->getMessage()
        ));

        http_response_code(500);

        if (config('debug')) {
            echo '<h1 style="font-family:monospace">Error: ' . e($e->getMessage()) . '</h1>';
            echo '<pre style="font-family:monospace">' . e($e->getFile() . ':' . $e->getLine()) . "\n\n" . e($e->getTraceAsString()) . '</pre>';
            return;
        }
        echo View::render('errors.500', [], null);
    }
}
