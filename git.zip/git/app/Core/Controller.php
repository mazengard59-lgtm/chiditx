<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Base controller: view rendering, redirects, JSON responses,
 * and lightweight input validation shared by all controllers.
 */
abstract class Controller
{
    protected Request $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    protected function view(string $view, array $data = [], ?string $layout = 'admin'): string
    {
        return View::render($view, $data, $layout);
    }

    protected function json(array $payload, int $status = 200): string
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        return json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /** Redirect back to a form with errors + old input preserved in session. */
    protected function backWithErrors(string $path, array $errors): never
    {
        Session::set('_errors', $errors);
        Session::set('_old', $this->request->all());
        redirect($path);
    }

    /**
     * Validate input against rules: 'required', 'email', 'min:N', 'max:N'.
     * Returns [values, errors].
     */
    protected function validate(array $rules): array
    {
        $values = [];
        $errors = [];

        foreach ($rules as $field => $ruleString) {
            $value = $this->request->input($field, '') ?? '';
            $values[$field] = $value;
            $label = ucfirst(str_replace('_', ' ', $field));

            foreach (explode('|', $ruleString) as $rule) {
                [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);

                $failed = match ($name) {
                    'required' => $value === '',
                    'email'    => $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL),
                    'min'      => $value !== '' && mb_strlen($value) < (int) $arg,
                    'max'      => mb_strlen($value) > (int) $arg,
                    default    => false,
                };

                if ($failed) {
                    $errors[$field] = match ($name) {
                        'required' => "{$label} is required.",
                        'email'    => "{$label} must be a valid email address.",
                        'min'      => "{$label} must be at least {$arg} characters.",
                        'max'      => "{$label} may not exceed {$arg} characters.",
                        default    => "{$label} is invalid.",
                    };
                    break; // first error per field is enough
                }
            }
        }
        return [$values, $errors];
    }
}
