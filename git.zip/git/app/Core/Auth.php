<?php

declare(strict_types=1);

namespace App\Core;

use App\Models\ActivityLog;
use App\Models\User;

/**
 * Authentication service.
 * Sessions carry only the user ID; the user row is re-fetched per request
 * so role/status changes take effect immediately.
 */
final class Auth
{
    private const SESSION_KEY = '_auth_user_id';
    private static ?array $cachedUser = null;

    /** Attempt login. Returns the user row on success, null on failure. */
    public static function attempt(string $email, string $password, Request $request): ?array
    {
        $user = (new User())->findByEmail($email);

        // Always run password_verify to keep timing constant for unknown emails.
        $hash = $user['password_hash'] ?? '$2y$10$invalidinvalidinvalidinvalidinvalidinval';
        if (!password_verify($password, $hash) || $user === null) {
            return null;
        }

        if ($user['status'] !== 'active') {
            return null;
        }

        Session::regenerate(); // prevent session fixation
        Session::set(self::SESSION_KEY, (int) $user['id']);
        self::$cachedUser = $user;

        (new User())->touchLastLogin((int) $user['id']);
        ActivityLog::record((int) $user['id'], 'auth.login', 'Signed in', $request);

        return $user;
    }

    public static function user(): ?array
    {
        if (self::$cachedUser !== null) {
            return self::$cachedUser;
        }

        $id = Session::get(self::SESSION_KEY);
        if ($id === null) {
            return null;
        }

        $user = (new User())->find((int) $id);
        if ($user === null || $user['status'] !== 'active') {
            self::logout();
            return null;
        }

        return self::$cachedUser = $user;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function isAdmin(): bool
    {
        return (self::user()['role'] ?? null) === 'admin';
    }

    public static function logout(): void
    {
        self::$cachedUser = null;
        Session::destroy();
        Session::start();
        Session::regenerate();
    }
}
