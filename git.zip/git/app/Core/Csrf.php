<?php

declare(strict_types=1);

namespace App\Core;

/**
 * CSRF protection: per-session token, verified on every state-changing
 * request (POST/PUT/PATCH/DELETE) by CsrfMiddleware.
 */
final class Csrf
{
    private const KEY = '_csrf_token';

    public static function token(): string
    {
        if (!Session::has(self::KEY)) {
            Session::set(self::KEY, bin2hex(random_bytes(32)));
        }
        return (string) Session::get(self::KEY);
    }

    public static function verify(?string $token): bool
    {
        return is_string($token)
            && $token !== ''
            && hash_equals(self::token(), $token);
    }
}
