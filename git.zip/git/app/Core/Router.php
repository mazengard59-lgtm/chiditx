<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Minimal REST-style router with route parameters and per-route middleware.
 *
 *   $router->get('/clients/{id}', [ClientController::class, 'show'], ['auth']);
 */
final class Router
{
    /** @var array<string, array<int, array{pattern:string, params:string[], handler:array, middleware:string[]}>> */
    private array $routes = [];

    public function get(string $path, array $handler, array $middleware = []): void
    {
        $this->add('GET', $path, $handler, $middleware);
    }

    public function post(string $path, array $handler, array $middleware = []): void
    {
        $this->add('POST', $path, $handler, $middleware);
    }

    private function add(string $method, string $path, array $handler, array $middleware): void
    {
        $params = [];
        $pattern = preg_replace_callback(
            '/\{(\w+)\}/',
            static function (array $m) use (&$params): string {
                $params[] = $m[1];
                return '([^/]+)';
            },
            '/' . trim($path, '/')
        );

        $this->routes[$method][] = [
            'pattern'    => '#^' . ($pattern === '/' ? '/?' : $pattern) . '$#',
            'params'     => $params,
            'handler'    => $handler,
            'middleware' => $middleware,
        ];
    }

    /**
     * Match the request and return [handler, args, middleware], or null (404).
     * @return array{handler:array, args:array<string,string>, middleware:string[]}|null
     */
    public function match(Request $request): ?array
    {
        foreach ($this->routes[$request->method] ?? [] as $route) {
            if (preg_match($route['pattern'], $request->path, $matches)) {
                array_shift($matches);
                return [
                    'handler'    => $route['handler'],
                    'args'       => array_combine($route['params'], $matches) ?: [],
                    'middleware' => $route['middleware'],
                ];
            }
        }
        return null;
    }
}
