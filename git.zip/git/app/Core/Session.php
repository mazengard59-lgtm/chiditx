<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Secure session wrapper.
 * Hardened against session hijacking: httponly + samesite cookies,
 * ID regeneration on privilege change, and inactivity timeout.
 */
final class Session
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        session_name((string) config('session.name', 'sams_session'));
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();

        self::enforceTimeout();
    }

    private static function enforceTimeout(): void
    {
        $lifetime = (int) config('session.lifetime', 7200);
        $last = $_SESSION['_last_activity'] ?? null;

        if ($last !== null && (time() - $last) > $lifetime) {
            self::destroy();
            self::start();
        }
        $_SESSION['_last_activity'] = time();
    }

    /** Rotate the session ID — call on login/logout to prevent fixation. */
    public static function regenerate(): void
    {
        session_regenerate_id(true);
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function remove(string $key): void
    {
        unset($_SESSION[$key]);
    }

    /** Get a value and remove it in one step. */
    public static function pull(string $key, mixed $default = null): mixed
    {
        $value = $_SESSION[$key] ?? $default;
        unset($_SESSION[$key]);
        return $value;
    }

    public static function flash(string $key, string $message): void
    {
        $_SESSION['_flash_' . $key] = $message;
    }

    public static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }
}
