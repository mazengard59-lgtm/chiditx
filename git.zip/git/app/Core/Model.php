<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * Base model: thin, safe CRUD layer over PDO prepared statements.
 * Subclasses declare $table and $fillable; anything not in $fillable
 * is silently dropped (mass-assignment protection).
 */
abstract class Model
{
    protected string $table;

    /** @var string[] Columns allowed in create()/update(). */
    protected array $fillable = [];

    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM `{$this->table}` WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    /** All rows, newest first. */
    public function all(string $orderBy = 'id DESC', int $limit = 500): array
    {
        $orderBy = preg_replace('/[^a-zA-Z0-9_,. ]/', '', $orderBy);
        $stmt = $this->db->prepare("SELECT * FROM `{$this->table}` ORDER BY {$orderBy} LIMIT " . max(1, $limit));
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** First row matching column = value. */
    public function findBy(string $column, mixed $value): ?array
    {
        $this->assertColumn($column);
        $stmt = $this->db->prepare("SELECT * FROM `{$this->table}` WHERE `{$column}` = ? LIMIT 1");
        $stmt->execute([$value]);
        return $stmt->fetch() ?: null;
    }

    /** Insert a row from fillable data; returns the new ID. */
    public function create(array $data): int
    {
        $data = $this->onlyFillable($data);
        $columns = array_keys($data);
        $placeholders = implode(', ', array_fill(0, count($columns), '?'));
        $columnSql = '`' . implode('`, `', $columns) . '`';

        $stmt = $this->db->prepare("INSERT INTO `{$this->table}` ({$columnSql}) VALUES ({$placeholders})");
        $stmt->execute(array_values($data));
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $data = $this->onlyFillable($data);
        if ($data === []) {
            return false;
        }
        $set = implode(', ', array_map(static fn($c) => "`{$c}` = ?", array_keys($data)));
        $stmt = $this->db->prepare("UPDATE `{$this->table}` SET {$set} WHERE id = ?");
        return $stmt->execute([...array_values($data), $id]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM `{$this->table}` WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function count(): int
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM `{$this->table}`")->fetchColumn();
    }

    private function onlyFillable(array $data): array
    {
        return array_intersect_key($data, array_flip($this->fillable));
    }

    private function assertColumn(string $column): void
    {
        if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $column)) {
            throw new \InvalidArgumentException("Invalid column name: {$column}");
        }
    }
}
