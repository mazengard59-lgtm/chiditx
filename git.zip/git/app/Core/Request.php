<?php

declare(strict_types=1);

namespace App\Core;

/**
 * HTTP request abstraction. Centralizes input access so validation
 * and sanitization happen in one place, not scattered across views.
 */
final class Request
{
    public readonly string $method;
    public readonly string $path;

    public function __construct()
    {
        $this->method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $this->path   = $this->resolvePath();
    }

    /** URI path relative to the app root (subfolder-safe). */
    private function resolvePath(): string
    {
        $uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

        if ($base !== '' && str_starts_with($uri, $base)) {
            $uri = substr($uri, strlen($base));
        }
        return '/' . trim(rawurldecode($uri), '/');
    }

    /** POST/GET input, trimmed. Returns $default when absent. */
    public function input(string $key, ?string $default = null): ?string
    {
        $value = $_POST[$key] ?? $_GET[$key] ?? $default;
        return is_string($value) ? trim($value) : $default;
    }

    /** All request input (POST wins over GET), trimmed strings only. */
    public function all(): array
    {
        $merged = array_merge($_GET, $_POST);
        return array_map(
            static fn($v) => is_string($v) ? trim($v) : $v,
            $merged
        );
    }

    public function isPost(): bool
    {
        return $this->method === 'POST';
    }

    public function isAjax(): bool
    {
        return strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
            || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
    }

    public function ip(): string
    {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public function userAgent(): string
    {
        return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
    }
}
