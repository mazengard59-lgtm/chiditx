<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * View renderer. Views are plain PHP templates under app/Views;
 * an optional layout wraps the view via the $content variable.
 */
final class View
{
    /**
     * @param string      $view   Dot notation, e.g. 'dashboard.index'
     * @param array       $data   Variables extracted into the template
     * @param string|null $layout Layout name under Views/layouts (no extension)
     */
    public static function render(string $view, array $data = [], ?string $layout = null): string
    {
        $content = self::renderFile(self::path($view), $data);

        if ($layout !== null) {
            $data['content'] = $content;
            $content = self::renderFile(self::path('layouts.' . $layout), $data);
        }
        return $content;
    }

    private static function path(string $view): string
    {
        $file = BASE_PATH . '/app/Views/' . str_replace('.', '/', $view) . '.php';
        if (!is_file($file)) {
            throw new RuntimeException("View not found: {$view}");
        }
        return $file;
    }

    private static function renderFile(string $__file, array $__data): string
    {
        extract($__data, EXTR_SKIP);
        ob_start();
        require $__file;
        return (string) ob_get_clean();
    }
}
