<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class TicketReply extends Model
{
    protected string $table = 'ticket_replies';

    protected array $fillable = ['ticket_id', 'user_id', 'message', 'is_internal'];

    public function forTicket(int $ticketId): array
    {
        $stmt = $this->db->prepare(
            'SELECT r.*, u.name AS user_name
             FROM ticket_replies r
             LEFT JOIN users u ON u.id = r.user_id
             WHERE r.ticket_id = ?
             ORDER BY r.created_at ASC'
        );
        $stmt->execute([$ticketId]);
        return $stmt->fetchAll();
    }
}
