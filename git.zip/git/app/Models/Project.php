<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Project extends Model
{
    protected string $table = 'projects';

    protected array $fillable = [
        'client_id', 'name', 'description', 'category', 'price', 'deposit',
        'status', 'priority', 'progress', 'is_featured', 'developer',
        'start_date', 'deadline', 'launch_date', 'maintenance_until', 'warranty_until',
        'github_url', 'live_url', 'staging_url', 'technologies', 'screenshot_url', 'notes',
    ];

    public const STATUSES   = ['planning', 'in_progress', 'on_hold', 'review', 'completed', 'maintenance', 'cancelled'];
    public const PRIORITIES = ['low', 'medium', 'high', 'urgent'];
    public const ACTIVE_STATUSES = ['planning', 'in_progress', 'review'];

    /** Badge color per status, used by list + detail views. */
    public const STATUS_COLORS = [
        'planning'    => 'info',
        'in_progress' => 'accent',
        'on_hold'     => 'warning',
        'review'      => 'info',
        'completed'   => 'success',
        'maintenance' => 'success',
        'cancelled'   => 'danger',
    ];

    /** All projects joined with client names, for the list view. */
    public function allWithClients(): array
    {
        return $this->db->query(
            'SELECT p.*, c.name AS client_name, c.company AS client_company
             FROM projects p
             JOIN clients c ON c.id = p.client_id
             ORDER BY p.created_at DESC'
        )->fetchAll();
    }

    public function findWithClient(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT p.*, c.name AS client_name, c.company AS client_company
             FROM projects p JOIN clients c ON c.id = p.client_id
             WHERE p.id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function forClient(int $clientId): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM projects WHERE client_id = ? ORDER BY created_at DESC'
        );
        $stmt->execute([$clientId]);
        return $stmt->fetchAll();
    }

    public function countActive(): int
    {
        $placeholders = implode(',', array_fill(0, count(self::ACTIVE_STATUSES), '?'));
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM projects WHERE status IN ({$placeholders})");
        $stmt->execute(self::ACTIVE_STATUSES);
        return (int) $stmt->fetchColumn();
    }

    /** Collected revenue = deposits + full price of completed work. */
    public function collectedRevenue(): float
    {
        return (float) $this->db->query(
            "SELECT COALESCE(SUM(CASE
                WHEN status IN ('completed', 'maintenance') THEN price
                ELSE deposit END), 0)
             FROM projects WHERE status <> 'cancelled'"
        )->fetchColumn();
    }

    /** Projects featured on the public portfolio Work section, with their images. */
    public function featured(): array
    {
        $projects = $this->db->query(
            'SELECT id, name, description, category, technologies, live_url
             FROM projects
             WHERE is_featured = 1
             ORDER BY updated_at DESC
             LIMIT 8'
        )->fetchAll();

        $images = (new ProjectImage())->forProjects(array_map(static fn($p) => (int) $p['id'], $projects));
        foreach ($projects as &$project) {
            $project['images'] = $images[(int) $project['id']] ?? [];
        }
        return $projects;
    }

    /** Nearest upcoming deadlines for the dashboard. */
    public function upcomingDeadlines(int $limit = 5): array
    {
        $stmt = $this->db->prepare(
            "SELECT p.id, p.name, p.deadline, p.progress, p.status, c.name AS client_name
             FROM projects p JOIN clients c ON c.id = p.client_id
             WHERE p.deadline IS NOT NULL
               AND p.status IN ('planning', 'in_progress', 'review')
             ORDER BY p.deadline ASC
             LIMIT " . max(1, $limit)
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
