<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class BlogComment extends Model
{
    protected string $table = 'blog_comments';

    protected array $fillable = ['post_id', 'name', 'email', 'body', 'is_approved'];

    public function approvedFor(int $postId): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM blog_comments WHERE post_id = ? AND is_approved = 1 ORDER BY created_at ASC'
        );
        $stmt->execute([$postId]);
        return $stmt->fetchAll();
    }

    public function allWithPosts(): array
    {
        return $this->db->query(
            'SELECT bc.*, p.title AS post_title, p.slug AS post_slug
             FROM blog_comments bc
             JOIN posts p ON p.id = bc.post_id
             ORDER BY bc.is_approved ASC, bc.created_at DESC'
        )->fetchAll();
    }
}
