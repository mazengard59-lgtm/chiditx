<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Ticket extends Model
{
    protected string $table = 'tickets';

    protected array $fillable = ['client_id', 'subject', 'category', 'priority', 'status'];

    public const PRIORITIES = ['low', 'medium', 'high', 'urgent'];
    public const STATUSES   = ['open', 'pending', 'resolved', 'closed'];
    public const CATEGORIES = ['general', 'bug', 'billing', 'feature-request', 'hosting', 'domain'];

    public const STATUS_COLORS = [
        'open' => 'accent', 'pending' => 'warning', 'resolved' => 'success', 'closed' => 'muted',
    ];

    public function allWithClients(): array
    {
        return $this->db->query(
            "SELECT t.*, c.name AS client_name,
                    (SELECT COUNT(*) FROM ticket_replies r WHERE r.ticket_id = t.id) AS reply_count
             FROM tickets t
             JOIN clients c ON c.id = t.client_id
             ORDER BY FIELD(t.status, 'open','pending','resolved','closed'),
                      FIELD(t.priority, 'urgent','high','medium','low'),
                      t.updated_at DESC"
        )->fetchAll();
    }

    public function findWithClient(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT t.*, c.name AS client_name, c.email AS client_email, c.whatsapp AS client_whatsapp
             FROM tickets t JOIN clients c ON c.id = t.client_id
             WHERE t.id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function openCount(): int
    {
        return (int) $this->db
            ->query("SELECT COUNT(*) FROM tickets WHERE status IN ('open','pending')")
            ->fetchColumn();
    }
}
