<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

/** Renewal history — an immutable audit row for every renewal action. */
final class Renewal extends Model
{
    protected string $table = 'renewals';

    protected array $fillable = [
        'user_id', 'item_type', 'item_id', 'item_label',
        'old_expiry', 'new_expiry', 'amount', 'notes',
    ];

    public function recent(int $limit = 15): array
    {
        $stmt = $this->db->prepare(
            'SELECT r.*, u.name AS user_name
             FROM renewals r
             LEFT JOIN users u ON u.id = r.user_id
             ORDER BY r.created_at DESC
             LIMIT ' . max(1, $limit)
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
