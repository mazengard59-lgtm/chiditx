<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class AutomationLog extends Model
{
    protected string $table = 'automation_logs';

    protected array $fillable = ['automation_id', 'level', 'message'];

    public const LEVELS = ['info', 'success', 'error'];

    public function forAutomation(int $automationId, int $limit = 50): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM automation_logs WHERE automation_id = ?
             ORDER BY created_at DESC, id DESC LIMIT ' . max(1, $limit)
        );
        $stmt->execute([$automationId]);
        return $stmt->fetchAll();
    }
}
