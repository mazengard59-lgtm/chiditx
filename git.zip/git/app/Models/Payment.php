<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Payment extends Model
{
    protected string $table = 'payments';

    protected array $fillable = [
        'invoice_id', 'amount', 'method', 'reference', 'paid_at', 'notes',
    ];

    public const METHODS = ['bank_transfer', 'cash', 'paystack', 'flutterwave', 'other'];

    /** [month => total] for the last N months (for analytics charts). */
    public function monthlyTotals(int $months = 12): array
    {
        $stmt = $this->db->prepare(
            "SELECT DATE_FORMAT(paid_at, '%Y-%m') AS ym, SUM(amount) AS total
             FROM payments
             WHERE paid_at >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
             GROUP BY ym ORDER BY ym"
        );
        $stmt->execute([$months]);

        $map = [];
        foreach ($stmt->fetchAll() as $row) {
            $map[$row['ym']] = (float) $row['total'];
        }
        return $map;
    }
}
