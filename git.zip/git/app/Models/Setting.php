<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

/**
 * Key/value application settings (branding, API keys, theme defaults).
 * Values are stored as strings; JSON-encode structures before saving.
 */
final class Setting extends Model
{
    protected string $table = 'settings';

    protected array $fillable = ['setting_key', 'setting_value'];

    public function getValue(string $key, ?string $default = null): ?string
    {
        $row = $this->findBy('setting_key', $key);
        return $row['setting_value'] ?? $default;
    }

    public function setValue(string $key, string $value): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
        );
        $stmt->execute([$key, $value]);
    }
}
