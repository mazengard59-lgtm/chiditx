<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Invoice extends Model
{
    protected string $table = 'invoices';

    protected array $fillable = [
        'invoice_number', 'client_id', 'project_id', 'issue_date', 'due_date',
        'subtotal', 'discount', 'tax_rate', 'tax_amount', 'total',
        'amount_paid', 'status', 'notes',
    ];

    public const STATUSES = ['draft', 'pending', 'partial', 'paid', 'overdue', 'cancelled'];

    public const STATUS_COLORS = [
        'draft'     => 'muted',
        'pending'   => 'info',
        'partial'   => 'warning',
        'paid'      => 'success',
        'overdue'   => 'danger',
        'cancelled' => 'muted',
    ];

    /** Next sequential number, e.g. INV-2026-0007. */
    public function nextNumber(): string
    {
        $year = date('Y');
        $count = (int) $this->db
            ->query("SELECT COUNT(*) FROM invoices WHERE invoice_number LIKE 'INV-{$year}-%'")
            ->fetchColumn();
        return sprintf('INV-%s-%04d', $year, $count + 1);
    }

    /**
     * Lazy overdue check (no cron on shared hosting): flip pending/partial
     * invoices past their due date to overdue. Cheap indexed UPDATE,
     * called when invoice pages load.
     */
    public function refreshOverdue(): void
    {
        $this->db->exec(
            "UPDATE invoices SET status = 'overdue'
             WHERE status IN ('pending','partial') AND due_date < CURDATE()"
        );
    }

    public function allWithClients(): array
    {
        return $this->db->query(
            'SELECT i.*, c.name AS client_name, p.name AS project_name
             FROM invoices i
             JOIN clients c ON c.id = i.client_id
             LEFT JOIN projects p ON p.id = i.project_id
             ORDER BY i.created_at DESC'
        )->fetchAll();
    }

    public function findFull(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT i.*, c.name AS client_name, c.company AS client_company,
                    c.email AS client_email, c.phone AS client_phone,
                    c.address AS client_address, c.whatsapp AS client_whatsapp,
                    p.name AS project_name
             FROM invoices i
             JOIN clients c ON c.id = i.client_id
             LEFT JOIN projects p ON p.id = i.project_id
             WHERE i.id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        $invoice = $stmt->fetch();
        if (!$invoice) {
            return null;
        }

        $items = $this->db->prepare(
            'SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sort_order, id'
        );
        $items->execute([$id]);
        $invoice['items'] = $items->fetchAll();

        $payments = $this->db->prepare(
            'SELECT * FROM payments WHERE invoice_id = ? ORDER BY paid_at DESC, id DESC'
        );
        $payments->execute([$id]);
        $invoice['payments'] = $payments->fetchAll();

        return $invoice;
    }

    /** Replace all line items and recompute totals + status. */
    public function syncItems(int $invoiceId, array $items): void
    {
        $this->db->prepare('DELETE FROM invoice_items WHERE invoice_id = ?')->execute([$invoiceId]);

        $insert = $this->db->prepare(
            'INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, line_total, sort_order)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        foreach (array_values($items) as $i => $item) {
            $insert->execute([
                $invoiceId, $item['description'], $item['quantity'],
                $item['unit_price'], $item['quantity'] * $item['unit_price'], $i,
            ]);
        }
        $this->recalculate($invoiceId);
    }

    /** Recompute subtotal/tax/total/amount_paid and derive status. */
    public function recalculate(int $invoiceId): void
    {
        $invoice = $this->find($invoiceId);
        if (!$invoice) {
            return;
        }

        $stmt = $this->db->prepare('SELECT COALESCE(SUM(line_total), 0) FROM invoice_items WHERE invoice_id = ?');
        $stmt->execute([$invoiceId]);
        $subtotal = (float) $stmt->fetchColumn();

        $paidStmt = $this->db->prepare('SELECT COALESCE(SUM(amount), 0) FROM payments WHERE invoice_id = ?');
        $paidStmt->execute([$invoiceId]);
        $paid = (float) $paidStmt->fetchColumn();

        $discount  = min((float) $invoice['discount'], $subtotal);
        $taxable   = $subtotal - $discount;
        $taxAmount = round($taxable * (float) $invoice['tax_rate'] / 100, 2);
        $total     = round($taxable + $taxAmount, 2);

        $status = $invoice['status'];
        if (!in_array($status, ['draft', 'cancelled'], true)) {
            $status = match (true) {
                $total > 0 && $paid >= $total          => 'paid',
                $paid > 0 && $paid < $total            => 'partial',
                $invoice['due_date'] < date('Y-m-d')   => 'overdue',
                default                                => 'pending',
            };
        }

        $this->db->prepare(
            'UPDATE invoices SET subtotal = ?, tax_amount = ?, total = ?, amount_paid = ?, status = ? WHERE id = ?'
        )->execute([$subtotal, $taxAmount, $total, $paid, $status, $invoiceId]);
    }

    /** Outstanding receivables (pending + partial + overdue). */
    public function outstandingTotal(): float
    {
        return (float) $this->db->query(
            "SELECT COALESCE(SUM(total - amount_paid), 0) FROM invoices
             WHERE status IN ('pending','partial','overdue')"
        )->fetchColumn();
    }
}
