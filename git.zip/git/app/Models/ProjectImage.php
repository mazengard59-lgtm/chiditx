<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

/** Showcase images for a project (portfolio carousel). */
final class ProjectImage extends Model
{
    protected string $table = 'project_images';

    protected array $fillable = ['project_id', 'image_url', 'sort_order'];

    public function forProject(int $projectId): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM project_images WHERE project_id = ? ORDER BY sort_order, id'
        );
        $stmt->execute([$projectId]);
        return $stmt->fetchAll();
    }

    /** project_id => [image rows] for a set of projects (one query). */
    public function forProjects(array $projectIds): array
    {
        if ($projectIds === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($projectIds), '?'));
        $stmt = $this->db->prepare(
            "SELECT * FROM project_images WHERE project_id IN ({$placeholders}) ORDER BY sort_order, id"
        );
        $stmt->execute(array_values($projectIds));

        $grouped = [];
        foreach ($stmt->fetchAll() as $row) {
            $grouped[(int) $row['project_id']][] = $row;
        }
        return $grouped;
    }
}
