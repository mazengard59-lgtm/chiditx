<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Domain extends Model
{
    protected string $table = 'domains';

    protected array $fillable = [
        'client_id', 'hosting_id', 'domain_name', 'registrar', 'purchase_date',
        'expiry_date', 'auto_renew', 'nameservers', 'ssl_expiry', 'status', 'notes',
    ];

    public const STATUSES = ['active', 'expired', 'transferred', 'cancelled'];

    public function allWithRelations(): array
    {
        return $this->db->query(
            'SELECT d.*, c.name AS client_name, h.provider AS hosting_provider
             FROM domains d
             LEFT JOIN clients c ON c.id = d.client_id
             LEFT JOIN hosting_accounts h ON h.id = d.hosting_id
             ORDER BY d.expiry_date IS NULL, d.expiry_date ASC'
        )->fetchAll();
    }
}
