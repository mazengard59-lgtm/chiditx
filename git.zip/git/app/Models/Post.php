<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Post extends Model
{
    protected string $table = 'posts';

    protected array $fillable = [
        'user_id', 'title', 'slug', 'excerpt', 'body', 'featured_image_url',
        'category', 'tags', 'meta_title', 'meta_description', 'status', 'published_at',
    ];

    public const STATUSES = ['draft', 'published'];

    public function allWithAuthors(): array
    {
        return $this->db->query(
            'SELECT p.*, u.name AS author_name,
                    (SELECT COUNT(*) FROM blog_comments bc WHERE bc.post_id = p.id AND bc.is_approved = 0) AS pending_comments
             FROM posts p
             LEFT JOIN users u ON u.id = p.user_id
             ORDER BY p.created_at DESC'
        )->fetchAll();
    }

    public function published(int $limit = 20): array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM posts
             WHERE status = 'published' AND published_at <= NOW()
             ORDER BY published_at DESC LIMIT " . max(1, $limit)
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findPublishedBySlug(string $slug): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.name AS author_name
             FROM posts p LEFT JOIN users u ON u.id = p.user_id
             WHERE p.slug = ? AND p.status = 'published' AND p.published_at <= NOW()
             LIMIT 1"
        );
        $stmt->execute([$slug]);
        return $stmt->fetch() ?: null;
    }

    /** URL-safe unique slug from a title. */
    public function makeSlug(string $title, ?int $ignoreId = null): string
    {
        $base = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $title), '-')) ?: 'post';
        $slug = $base;
        $n = 1;

        while (true) {
            $sql = 'SELECT COUNT(*) FROM posts WHERE slug = ?' . ($ignoreId ? ' AND id <> ?' : '');
            $stmt = $this->db->prepare($sql);
            $stmt->execute($ignoreId ? [$slug, $ignoreId] : [$slug]);
            if ((int) $stmt->fetchColumn() === 0) {
                return $slug;
            }
            $slug = $base . '-' . (++$n);
        }
    }
}
