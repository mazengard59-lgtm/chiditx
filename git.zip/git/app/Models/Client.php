<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Client extends Model
{
    protected string $table = 'clients';

    protected array $fillable = [
        'user_id', 'name', 'company', 'industry', 'email', 'phone', 'whatsapp',
        'country', 'timezone', 'address', 'photo_url', 'tags', 'notes', 'status',
    ];

    public const STATUSES = ['vip', 'regular', 'inactive'];

    /** All clients with their project counts, for the list view. */
    public function allWithProjectCounts(): array
    {
        return $this->db->query(
            'SELECT c.*, COUNT(p.id) AS project_count, COALESCE(SUM(p.price), 0) AS total_value
             FROM clients c
             LEFT JOIN projects p ON p.client_id = c.id
             GROUP BY c.id
             ORDER BY c.created_at DESC'
        )->fetchAll();
    }

    public function countByStatus(string $status): int
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM clients WHERE status = ?');
        $stmt->execute([$status]);
        return (int) $stmt->fetchColumn();
    }

    /** id => "Name — Company" pairs for select dropdowns. */
    public function options(): array
    {
        $rows = $this->db->query(
            "SELECT id, name, company FROM clients WHERE status <> 'inactive' ORDER BY name"
        )->fetchAll();

        $options = [];
        foreach ($rows as $row) {
            $options[(int) $row['id']] = $row['name'] . ($row['company'] ? ' — ' . $row['company'] : '');
        }
        return $options;
    }
}
