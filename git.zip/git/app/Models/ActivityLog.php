<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Request;

/**
 * Audit trail. Every significant action (logins, record changes,
 * renewals) is recorded here and surfaced on the dashboard.
 */
final class ActivityLog extends Model
{
    protected string $table = 'activity_logs';

    protected array $fillable = [
        'user_id', 'action', 'description', 'ip_address', 'user_agent',
    ];

    public static function record(?int $userId, string $action, string $description, ?Request $request = null): void
    {
        (new self())->create([
            'user_id'     => $userId,
            'action'      => $action,
            'description' => $description,
            'ip_address'  => $request?->ip(),
            'user_agent'  => $request?->userAgent(),
        ]);
    }

    /** @return array<int, array<string, mixed>> */
    public function recent(int $limit = 10): array
    {
        $stmt = $this->db->prepare(
            'SELECT al.*, u.name AS user_name
             FROM activity_logs al
             LEFT JOIN users u ON u.id = al.user_id
             ORDER BY al.created_at DESC
             LIMIT ' . max(1, $limit)
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
