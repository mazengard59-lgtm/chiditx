<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class HostingAccount extends Model
{
    protected string $table = 'hosting_accounts';

    protected array $fillable = [
        'client_id', 'provider', 'plan', 'disk_space', 'bandwidth', 'server_ip',
        'control_panel_url', 'php_version', 'has_ssl', 'username', 'expiry_date',
        'status', 'notes',
    ];

    public const STATUSES = ['active', 'suspended', 'cancelled'];

    public function allWithClients(): array
    {
        return $this->db->query(
            'SELECT h.*, c.name AS client_name
             FROM hosting_accounts h
             LEFT JOIN clients c ON c.id = h.client_id
             ORDER BY h.expiry_date IS NULL, h.expiry_date ASC'
        )->fetchAll();
    }

    /** id => label pairs for the domain form dropdown. */
    public function options(): array
    {
        $rows = $this->db->query(
            "SELECT id, provider, plan FROM hosting_accounts WHERE status = 'active' ORDER BY provider"
        )->fetchAll();

        $options = [];
        foreach ($rows as $row) {
            $options[(int) $row['id']] = $row['provider'] . ($row['plan'] ? ' — ' . $row['plan'] : '');
        }
        return $options;
    }
}
