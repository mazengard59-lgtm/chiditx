<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Lead extends Model
{
    protected string $table = 'leads';

    protected array $fillable = [
        'name', 'company', 'email', 'phone', 'whatsapp', 'source', 'status',
        'score', 'services', 'last_contact_at', 'follow_up_at', 'notes',
        'converted_client_id',
    ];

    public const SOURCES  = ['website', 'facebook', 'instagram', 'referral', 'whatsapp', 'other'];
    public const STATUSES = ['new', 'contacted', 'qualified', 'proposal', 'won', 'lost'];

    public const STATUS_COLORS = [
        'new'       => 'info',
        'contacted' => 'accent',
        'qualified' => 'accent',
        'proposal'  => 'warning',
        'won'       => 'success',
        'lost'      => 'muted',
    ];

    /** Open pipeline (not won/lost), follow-ups first. */
    public function pipeline(): array
    {
        return $this->db->query(
            "SELECT * FROM leads
             ORDER BY FIELD(status, 'new','contacted','qualified','proposal','won','lost'),
                      follow_up_at IS NULL, follow_up_at ASC, score DESC"
        )->fetchAll();
    }

    public function dueFollowUps(): int
    {
        return (int) $this->db->query(
            "SELECT COUNT(*) FROM leads
             WHERE follow_up_at <= CURDATE() AND status NOT IN ('won','lost')"
        )->fetchColumn();
    }
}
