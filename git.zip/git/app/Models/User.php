<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class User extends Model
{
    protected string $table = 'users';

    protected array $fillable = [
        'name', 'email', 'password_hash', 'role', 'status', 'avatar_url', 'phone', 'last_login_at',
    ];

    public function findByEmail(string $email): ?array
    {
        return $this->findBy('email', mb_strtolower($email));
    }

    public function touchLastLogin(int $id): void
    {
        $stmt = $this->db->prepare("UPDATE `{$this->table}` SET last_login_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
    }
}
