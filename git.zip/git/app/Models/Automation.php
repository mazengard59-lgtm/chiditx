<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

final class Automation extends Model
{
    protected string $table = 'automations';

    protected array $fillable = [
        'client_id', 'name', 'platform', 'description', 'prompt', 'workflow',
        'webhook_url', 'status', 'version',
    ];

    public const PLATFORMS = ['whatsapp', 'instagram', 'facebook', 'telegram', 'crm', 'api', 'webhook', 'other'];
    public const STATUSES  = ['development', 'active', 'paused', 'archived'];

    public const STATUS_COLORS = [
        'development' => 'info', 'active' => 'success', 'paused' => 'warning', 'archived' => 'muted',
    ];

    public const PLATFORM_ICONS = [
        'whatsapp' => 'whatsapp', 'instagram' => 'instagram', 'facebook' => 'facebook',
        'telegram' => 'telegram', 'crm' => 'funnel', 'api' => 'braces', 'webhook' => 'plug', 'other' => 'robot',
    ];

    public function allWithClients(): array
    {
        return $this->db->query(
            "SELECT a.*, c.name AS client_name,
                    (SELECT COUNT(*) FROM automation_logs l WHERE l.automation_id = a.id AND l.level = 'error') AS error_count
             FROM automations a
             LEFT JOIN clients c ON c.id = a.client_id
             ORDER BY FIELD(a.status, 'active','development','paused','archived'), a.updated_at DESC"
        )->fetchAll();
    }

    public function findWithClient(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT a.*, c.name AS client_name FROM automations a
             LEFT JOIN clients c ON c.id = a.client_id WHERE a.id = ? LIMIT 1'
        );
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }
}
