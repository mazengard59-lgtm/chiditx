<?php

declare(strict_types=1);

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Session;

/**
 * Global helper functions. Kept intentionally small — anything with
 * real logic belongs in a class, not here.
 */

/** Escape output for safe HTML rendering (XSS protection). */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Read a config value with dot notation, e.g. config('session.name'). */
function config(string $key, mixed $default = null): mixed
{
    static $config = null;
    $config ??= require BASE_PATH . '/config/app.php';

    $value = $config;
    foreach (explode('.', $key) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $default;
        }
        $value = $value[$segment];
    }
    return $value;
}

/** Base URL of the app (auto-detected, works in a subfolder and on InfinityFree). */
function base_url(): string
{
    static $base = null;
    if ($base === null) {
        $configured = config('url');
        if ($configured) {
            $base = rtrim($configured, '/');
        } else {
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
            $base   = "{$scheme}://{$host}{$dir}";
        }
    }
    return $base;
}

/** URL to a named path, e.g. url('dashboard'). */
function url(string $path = ''): string
{
    return base_url() . '/' . ltrim($path, '/');
}

/** URL to a public asset, e.g. asset('css/admin.css'). */
function asset(string $path): string
{
    return base_url() . '/assets/' . ltrim($path, '/');
}

/** Redirect and terminate. */
function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

/** Currently authenticated user (or null). */
function auth(): ?array
{
    return Auth::user();
}

/** Hidden CSRF input field for forms. */
function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

/** CSRF token value (for AJAX headers). */
function csrf_token(): string
{
    return Csrf::token();
}

/** Repopulate form values after a failed validation. */
function old(string $key, string $default = ''): string
{
    $old = Session::get('_old', []);
    return e($old[$key] ?? $default);
}

/** Format an amount as Naira, e.g. money(150000) => ₦150,000. */
function money(float|int|string $amount): string
{
    return '₦' . number_format((float) $amount, fmod((float) $amount, 1.0) === 0.0 ? 0 : 2);
}

/** Human label for an enum value: 'in_progress' => 'In Progress'. */
function label(string $value): string
{
    return ucwords(str_replace('_', ' ', $value));
}

/** Read an app setting from the DB (per-request cached), e.g. setting('emailjs_public_key'). */
function setting(string $key, ?string $default = null): ?string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (\App\Core\Database::connection()
                ->query('SELECT setting_key, setting_value FROM settings')->fetchAll() as $row) {
                $cache[$row['setting_key']] = $row['setting_value'];
            }
        } catch (\Throwable) {
            // settings table unavailable (e.g. mid-migration) — fall through to defaults
        }
    }
    $value = $cache[$key] ?? null;
    return ($value === null || $value === '') ? $default : $value;
}

/** Whole days from today until a date (negative = expired). Null-safe. */
function days_left(?string $date): ?int
{
    if (!$date) {
        return null;
    }
    return (int) floor((strtotime($date) - strtotime(date('Y-m-d'))) / 86400);
}

/**
 * Expiry color per spec thresholds (365/120/90/60/30/15/7/expired).
 * Returns [cssVariable, badgeVariant, humanLabel].
 */
function expiry_tone(?int $days): array
{
    return match (true) {
        $days === null => ['var(--text-low)', 'muted',   'no date'],
        $days < 0      => ['var(--danger)',   'danger',  abs($days) . 'd expired'],
        $days === 0    => ['var(--danger)',   'danger',  'expires today'],
        $days <= 7     => ['var(--danger)',   'danger',  $days . 'd left'],
        $days <= 15    => ['var(--warning)',  'warning', $days . 'd left'],
        $days <= 30    => ['var(--warning)',  'warning', $days . 'd left'],
        $days <= 60    => ['var(--info)',     'info',    $days . 'd left'],
        $days <= 90    => ['var(--info)',     'info',    $days . 'd left'],
        $days <= 120   => ['var(--text-mid)', 'muted',   $days . 'd left'],
        default        => ['var(--success)',  'success', $days . 'd left'],
    };
}

/** Flash message helper: flash('success', 'Saved!') to set, flash('success') to read. */
function flash(string $key, ?string $message = null): ?string
{
    if ($message !== null) {
        Session::flash($key, $message);
        return null;
    }
    return Session::pull('_flash_' . $key);
}
