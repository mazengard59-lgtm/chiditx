/**
 * SAMS admin shell behaviors: theme toggle, mobile sidebar,
 * auto-dismissing flash messages, and a fetch wrapper that
 * attaches the CSRF token to every AJAX request.
 */
(() => {
  'use strict';

  /* ---- Theme (persisted, dark by default) ---- */
  const root = document.documentElement;
  const applyTheme = (theme) => {
    root.setAttribute('data-theme', theme);
    localStorage.setItem('sams-theme', theme);
    const icon = document.querySelector('#themeToggle i');
    if (icon) icon.className = theme === 'dark' ? 'bi bi-sun' : 'bi bi-moon-stars';
  };

  applyTheme(localStorage.getItem('sams-theme') || 'dark');

  document.getElementById('themeToggle')?.addEventListener('click', () => {
    applyTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
  });

  /* ---- Mobile sidebar ---- */
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebarBackdrop');
  const setSidebar = (open) => {
    sidebar?.classList.toggle('is-open', open);
    backdrop?.classList.toggle('is-visible', open);
  };
  document.getElementById('sidebarToggle')?.addEventListener('click', () => {
    setSidebar(!sidebar?.classList.contains('is-open'));
  });
  backdrop?.addEventListener('click', () => setSidebar(false));

  /* ---- Flash messages auto-dismiss ---- */
  document.querySelectorAll('[data-flash]').forEach((el) => {
    setTimeout(() => {
      el.style.transition = 'opacity .4s, transform .4s';
      el.style.opacity = '0';
      el.style.transform = 'translateY(-6px)';
      setTimeout(() => el.remove(), 400);
    }, 4500);
  });

  /* ---- Mobile table accordions ----
     Builds an accordion sibling for every .table-sams from its own rows.
     Must run BEFORE DataTables init: DataTables removes off-page rows
     from the DOM, and the accordion needs all of them. CSS decides
     which representation is visible per breakpoint. */
  const cloneCellInto = (cell, target) => {
    [...cell.childNodes].forEach((node) => target.appendChild(node.cloneNode(true)));
  };

  document.querySelectorAll('table.table-sams').forEach((table) => {
    const wrap = table.closest('.table-wrap');
    if (!wrap || wrap.dataset.accordion === 'built') return;
    wrap.dataset.accordion = 'built';

    const headers = [...table.querySelectorAll('thead th')].map((th) => th.textContent.trim());
    const hasHead = headers.length > 0;
    const accordion = document.createElement('div');
    accordion.className = 'table-accordion';

    table.querySelectorAll('tbody tr').forEach((tr) => {
      const cells = [...tr.children];
      if (!cells.length) return;

      const item = document.createElement('div');
      item.className = 'acc-item';

      // Header: first cell (plus second when the table has no thead,
      // e.g. renewal buckets where cell 1 is just an icon).
      const head = document.createElement('button');
      head.type = 'button';
      head.className = 'acc-head';
      const title = document.createElement('div');
      title.className = 'acc-title';
      const titleCells = hasHead ? 1 : Math.min(2, cells.length);
      for (let i = 0; i < titleCells; i++) cloneCellInto(cells[i], title);
      head.appendChild(title);
      head.insertAdjacentHTML('beforeend', '<i class="bi bi-chevron-down acc-chevron"></i>');

      // Body: remaining cells as label/value rows; cells holding
      // buttons or forms become an action row.
      const body = document.createElement('div');
      body.className = 'acc-body';
      cells.slice(titleCells).forEach((cell, idx) => {
        if (!cell.innerHTML.trim()) return;
        const isActions = !!cell.querySelector('form, .icon-btn, .btn-sams, .btn-ghost-sams');
        const row = document.createElement('div');
        row.className = isActions ? 'acc-actions' : 'acc-row';
        const label = hasHead ? headers[idx + titleCells] || '' : '';
        if (!isActions && label) {
          const tag = document.createElement('span');
          tag.className = 'acc-label';
          tag.textContent = label;
          row.appendChild(tag);
        }
        const value = document.createElement('div');
        value.className = 'acc-value';
        cloneCellInto(cell, value);
        row.appendChild(value);
        body.appendChild(row);
      });

      head.addEventListener('click', () => item.classList.toggle('is-open'));
      item.append(head, body);
      accordion.appendChild(item);
    });

    wrap.insertAdjacentElement('afterend', accordion);
  });

  /* ---- DataTables ---- */
  if (window.jQuery && jQuery.fn.dataTable) {
    document.querySelectorAll('.sams-datatable').forEach((table) => {
      new jQuery.fn.dataTable.Api(jQuery(table).DataTable({
        pageLength: 10,
        lengthMenu: [10, 25, 50, 100],
        order: [],
        language: { search: '', searchPlaceholder: 'Search…' },
      }));
    });
  }

  /* ---- SweetAlert2 delete confirmations (forms with data-confirm) ---- */
  document.addEventListener('submit', (event) => {
    const form = event.target.closest('form[data-confirm]');
    if (!form || form.dataset.confirmed === 'yes') return;

    event.preventDefault();
    const styles = getComputedStyle(document.documentElement);
    Swal.fire({
      title: 'Are you sure?',
      text: form.dataset.confirm,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete',
      confirmButtonColor: styles.getPropertyValue('--accent').trim() || '#E8342A',
      background: styles.getPropertyValue('--surface').trim(),
      color: styles.getPropertyValue('--text-hi').trim(),
    }).then((result) => {
      if (result.isConfirmed) {
        form.dataset.confirmed = 'yes';
        form.submit();
      }
    });
  });

  /* ---- CSRF-aware fetch for module AJAX (Phase 2+) ---- */
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content;
  window.samsFetch = (url, options = {}) =>
    fetch(url, {
      ...options,
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': csrf || '',
        ...(options.headers || {}),
      },
    });
})();
