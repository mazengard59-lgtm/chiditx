<?php

declare(strict_types=1);

/**
 * Route definitions.
 * Signature: $router->get|post(path, [Controller::class, 'method'], [middleware...])
 * CSRF is enforced automatically on all POST routes by the kernel.
 */

use App\Controllers\AnalyticsController;
use App\Controllers\AuthController;
use App\Controllers\AutomationController;
use App\Controllers\PortalController;
use App\Controllers\SettingsController;
use App\Controllers\BlogController;
use App\Controllers\ClientController;
use App\Controllers\InvoiceController;
use App\Controllers\TicketController;
use App\Controllers\DashboardController;
use App\Controllers\DomainController;
use App\Controllers\HomeController;
use App\Controllers\HostingController;
use App\Controllers\LeadController;
use App\Controllers\ProjectController;
use App\Controllers\RenewalController;

/** @var App\Core\App $app */
$router = $app->router;

// ---- Public website ----
$router->get('/', [HomeController::class, 'index']);
$router->get('/blog',                 [BlogController::class, 'publicIndex']);
$router->get('/blog/{slug}',          [BlogController::class, 'publicShow']);
$router->post('/blog/{slug}/comment', [BlogController::class, 'submitComment']);

// ---- Authentication ----
$router->get('/login',   [AuthController::class, 'showLogin'], ['guest']);
$router->post('/login',  [AuthController::class, 'login'],     ['guest']);
$router->post('/logout', [AuthController::class, 'logout'],    ['auth']);

// ---- Admin area ----
$router->get('/dashboard', [DashboardController::class, 'index'], ['auth', 'admin']);

// Clients
$router->get('/clients',              [ClientController::class, 'index'],   ['auth', 'admin']);
$router->get('/clients/create',       [ClientController::class, 'create'],  ['auth', 'admin']);
$router->post('/clients',             [ClientController::class, 'store'],   ['auth', 'admin']);
$router->get('/clients/{id}',         [ClientController::class, 'show'],    ['auth', 'admin']);
$router->get('/clients/{id}/edit',    [ClientController::class, 'edit'],    ['auth', 'admin']);
$router->post('/clients/{id}',        [ClientController::class, 'update'],  ['auth', 'admin']);
$router->post('/clients/{id}/delete', [ClientController::class, 'destroy'], ['auth', 'admin']);

// Projects
$router->get('/projects',              [ProjectController::class, 'index'],   ['auth', 'admin']);
$router->get('/projects/create',       [ProjectController::class, 'create'],  ['auth', 'admin']);
$router->post('/projects',             [ProjectController::class, 'store'],   ['auth', 'admin']);
$router->get('/projects/{id}',         [ProjectController::class, 'show'],    ['auth', 'admin']);
$router->get('/projects/{id}/edit',    [ProjectController::class, 'edit'],    ['auth', 'admin']);
$router->post('/projects/{id}',        [ProjectController::class, 'update'],  ['auth', 'admin']);
$router->post('/projects/{id}/delete', [ProjectController::class, 'destroy'], ['auth', 'admin']);
$router->post('/projects/{id}/images/{imageId}/delete', [ProjectController::class, 'destroyImage'], ['auth', 'admin']);

// Domains
$router->get('/domains',              [DomainController::class, 'index'],   ['auth', 'admin']);
$router->get('/domains/create',       [DomainController::class, 'create'],  ['auth', 'admin']);
$router->post('/domains',             [DomainController::class, 'store'],   ['auth', 'admin']);
$router->get('/domains/{id}/edit',    [DomainController::class, 'edit'],    ['auth', 'admin']);
$router->post('/domains/{id}',        [DomainController::class, 'update'],  ['auth', 'admin']);
$router->post('/domains/{id}/delete', [DomainController::class, 'destroy'], ['auth', 'admin']);

// Hosting
$router->get('/hosting',              [HostingController::class, 'index'],   ['auth', 'admin']);
$router->get('/hosting/create',       [HostingController::class, 'create'],  ['auth', 'admin']);
$router->post('/hosting',             [HostingController::class, 'store'],   ['auth', 'admin']);
$router->get('/hosting/{id}/edit',    [HostingController::class, 'edit'],    ['auth', 'admin']);
$router->post('/hosting/{id}',        [HostingController::class, 'update'],  ['auth', 'admin']);
$router->post('/hosting/{id}/delete', [HostingController::class, 'destroy'], ['auth', 'admin']);

// Renewal Center
$router->get('/renewals',        [RenewalController::class, 'index'], ['auth', 'admin']);
$router->post('/renewals/renew', [RenewalController::class, 'renew'], ['auth', 'admin']);

// CRM (leads)
$router->get('/crm',               [LeadController::class, 'index'],   ['auth', 'admin']);
$router->get('/crm/create',        [LeadController::class, 'create'],  ['auth', 'admin']);
$router->post('/crm',              [LeadController::class, 'store'],   ['auth', 'admin']);
$router->get('/crm/{id}/edit',     [LeadController::class, 'edit'],    ['auth', 'admin']);
$router->post('/crm/{id}',         [LeadController::class, 'update'],  ['auth', 'admin']);
$router->post('/crm/{id}/delete',  [LeadController::class, 'destroy'], ['auth', 'admin']);
$router->post('/crm/{id}/convert', [LeadController::class, 'convert'], ['auth', 'admin']);

// Invoices
$router->get('/invoices',               [InvoiceController::class, 'index'],      ['auth', 'admin']);
$router->get('/invoices/create',        [InvoiceController::class, 'create'],     ['auth', 'admin']);
$router->post('/invoices',              [InvoiceController::class, 'store'],      ['auth', 'admin']);
$router->get('/invoices/{id}',          [InvoiceController::class, 'show'],       ['auth', 'admin']);
$router->get('/invoices/{id}/edit',     [InvoiceController::class, 'edit'],       ['auth', 'admin']);
$router->get('/invoices/{id}/print',    [InvoiceController::class, 'print'],      ['auth', 'admin']);
$router->post('/invoices/{id}',         [InvoiceController::class, 'update'],     ['auth', 'admin']);
$router->post('/invoices/{id}/delete',  [InvoiceController::class, 'destroy'],    ['auth', 'admin']);
$router->post('/invoices/{id}/payment', [InvoiceController::class, 'addPayment'], ['auth', 'admin']);

// Support tickets
$router->get('/support',              [TicketController::class, 'index'],     ['auth', 'admin']);
$router->get('/support/create',       [TicketController::class, 'create'],    ['auth', 'admin']);
$router->post('/support',             [TicketController::class, 'store'],     ['auth', 'admin']);
$router->get('/support/{id}',         [TicketController::class, 'show'],      ['auth', 'admin']);
$router->post('/support/{id}/reply',  [TicketController::class, 'reply'],     ['auth', 'admin']);
$router->post('/support/{id}/status', [TicketController::class, 'setStatus'], ['auth', 'admin']);
$router->post('/support/{id}/delete', [TicketController::class, 'destroy'],   ['auth', 'admin']);

// Blog CMS (admin lives at /posts; public blog is /blog)
$router->get('/posts',                       [BlogController::class, 'index'],         ['auth', 'admin']);
$router->get('/posts/create',                [BlogController::class, 'create'],        ['auth', 'admin']);
$router->post('/posts',                      [BlogController::class, 'store'],         ['auth', 'admin']);
$router->get('/posts/comments',              [BlogController::class, 'comments'],      ['auth', 'admin']);
$router->post('/posts/comments/{id}/ok',     [BlogController::class, 'approveComment'],['auth', 'admin']);
$router->post('/posts/comments/{id}/delete', [BlogController::class, 'deleteComment'], ['auth', 'admin']);
$router->get('/posts/{id}/edit',             [BlogController::class, 'edit'],          ['auth', 'admin']);
$router->post('/posts/{id}',                 [BlogController::class, 'update'],        ['auth', 'admin']);
$router->post('/posts/{id}/delete',          [BlogController::class, 'destroy'],       ['auth', 'admin']);

// Analytics
$router->get('/analytics', [AnalyticsController::class, 'index'], ['auth', 'admin']);

// Clients — portal account provisioning
$router->post('/clients/{id}/portal', [App\Controllers\ClientController::class, 'createPortalAccount'], ['auth', 'admin']);

// AI Automations
$router->get('/automations',              [AutomationController::class, 'index'],   ['auth', 'admin']);
$router->get('/automations/create',       [AutomationController::class, 'create'],  ['auth', 'admin']);
$router->post('/automations',             [AutomationController::class, 'store'],   ['auth', 'admin']);
$router->get('/automations/{id}',         [AutomationController::class, 'show'],    ['auth', 'admin']);
$router->get('/automations/{id}/edit',    [AutomationController::class, 'edit'],    ['auth', 'admin']);
$router->post('/automations/{id}',        [AutomationController::class, 'update'],  ['auth', 'admin']);
$router->post('/automations/{id}/delete', [AutomationController::class, 'destroy'], ['auth', 'admin']);
$router->post('/automations/{id}/log',    [AutomationController::class, 'addLog'],  ['auth', 'admin']);

// Settings
$router->get('/settings',                   [SettingsController::class, 'index'],             ['auth', 'admin']);
$router->post('/settings/save',             [SettingsController::class, 'save'],              ['auth', 'admin']);
$router->post('/settings/users',            [SettingsController::class, 'createUser'],        ['auth', 'admin']);
$router->post('/settings/users/{id}/toggle',[SettingsController::class, 'toggleUser'],        ['auth', 'admin']);
$router->post('/settings/users/{id}/reset', [SettingsController::class, 'resetUserPassword'], ['auth', 'admin']);
$router->get('/settings/backup',            [SettingsController::class, 'backup'],            ['auth', 'admin']);

// ---- Client portal ----
$router->get('/portal',                     [PortalController::class, 'dashboard'],    ['auth', 'client']);
$router->get('/portal/projects',            [PortalController::class, 'projects'],     ['auth', 'client']);
$router->get('/portal/invoices',            [PortalController::class, 'invoices'],     ['auth', 'client']);
$router->get('/portal/invoices/{id}/print', [PortalController::class, 'invoicePrint'], ['auth', 'client']);
$router->get('/portal/tickets',             [PortalController::class, 'tickets'],      ['auth', 'client']);
$router->post('/portal/tickets',            [PortalController::class, 'ticketStore'],  ['auth', 'client']);
$router->get('/portal/tickets/{id}',        [PortalController::class, 'ticketShow'],   ['auth', 'client']);
$router->post('/portal/tickets/{id}/reply', [PortalController::class, 'ticketReply'],  ['auth', 'client']);
$router->get('/portal/profile',             [PortalController::class, 'profile'],      ['auth', 'client']);
$router->post('/portal/profile',            [PortalController::class, 'profileSave'],  ['auth', 'client']);
$router->post('/portal/password',           [PortalController::class, 'passwordSave'], ['auth', 'client']);
