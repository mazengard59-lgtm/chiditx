SAMS — Deployment to InfinityFree
=================================

WHAT YOU HAVE
  sams-deploy.zip     -> the application (upload contents into htdocs)
  sams-database.sql   -> full database (import via phpMyAdmin)

STEPS
1. CREATE THE DATABASE
   - InfinityFree control panel -> MySQL Databases -> create a database
     (you get a name like if0_1234567_sams).
   - Note the MySQL host (e.g. sql301.infinityfree.com), the db name,
     and your username (if0_1234567). Password = your vPanel password.

2. IMPORT THE SQL
   - Control panel -> phpMyAdmin (next to the new database) -> Import
   - Choose sams-database.sql -> Go.
   - It contains all tables AND your current data (admin login, clients,
     projects, showcase images, blog post, settings...).

3. UPLOAD THE APP
   - Open the InfinityFree File Manager -> htdocs
   - Upload sams-deploy.zip and use "Extract" (or extract locally and
     upload via FTP/FileZilla). Everything goes directly inside htdocs,
     so htdocs/index.php exists (not htdocs/portfolio/index.php).

4. CONFIGURE
   - In htdocs/config/: rename env.example.php -> env.php
   - Edit env.php: fill in the db host / name / user / password from step 1.
   - debug is already false in that file. Leave it false.

5. TEST
   - Visit your domain: the portfolio should load.
   - /login -> your same admin email + password as on localhost.
   - Dashboard, clients, renewals etc. should all work.

NOTES
 - The database contains the demo/test records created while building
   (client "Acme Fintech Ltd", "Jane Okafor", a test invoice/ticket/post).
   Delete them from the UI whenever you like.
 - Change your admin password after deploying (Settings -> Users -> key icon).
 - Uploaded screenshots live in assets/uploads/ and are included in the zip.
 - InfinityFree free SSL: enable it in the panel, the app auto-detects https.
