<?php

/**
 * Application configuration.
 * Override per-environment values in config/env.php (git-ignored).
 */

$config = [
    'name'     => 'SAMS',
    'agency'   => 'Chidi — Software Agency',
    'env'      => 'local',              // local | production
    'debug'    => true,                 // MUST be false in production
    'url'      => '',                   // auto-detected when empty
    'timezone' => 'Africa/Lagos',

    'session' => [
        'name'     => 'sams_session',
        'lifetime' => 7200,             // seconds of inactivity before logout
    ],

    'owner' => [
        'name'     => 'Chidi',
        'email'    => 'opreciouschidi@gmail.com',
        'whatsapp' => '2348084508767',
    ],
];

// Environment-specific overrides (create config/env.php on the server)
$envFile = __DIR__ . '/env.php';
if (is_file($envFile)) {
    $config = array_replace_recursive($config, require $envFile);
}

return $config;
