<?php

/**
 * PRODUCTION ENVIRONMENT — InfinityFree
 * 1. Rename this file to env.php
 * 2. Fill in the values from your InfinityFree control panel
 *    (Account → MySQL Databases shows host, db name, username)
 * env.php is git-ignored and blocked from the web by .htaccess.
 */

return [
    'env'   => 'production',
    'debug' => false,               // NEVER true in production

    // 'url' => 'https://yourdomain.com',   // uncomment to pin the base URL

    'db' => [
        'host' => 'sql102.infinityfree.com', // e.g. sql301.infinityfree.com
        'name' => 'if0_42348747_sams',
        'user' => 'if0_42348747',
        'pass' => '84ZgwdMtgQFEoaX',
    ],
];
