<?php

/**
 * Database configuration.
 * Local XAMPP defaults; production values come from config/env.php
 * (copy env.example.php → env.php on the server and fill it in).
 */

$config = [
    'host'    => '127.0.0.1',
    'port'    => 3306,
    'name'    => 'sams',
    'user'    => 'root',
    'pass'    => '',
    'charset' => 'utf8mb4',
];

$envFile = __DIR__ . '/env.php';
if (is_file($envFile)) {
    $env = require $envFile;
    if (isset($env['db']) && is_array($env['db'])) {
        $config = array_replace($config, $env['db']);
    }
}

return $config;
